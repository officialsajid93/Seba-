// Locale-aware formatting. Bengali uses Bengali digits (Intl "bn-IN"), matching
// how dates and prices are printed locally. All times are shown in India time.
const TZ = "Asia/Kolkata";
const intlLocale = (lang: string) => (lang === "bn" ? "bn-IN" : "en-IN");

export function formatMoney(paise: number, lang: string): string {
  return new Intl.NumberFormat(intlLocale(lang), {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: paise % 100 === 0 ? 0 : 2,
  }).format(paise / 100);
}

export function formatNumber(n: number, lang: string): string {
  return new Intl.NumberFormat(intlLocale(lang)).format(n);
}

export function formatDay(d: Date, lang: string): string {
  return new Intl.DateTimeFormat(intlLocale(lang), { timeZone: TZ, weekday: "short", day: "numeric", month: "short" }).format(d);
}

export function formatTime(d: Date, lang: string): string {
  return new Intl.DateTimeFormat(intlLocale(lang), { timeZone: TZ, hour: "numeric", minute: "2-digit" }).format(d);
}

export function formatSitting(start: Date, end: Date, lang: string): { day: string; time: string } {
  return { day: formatDay(start, lang), time: `${formatTime(start, lang)} – ${formatTime(end, lang)}` };
}
