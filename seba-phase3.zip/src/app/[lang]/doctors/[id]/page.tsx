import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { BadgeCheck, GraduationCap, Info, Languages, MapPin, Navigation, Phone, Stethoscope } from "lucide-react";
import { format } from "@/i18n/config";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatMoney, formatNumber, formatSitting } from "@/lib/format";
import { directionsUrl } from "@/lib/adapters/maps";
import { getDoctor, pick, type Practice } from "@/server/directory";
import { AvailabilityBadge, ConfirmedAgo } from "@/components/ui/availability";
import { Badge, Button, buttonClass, Card } from "@/components/ui/primitives";
import { ListSkeleton, Notice } from "@/components/ui/states";
import { DemoBadge, facilityIcon } from "@/components/directory/cards";
import { SaveDoctorButton } from "@/components/directory/SaveDoctorButton";

const LANG_NAMES: Record<string, { en: string; bn: string }> = {
  bn: { en: "Bengali", bn: "বাংলা" },
  en: { en: "English", bn: "ইংরেজি" },
  hi: { en: "Hindi", bn: "হিন্দি" },
};

export async function generateMetadata({ params }: PageProps<"/[lang]/doctors/[id]">): Promise<Metadata> {
  const { id } = await params;
  const [doctor, lang] = await Promise.all([getDoctor(id), getLocale()]);
  return doctor ? { title: pick(doctor.name, lang), robots: doctor.isDemo ? { index: false } : undefined } : {};
}

function PracticeCard({ p, lang, t, now }: { p: Practice; lang: string; t: Dictionary; now: Date }) {
  const d = t.directory;
  const Icon = facilityIcon[p.facility.type];
  return (
    <Card className="space-y-3">
      <div className="flex gap-3">
        <div className="grid size-11 shrink-0 place-items-center rounded-xl bg-teal-50 text-teal-700" aria-hidden>
          <Icon className="size-6" />
        </div>
        <div className="min-w-0 flex-1">
          <Link href={`/${lang}/facilities/${p.facility.id}`} className="font-semibold text-brand-700 underline-offset-2 hover:underline">
            {pick(p.facility.name, lang)}
          </Link>
          <p className="flex items-start gap-1 text-sm text-muted">
            <MapPin className="mt-0.5 size-4 shrink-0" aria-hidden />
            {p.facility.address}, {pick(p.facility.town, lang)}
          </p>
          <p className="text-sm">
            <span className="font-semibold">{format(d.fee, { amount: formatMoney(p.feePaise, lang) })}</span>
            <span className="text-muted"> · {p.bookingMode === "serial_token" ? d.serialBooking : d.slotBooking}</span>
          </p>
        </div>
      </div>

      <div className="flex gap-2">
        {p.facility.phone && (
          <a href={`tel:${p.facility.phone}`} className={buttonClass("secondary", "sm", true)}>
            <Phone className="size-4" aria-hidden />
            {d.call}
          </a>
        )}
        {p.facility.lat !== null && p.facility.lng !== null && (
          <a href={directionsUrl(p.facility.lat, p.facility.lng)} target="_blank" rel="noopener noreferrer" className={buttonClass("secondary", "sm", true)}>
            <Navigation className="size-4" aria-hidden />
            {d.directions}
          </a>
        )}
      </div>

      <ConfirmedAgo t={t.availability} confirmedAt={p.scheduleOk ? p.confirmedAt : null} now={now} />
      {!p.scheduleOk && <Notice tone="warn" icon={<Info className="size-5" />}>{d.notConfirmedNote}</Notice>}

      <div>
        <h3 className="mb-2 text-sm font-semibold text-muted">{d.sittings}</h3>
        {p.sittings.length === 0 ? (
          <p className="rounded-control bg-canvas px-3 py-2 text-sm text-muted">{d.noUpcoming}</p>
        ) : (
          <ul className="space-y-2">
            {p.sittings.map((s) => {
              const when = formatSitting(s.startsAt, s.endsAt, lang);
              return (
                <li key={s.id} className="flex flex-wrap items-center justify-between gap-2 rounded-control bg-canvas px-3 py-2">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold">{when.day}</p>
                    <p className="text-sm text-muted">{when.time}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <AvailabilityBadge t={t.availability} state={s.state} />
                    {s.bookable && (
                      <Button size="sm" disabled title={d.bookingSoon}>
                        {d.book}
                      </Button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
        {p.sittings.some((s) => s.bookable) && <p className="mt-2 text-sm text-muted">{d.bookingSoon}</p>}
      </div>
    </Card>
  );
}

async function DoctorContent({ params, t, lang }: { params: PageProps<"/[lang]/doctors/[id]">["params"]; t: Dictionary; lang: string }) {
  const { id } = await params;
  const doctor = await getDoctor(id);
  if (!doctor) notFound();
  const d = t.directory;
  const now = new Date();
  return (
    <div className="space-y-4">
      <Card className="space-y-3">
        <div className="flex items-start gap-3">
          <div className="grid size-16 shrink-0 place-items-center rounded-full bg-brand-50 text-brand-600" aria-hidden>
            <Stethoscope className="size-8" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="text-xl font-bold leading-snug">{pick(doctor.name, lang)}</h1>
            <p className="text-muted">{doctor.specialities.map((s) => pick(s, lang)).join(", ")}</p>
            {doctor.yearsExperience !== null && (
              <p className="text-sm text-muted">{format(d.years, { count: formatNumber(doctor.yearsExperience, lang) })}</p>
            )}
          </div>
          <Suspense fallback={null}>
            <SaveDoctorButton doctorId={doctor.id} lang={lang} saveLabel={t.account.saveDoctor} unsaveLabel={t.account.unsaveDoctor} />
          </Suspense>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <Badge tone="ok" icon={<BadgeCheck className="size-4" aria-hidden />}>{d.verifiedDoctor}</Badge>
          {doctor.isDemo && <DemoBadge label={d.demo} />}
        </div>
        {doctor.bio && <p>{pick(doctor.bio, lang)}</p>}
        <dl className="grid gap-2 text-sm">
          <div className="flex gap-2">
            <dt className="flex items-center gap-1.5 font-semibold"><GraduationCap className="size-4 text-brand-600" aria-hidden />{d.qualifications}:</dt>
            <dd className="text-muted">{doctor.qualifications.map((q) => q.degree).join(", ")}</dd>
          </div>
          {doctor.languages.length > 0 && (
            <div className="flex gap-2">
              <dt className="flex items-center gap-1.5 font-semibold"><Languages className="size-4 text-brand-600" aria-hidden />{d.languages}:</dt>
              <dd className="text-muted">{doctor.languages.map((l) => LANG_NAMES[l]?.[lang === "bn" ? "bn" : "en"] ?? l).join(", ")}</dd>
            </div>
          )}
          <div className="flex gap-2">
            <dt className="font-semibold">{d.registration}:</dt>
            <dd className="text-muted">{doctor.registration.number} · {doctor.registration.council}</dd>
          </div>
        </dl>
      </Card>

      <h2 className="pt-2 text-lg font-semibold">{d.practisesAt}</h2>
      <ul className="space-y-3">
        {doctor.practices.map((p) => (
          <li key={p.id}>
            <PracticeCard p={p} lang={lang} t={t} now={now} />
          </li>
        ))}
      </ul>
    </div>
  );
}

export default async function DoctorPage({ params }: PageProps<"/[lang]/doctors/[id]">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <Suspense fallback={<ListSkeleton rows={2} label={t.states.loading} />}>
      <DoctorContent params={params} t={t} lang={lang} />
    </Suspense>
  );
}
