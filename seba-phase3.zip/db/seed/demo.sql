-- DEMO DATA — development and staging only. Every provider is fictional,
-- named "Demo ...", flagged is_demo = true, and uses a registration number
-- starting with DEMO-. Re-running replaces the previous demo rows.
-- Loaded by `npm run db:seed:demo`, which refuses to run in production.
BEGIN;

-- Remove previous demo rows (children first).
DELETE FROM appointment_events WHERE appointment_id IN (
  SELECT a.id FROM appointments a JOIN consultation_sessions s ON s.id = a.session_id
  JOIN doctor_practices p ON p.id = s.practice_id JOIN doctors d ON d.id = p.doctor_id WHERE d.is_demo);
DELETE FROM appointments WHERE session_id IN (
  SELECT s.id FROM consultation_sessions s JOIN doctor_practices p ON p.id = s.practice_id
  JOIN doctors d ON d.id = p.doctor_id WHERE d.is_demo);
DELETE FROM consultation_sessions WHERE practice_id IN (
  SELECT p.id FROM doctor_practices p JOIN doctors d ON d.id = p.doctor_id WHERE d.is_demo);
DELETE FROM schedule_exceptions WHERE doctor_id IN (SELECT id FROM doctors WHERE is_demo);
DELETE FROM schedule_templates WHERE practice_id IN (
  SELECT p.id FROM doctor_practices p JOIN doctors d ON d.id = p.doctor_id WHERE d.is_demo);
DELETE FROM saved_doctors WHERE doctor_id IN (SELECT id FROM doctors WHERE is_demo);
DELETE FROM doctor_practices WHERE doctor_id IN (SELECT id FROM doctors WHERE is_demo);
DELETE FROM doctor_specialities WHERE doctor_id IN (SELECT id FROM doctors WHERE is_demo);
DELETE FROM doctor_qualifications WHERE doctor_id IN (SELECT id FROM doctors WHERE is_demo);
DELETE FROM doctors WHERE is_demo;
DELETE FROM lab_tests WHERE facility_id IN (SELECT id FROM facilities WHERE is_demo);
DELETE FROM facility_services WHERE facility_id IN (SELECT id FROM facilities WHERE is_demo);
DELETE FROM departments WHERE facility_id IN (SELECT id FROM facilities WHERE is_demo);
DELETE FROM facilities WHERE is_demo;

-- The demo verifier who "approved" these listings.
INSERT INTO users (id, phone_e164, display_name, preferred_lang)
VALUES ('de000000-0000-4000-8000-000000000001', '+916000000001', 'Demo Verifier', 'en')
ON CONFLICT (id) DO NOTHING;

-- Facilities (approximate town-centre coordinates)
INSERT INTO facilities (id, is_demo, type, name, name_bn, address_line, locality_id, pincode, lat, lng, phone_e164,
                        open_24x7, emergency_available, verification_status, verified_at, is_published)
SELECT v.id::uuid, true, v.type::facility_type, v.name, v.name_bn, v.addr, l.id, v.pin, v.lat, v.lng, v.phone,
       v.open247, v.emergency, 'verified', now(), true
FROM (VALUES
  ('de000000-0000-4000-8000-0000000000f1', 'chamber',          'Demo Chamber (Medicine Shop)', 'ডেমো চেম্বার (ওষুধের দোকান)', 'Demo Road, near bus stand',  'dhuliyan', '742202', 24.6800, 87.9500, '+916000000101', false, false),
  ('de000000-0000-4000-8000-0000000000f2', 'hospital',         'Demo General Hospital',        'ডেমো জেনারেল হাসপাতাল',       'Demo Hospital Road',         'jangipur', '742213', 24.4700, 88.0700, '+916000000102', true,  true),
  ('de000000-0000-4000-8000-0000000000f3', 'nursing_home',     'Demo Nursing Home',            'ডেমো নার্সিং হোম',            'Demo Lane, NTPC more',       'farakka',  '742212', 24.8100, 87.9100, '+916000000103', true,  true),
  ('de000000-0000-4000-8000-0000000000f4', 'diagnostic_centre','Demo Diagnostic Centre',       'ডেমো ডায়াগনস্টিক সেন্টার',     'Demo Market, Station Road',  'malda',    '732101', 25.0000, 88.1400, '+916000000104', false, false),
  ('de000000-0000-4000-8000-0000000000f5', 'clinic',           'Demo Polyclinic',              'ডেমো পলিক্লিনিক',              'Demo Para, Rathbari',        'malda',    '732101', 25.0050, 88.1450, '+916000000105', false, false)
) AS v(id, type, name, name_bn, addr, town, pin, lat, lng, phone, open247, emergency)
JOIN localities l ON l.slug = v.town;

INSERT INTO departments (facility_id, name, name_bn) VALUES
  ('de000000-0000-4000-8000-0000000000f2', 'Medicine', 'মেডিসিন'),
  ('de000000-0000-4000-8000-0000000000f2', 'Orthopaedics', 'অর্থোপেডিক্স'),
  ('de000000-0000-4000-8000-0000000000f3', 'Obstetrics and Gynaecology', 'প্রসূতি ও স্ত্রীরোগ');

INSERT INTO facility_services (facility_id, category, name) VALUES
  ('de000000-0000-4000-8000-0000000000f2', 'Emergency', '24-hour emergency'),
  ('de000000-0000-4000-8000-0000000000f2', 'Imaging', 'X-Ray'),
  ('de000000-0000-4000-8000-0000000000f2', 'Ambulance', 'Ambulance'),
  ('de000000-0000-4000-8000-0000000000f3', 'Maternity', 'Normal and caesarean delivery'),
  ('de000000-0000-4000-8000-0000000000f3', 'Beds', 'General ward'),
  ('de000000-0000-4000-8000-0000000000f4', 'Pathology', 'Blood tests'),
  ('de000000-0000-4000-8000-0000000000f4', 'Imaging', 'Ultrasound (USG)');

INSERT INTO lab_tests (facility_id, name, name_bn, sample_type, price_paise, home_collection) VALUES
  ('de000000-0000-4000-8000-0000000000f4', 'Complete Blood Count (CBC)', 'সিবিসি রক্ত পরীক্ষা', 'Blood', 25000, true),
  ('de000000-0000-4000-8000-0000000000f4', 'Blood Sugar (Fasting)', 'রক্তে শর্করা (খালি পেটে)', 'Blood', 8000, true),
  ('de000000-0000-4000-8000-0000000000f4', 'USG Whole Abdomen', 'ইউএসজি পুরো পেট', NULL, 90000, false);

-- Doctors
INSERT INTO doctors (id, is_demo, full_name, full_name_bn, sex, registration_number, registration_council,
                     practising_since, languages, verification_status, verified_at, verified_by, bio_en, bio_bn)
SELECT v.id::uuid, true, v.name, v.name_bn, v.sex, v.reg, 'Demo Council (not a real registration)', v.since,
       v.langs, 'verified', now(), 'de000000-0000-4000-8000-000000000001', v.bio, v.bio_bn
FROM (VALUES
  ('de000000-0000-4000-8000-0000000000d1', 'Dr. Demo Anwar Hossain', 'ডা. ডেমো আনোয়ার হোসেন', 'male',   'DEMO-0001', 2008, ARRAY['bn','en','hi'], 'Demo profile for testing. General physician.', 'পরীক্ষার জন্য ডেমো প্রোফাইল। সাধারণ চিকিৎসক।'),
  ('de000000-0000-4000-8000-0000000000d2', 'Dr. Demo Priya Sen',     'ডা. ডেমো প্রিয়া সেন',      'female', 'DEMO-0002', 2012, ARRAY['bn','en'],      'Demo profile for testing. Child specialist.', 'পরীক্ষার জন্য ডেমো প্রোফাইল। শিশু বিশেষজ্ঞ।'),
  ('de000000-0000-4000-8000-0000000000d3', 'Dr. Demo Rafiq Ahmed',   'ডা. ডেমো রফিক আহমেদ',     'male',   'DEMO-0003', 2005, ARRAY['bn','en','hi'], 'Demo profile for testing. Bone and joint specialist.', 'পরীক্ষার জন্য ডেমো প্রোফাইল। হাড় ও জয়েন্ট বিশেষজ্ঞ।'),
  ('de000000-0000-4000-8000-0000000000d4', 'Dr. Demo Moumita Das',   'ডা. ডেমো মৌমিতা দাস',      'female', 'DEMO-0004', 2010, ARRAY['bn','en'],      'Demo profile for testing. Gynaecologist.', 'পরীক্ষার জন্য ডেমো প্রোফাইল। স্ত্রীরোগ বিশেষজ্ঞ।'),
  ('de000000-0000-4000-8000-0000000000d5', 'Dr. Demo Sujoy Mondal',  'ডা. ডেমো সুজয় মণ্ডল',       'male',   'DEMO-0005', 2016, ARRAY['bn'],           'Demo profile for testing. ENT specialist.', 'পরীক্ষার জন্য ডেমো প্রোফাইল। নাক কান গলা বিশেষজ্ঞ।'),
  ('de000000-0000-4000-8000-0000000000d6', 'Dr. Demo Nasrin Begum',  'ডা. ডেমো নাসরিন বেগম',     'female', 'DEMO-0006', 2014, ARRAY['bn','en'],      'Demo profile for testing. Skin specialist.', 'পরীক্ষার জন্য ডেমো প্রোফাইল। চর্মরোগ বিশেষজ্ঞ।')
) AS v(id, name, name_bn, sex, reg, since, langs, bio, bio_bn);

INSERT INTO doctor_qualifications (doctor_id, degree, institution, year, is_verified) VALUES
  ('de000000-0000-4000-8000-0000000000d1', 'MBBS', 'Demo Medical College', 2007, true),
  ('de000000-0000-4000-8000-0000000000d2', 'MBBS', 'Demo Medical College', 2009, true),
  ('de000000-0000-4000-8000-0000000000d2', 'MD (Paediatrics)', 'Demo Medical College', 2012, true),
  ('de000000-0000-4000-8000-0000000000d3', 'MBBS', 'Demo Medical College', 2002, true),
  ('de000000-0000-4000-8000-0000000000d3', 'MS (Orthopaedics)', 'Demo Medical College', 2005, true),
  ('de000000-0000-4000-8000-0000000000d4', 'MBBS', 'Demo Medical College', 2006, true),
  ('de000000-0000-4000-8000-0000000000d4', 'MS (Obstetrics and Gynaecology)', 'Demo Medical College', 2010, true),
  ('de000000-0000-4000-8000-0000000000d5', 'MBBS', 'Demo Medical College', 2013, true),
  ('de000000-0000-4000-8000-0000000000d5', 'MS (ENT)', 'Demo Medical College', 2016, true),
  ('de000000-0000-4000-8000-0000000000d6', 'MBBS', 'Demo Medical College', 2011, true),
  ('de000000-0000-4000-8000-0000000000d6', 'MD (Dermatology)', 'Demo Medical College', 2014, true);

INSERT INTO doctor_specialities (doctor_id, speciality_id, is_primary)
SELECT v.d::uuid, s.id, true FROM (VALUES
  ('de000000-0000-4000-8000-0000000000d1', 'general-physician'),
  ('de000000-0000-4000-8000-0000000000d2', 'paediatrics'),
  ('de000000-0000-4000-8000-0000000000d3', 'orthopaedics'),
  ('de000000-0000-4000-8000-0000000000d4', 'gynaecology'),
  ('de000000-0000-4000-8000-0000000000d5', 'ent'),
  ('de000000-0000-4000-8000-0000000000d6', 'dermatology')
) AS v(d, slug) JOIN specialities s ON s.slug = v.slug;

-- Practices. Schedule states cover every case the UI must show:
-- confirmed, never confirmed (d5) and stale — confirmed 30 days ago (d6).
INSERT INTO doctor_practices (id, doctor_id, facility_id, consultation_fee_paise, booking_mode,
                              schedule_state, schedule_confirmed_at, schedule_confirmed_by)
VALUES
  ('de000000-0000-4000-8000-0000000000a1', 'de000000-0000-4000-8000-0000000000d1', 'de000000-0000-4000-8000-0000000000f1', 20000, 'serial_token', 'confirmed', now() - interval '2 days', 'de000000-0000-4000-8000-000000000001'),
  ('de000000-0000-4000-8000-0000000000a2', 'de000000-0000-4000-8000-0000000000d1', 'de000000-0000-4000-8000-0000000000f2', 30000, 'serial_token', 'confirmed', now() - interval '1 day',  'de000000-0000-4000-8000-000000000001'),
  ('de000000-0000-4000-8000-0000000000a3', 'de000000-0000-4000-8000-0000000000d2', 'de000000-0000-4000-8000-0000000000f5', 40000, 'time_slot',    'confirmed', now(),                     'de000000-0000-4000-8000-000000000001'),
  ('de000000-0000-4000-8000-0000000000a4', 'de000000-0000-4000-8000-0000000000d3', 'de000000-0000-4000-8000-0000000000f2', 50000, 'serial_token', 'confirmed', now() - interval '3 days', 'de000000-0000-4000-8000-000000000001'),
  ('de000000-0000-4000-8000-0000000000a5', 'de000000-0000-4000-8000-0000000000d4', 'de000000-0000-4000-8000-0000000000f3', 40000, 'serial_token', 'confirmed', now() - interval '1 day',  'de000000-0000-4000-8000-000000000001'),
  ('de000000-0000-4000-8000-0000000000a6', 'de000000-0000-4000-8000-0000000000d5', 'de000000-0000-4000-8000-0000000000f1', 30000, 'serial_token', 'unverified', NULL, NULL),
  ('de000000-0000-4000-8000-0000000000a7', 'de000000-0000-4000-8000-0000000000d6', 'de000000-0000-4000-8000-0000000000f5', 35000, 'serial_token', 'confirmed', now() - interval '30 days', 'de000000-0000-4000-8000-000000000001');

UPDATE doctor_practices SET department_id = (SELECT id FROM departments WHERE facility_id = 'de000000-0000-4000-8000-0000000000f2' AND name = 'Medicine')
 WHERE id = 'de000000-0000-4000-8000-0000000000a2';
UPDATE doctor_practices SET department_id = (SELECT id FROM departments WHERE facility_id = 'de000000-0000-4000-8000-0000000000f2' AND name = 'Orthopaedics')
 WHERE id = 'de000000-0000-4000-8000-0000000000a4';

-- Weekly templates (weekday: 0 = Sunday)
INSERT INTO schedule_templates (practice_id, weekday, shift_label, start_time, end_time, slot_minutes, capacity) VALUES
  ('de000000-0000-4000-8000-0000000000a1', 1, 'evening', '17:00', '20:00', NULL, 30),
  ('de000000-0000-4000-8000-0000000000a1', 4, 'evening', '17:00', '20:00', NULL, 30),
  ('de000000-0000-4000-8000-0000000000a2', 6, 'morning', '10:00', '13:00', NULL, 40),
  ('de000000-0000-4000-8000-0000000000a3', 1, 'morning', '10:00', '13:00', 15, 12),
  ('de000000-0000-4000-8000-0000000000a3', 2, 'morning', '10:00', '13:00', 15, 12),
  ('de000000-0000-4000-8000-0000000000a3', 3, 'morning', '10:00', '13:00', 15, 12),
  ('de000000-0000-4000-8000-0000000000a3', 4, 'morning', '10:00', '13:00', 15, 12),
  ('de000000-0000-4000-8000-0000000000a3', 5, 'morning', '10:00', '13:00', 15, 12),
  ('de000000-0000-4000-8000-0000000000a3', 6, 'morning', '10:00', '13:00', 15, 12),
  ('de000000-0000-4000-8000-0000000000a4', 2, 'morning', '11:00', '14:00', NULL, 25),
  ('de000000-0000-4000-8000-0000000000a4', 5, 'morning', '11:00', '14:00', NULL, 25),
  ('de000000-0000-4000-8000-0000000000a5', 3, 'evening', '16:00', '19:00', NULL, 20),
  ('de000000-0000-4000-8000-0000000000a5', 6, 'evening', '16:00', '19:00', NULL, 20),
  ('de000000-0000-4000-8000-0000000000a6', 2, 'evening', '18:00', '20:00', NULL, 20),
  ('de000000-0000-4000-8000-0000000000a7', 0, 'morning', '09:00', '12:00', NULL, 25);

-- Sittings for the next 14 days from the templates (Phase 4 adds the real generator).
INSERT INTO consultation_sessions (practice_id, template_id, session_date, starts_at, ends_at, booking_mode,
                                   slot_minutes, capacity, booking_closes_at)
SELECT t.practice_id, t.id, d::date,
       (d::date + t.start_time) AT TIME ZONE 'Asia/Kolkata',
       (d::date + t.end_time)   AT TIME ZONE 'Asia/Kolkata',
       p.booking_mode, t.slot_minutes, t.capacity,
       ((d::date + t.start_time) AT TIME ZONE 'Asia/Kolkata') - interval '30 minutes'
FROM schedule_templates t
JOIN doctor_practices p ON p.id = t.practice_id
JOIN doctors doc ON doc.id = p.doctor_id AND doc.is_demo
CROSS JOIN generate_series((now() AT TIME ZONE 'Asia/Kolkata')::date,
                           (now() AT TIME ZONE 'Asia/Kolkata')::date + 13, interval '1 day') AS d
WHERE extract(dow FROM d) = t.weekday;

-- Seats already taken at the chamber by phone and walk-in patients (demo),
-- so "few seats left" shows up.
UPDATE consultation_sessions SET active_count = capacity - 3, next_token = capacity - 2
 WHERE practice_id = 'de000000-0000-4000-8000-0000000000a5';
UPDATE consultation_sessions SET active_count = 12, next_token = 13
 WHERE practice_id = 'de000000-0000-4000-8000-0000000000a1';

-- Dr. Demo Rafiq is on leave for his next sitting: record the leave and cancel it.
INSERT INTO schedule_exceptions (doctor_id, practice_id, kind, starts_on, ends_on, reason_public, created_by)
SELECT 'de000000-0000-4000-8000-0000000000d3', 'de000000-0000-4000-8000-0000000000a4', 'leave',
       min(session_date), min(session_date), 'Doctor on leave', 'de000000-0000-4000-8000-000000000001'
FROM consultation_sessions WHERE practice_id = 'de000000-0000-4000-8000-0000000000a4';
UPDATE consultation_sessions SET status = 'cancelled', public_note = 'Doctor on leave'
 WHERE id = (SELECT id FROM consultation_sessions WHERE practice_id = 'de000000-0000-4000-8000-0000000000a4'
             ORDER BY starts_at LIMIT 1);

COMMIT;
