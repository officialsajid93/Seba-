-- Database rule tests. Run against a freshly migrated database:
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/tests/rules_test.sql
-- Every check raises (and stops the script) on failure; prints "ALL TESTS PASSED" on success.
BEGIN;

CREATE FUNCTION pg_temp.expect_error(stmt text, expected text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE stmt;
  RAISE EXCEPTION 'expected error "%" but statement succeeded: %', expected, stmt;
EXCEPTION WHEN OTHERS THEN
  IF SQLERRM NOT LIKE '%' || expected || '%' THEN
    RAISE EXCEPTION 'expected error "%" but got "%"', expected, SQLERRM;
  END IF;
END $$;

CREATE FUNCTION pg_temp.ok(cond boolean, label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF NOT cond THEN RAISE EXCEPTION 'FAILED: %', label; END IF; RAISE NOTICE 'ok - %', label; END $$;

-- ---------- seed ----------
INSERT INTO localities (id, name_en, name_bn, district, pincode, is_launched)
VALUES ('10000000-0000-0000-0000-000000000001','Test Town','টেস্ট শহর','Test District','742202', true);

INSERT INTO users (id, phone_e164, display_name) VALUES
 ('20000000-0000-0000-0000-000000000001','+919800000001','Patient A'),
 ('20000000-0000-0000-0000-000000000002','+919800000002','Patient B'),
 ('20000000-0000-0000-0000-000000000003','+919800000003','Verifier'),
 ('20000000-0000-0000-0000-000000000004','+919800000004','Pharmacist'),
 ('20000000-0000-0000-0000-000000000005','+919800000005','Facility admin');

INSERT INTO patients (id, account_user_id, relation, full_name) VALUES
 ('30000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','self','Patient A'),
 ('30000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001','parent','A''s mother'),
 ('30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002','self','Patient B');

INSERT INTO doctors (id, full_name, registration_number, registration_council, verification_status, verified_at, verified_by)
VALUES ('40000000-0000-0000-0000-000000000001','Dr Test','WB-12345','West Bengal Medical Council','verified', now(),
        '20000000-0000-0000-0000-000000000003');

INSERT INTO facilities (id, type, name, address_line, locality_id, verification_status, verified_at, is_published)
VALUES ('50000000-0000-0000-0000-000000000001','chamber','Test Chamber','Main Road','10000000-0000-0000-0000-000000000001',
        'verified', now(), true);

INSERT INTO doctor_practices (id, doctor_id, facility_id, consultation_fee_paise, booking_mode, schedule_state,
                              schedule_confirmed_at, schedule_confirmed_by)
VALUES ('60000000-0000-0000-0000-000000000001','40000000-0000-0000-0000-000000000001',
        '50000000-0000-0000-0000-000000000001', 30000, 'serial_token','confirmed', now(),
        '20000000-0000-0000-0000-000000000005');

-- serial-token session, capacity 2
INSERT INTO consultation_sessions (id, practice_id, session_date, starts_at, ends_at, booking_mode, capacity)
VALUES ('70000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000001',
        current_date + 1, (current_date + 1) + time '17:00', (current_date + 1) + time '20:00', 'serial_token', 2);
-- time-slot session 10:00-11:00, 15-min slots, capacity 4
INSERT INTO consultation_sessions (id, practice_id, session_date, starts_at, ends_at, booking_mode, slot_minutes, capacity)
VALUES ('70000000-0000-0000-0000-000000000002','60000000-0000-0000-0000-000000000001',
        current_date + 2, (current_date + 2) + time '10:00', (current_date + 2) + time '11:00', 'time_slot', 15, 4);

-- ---------- booking: serial tokens ----------
DO $$
DECLARE a1 appointments; a2 appointments; a3 appointments;
BEGIN
  a1 := book_appointment('70000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001');
  PERFORM pg_temp.ok(a1.token_number = 1, 'first booking gets token 1');
  PERFORM pg_temp.ok(a1.consultation_fee_paise = 30000, 'fee snapshot copied from practice');

  PERFORM pg_temp.expect_error($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001') $q$,
                               'ALREADY_BOOKED');
  PERFORM pg_temp.ok((SELECT active_count FROM consultation_sessions WHERE id='70000000-0000-0000-0000-000000000001') = 1,
                     'failed duplicate booking did not consume a seat');

  PERFORM pg_temp.expect_error($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000001') $q$,
                               'PATIENT_NOT_OWNED');

  a2 := book_appointment('70000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002');
  PERFORM pg_temp.expect_error($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001') $q$,
                               'SESSION_FULL');

  PERFORM cancel_appointment(a1.id, '20000000-0000-0000-0000-000000000001', false, 'cannot come');
  a3 := book_appointment('70000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001');
  PERFORM pg_temp.ok(a3.token_number = 3, 'token numbers are never reused after cancellation');
  PERFORM pg_temp.expect_error(format('SELECT cancel_appointment(%L, NULL, false, %L)', a1.id, 'again'), 'NOT_CANCELLABLE');
END $$;

-- ---------- booking: time slots + reschedule ----------
DO $$
DECLARE t0 timestamptz := (current_date + 2) + time '10:00'; a appointments; r appointments;
BEGIN
  a := book_appointment('70000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001', t0);
  PERFORM pg_temp.expect_error(format($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002', %L) $q$, t0),
                               'ALREADY_BOOKED');
  PERFORM pg_temp.expect_error(format($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002', %L) $q$, t0 + interval '7 minutes'),
                               'INVALID_SLOT');
  PERFORM pg_temp.expect_error(format($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002', %L) $q$, t0 + interval '60 minutes'),
                               'INVALID_SLOT');

  r := reschedule_appointment(a.id, '70000000-0000-0000-0000-000000000002', '20000000-0000-0000-0000-000000000001', t0 + interval '30 minutes');
  PERFORM pg_temp.ok(r.rescheduled_from_id = a.id, 'reschedule links new booking to old');
  PERFORM pg_temp.ok((SELECT status FROM appointments WHERE id = a.id) = 'rescheduled', 'old booking marked rescheduled');
  PERFORM pg_temp.ok((SELECT active_count FROM consultation_sessions WHERE id='70000000-0000-0000-0000-000000000002') = 1,
                     'reschedule within a session keeps one seat');
  -- freed 10:00 slot is bookable again
  PERFORM book_appointment('70000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002', t0);
  PERFORM pg_temp.ok(true, 'freed slot can be booked by someone else');
END $$;

-- ---------- availability gating ----------
DO $$
BEGIN
  UPDATE doctor_practices SET schedule_confirmed_at = now() - interval '30 days' WHERE id = '60000000-0000-0000-0000-000000000001';
  PERFORM pg_temp.expect_error($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001', (current_date + 2) + time '10:45') $q$,
                               'SESSION_NOT_BOOKABLE');
  PERFORM pg_temp.ok(EXISTS (SELECT 1 FROM stale_schedules WHERE practice_id = '60000000-0000-0000-0000-000000000001'),
                     'stale schedule is not bookable and appears on admin monitor');
  UPDATE doctor_practices SET schedule_confirmed_at = now() WHERE id = '60000000-0000-0000-0000-000000000001';

  UPDATE doctors SET verification_status = 'suspended' WHERE id = '40000000-0000-0000-0000-000000000001';
  PERFORM pg_temp.expect_error($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001', (current_date + 2) + time '10:45') $q$,
                               'SESSION_NOT_BOOKABLE');
  UPDATE doctors SET verification_status = 'verified' WHERE id = '40000000-0000-0000-0000-000000000001';

  PERFORM pg_temp.expect_error($q$ UPDATE facilities SET verification_status='rejected' WHERE id='50000000-0000-0000-0000-000000000001' $q$,
                               'check');
  PERFORM pg_temp.ok(true, 'a published facility cannot be un-verified without unpublishing');
END $$;

-- ---------- emergency session cancellation ----------
DO $$
DECLARE n int;
BEGIN
  SELECT count(*) INTO n FROM cancel_session('70000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000005','Doctor unavailable — emergency');
  PERFORM pg_temp.ok(n = 2, 'cancel_session cancels every live booking and returns them for notification');
  PERFORM pg_temp.ok(NOT EXISTS (SELECT 1 FROM appointments WHERE session_id='70000000-0000-0000-0000-000000000001'
                                  AND status IN ('confirmed','pending_payment')), 'no live bookings remain');
  PERFORM pg_temp.expect_error($q$ SELECT book_appointment('70000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000002') $q$,
                               'SESSION_NOT_BOOKABLE');
END $$;

-- ---------- pharmacy ----------
INSERT INTO pharmacies (id, legal_name, display_name, address_line, locality_id, pincode, retail_licence_no,
                        licence_valid_until, pharmacist_name, pharmacist_reg_no, accepts_online_orders,
                        verification_status, verified_at)
VALUES ('80000000-0000-0000-0000-000000000001','Test Medical Hall','Test Medical','Station Road',
        '10000000-0000-0000-0000-000000000001','742202','RL-0001', current_date + 365, 'Ph. Test','WBPC-999', true,
        'verified', now());
INSERT INTO user_roles (user_id, role, pharmacy_id)
VALUES ('20000000-0000-0000-0000-000000000004','pharmacist','80000000-0000-0000-0000-000000000001');

INSERT INTO medicines (id, brand_name, generic_name, strength, dosage_form, pack_size, schedule, mrp_paise) VALUES
 ('90000000-0000-0000-0000-000000000001','TestPara','Paracetamol','500 mg','tablet','15 tablets','otc', 3000),
 ('90000000-0000-0000-0000-000000000002','TestAmox','Amoxicillin','500 mg','capsule','10 capsules','H', 9000),
 ('90000000-0000-0000-0000-000000000003','TestRestricted','Restricted compound','1 mg','tablet','10 tablets','X', 5000);

INSERT INTO pharmacy_inventory (pharmacy_id, medicine_id, selling_price_paise, stock_qty) VALUES
 ('80000000-0000-0000-0000-000000000001','90000000-0000-0000-0000-000000000001', 2700, 50),
 ('80000000-0000-0000-0000-000000000001','90000000-0000-0000-0000-000000000002', 8500, 1);

DO $$
DECLARE rx uuid; o medicine_orders;
BEGIN
  PERFORM pg_temp.expect_error($q$ UPDATE pharmacy_inventory SET selling_price_paise = 3500 WHERE medicine_id='90000000-0000-0000-0000-000000000001' $q$,
                               'exceeds MRP');

  -- OTC-only order cannot sneak in an Rx drug
  INSERT INTO medicine_orders (id, order_code, user_id, patient_id, pharmacy_id, delivery_address, subtotal_paise)
  VALUES ('a0000000-0000-0000-0000-000000000001','M-OTC','20000000-0000-0000-0000-000000000001',
          '30000000-0000-0000-0000-000000000001','80000000-0000-0000-0000-000000000001','{"line1":"x"}', 5400);
  INSERT INTO medicine_order_items (order_id, medicine_id, quantity, unit_price_paise, schedule_snapshot)
  VALUES ('a0000000-0000-0000-0000-000000000001','90000000-0000-0000-0000-000000000001', 2, 2700, 'otc');
  PERFORM pg_temp.expect_error($q$ INSERT INTO medicine_order_items (order_id, medicine_id, quantity, unit_price_paise, schedule_snapshot)
                                   VALUES ('a0000000-0000-0000-0000-000000000001','90000000-0000-0000-0000-000000000002', 1, 8500, 'otc') $q$,
                               'prescription-only');
  PERFORM pg_temp.expect_error($q$ INSERT INTO medicine_order_items (order_id, medicine_id, quantity, unit_price_paise, schedule_snapshot)
                                   VALUES ('a0000000-0000-0000-0000-000000000001','90000000-0000-0000-0000-000000000003', 1, 5000, 'otc') $q$,
                               'cannot be sold online');

  -- Rx order needs a prescription attached
  PERFORM pg_temp.expect_error($q$ INSERT INTO medicine_orders (order_code, user_id, patient_id, pharmacy_id, requires_prescription, delivery_address, subtotal_paise)
                                   VALUES ('M-NORX','20000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',
                                           '80000000-0000-0000-0000-000000000001', true, '{}', 8500) $q$, 'check');

  INSERT INTO prescriptions (id, patient_id, uploaded_by, file_key, sha256, mime_type, size_bytes)
  VALUES ('b0000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001',
          '20000000-0000-0000-0000-000000000001','rx/test.jpg', repeat('a',64), 'image/jpeg', 12345)
  RETURNING id INTO rx;
  INSERT INTO medicine_orders (id, order_code, user_id, patient_id, pharmacy_id, prescription_id, requires_prescription,
                               status, delivery_address, subtotal_paise)
  VALUES ('a0000000-0000-0000-0000-000000000002','M-RX','20000000-0000-0000-0000-000000000001',
          '30000000-0000-0000-0000-000000000001','80000000-0000-0000-0000-000000000001', rx, true,
          'awaiting_rx_review','{"line1":"x"}', 8500);
  INSERT INTO medicine_order_items (order_id, medicine_id, quantity, unit_price_paise, schedule_snapshot)
  VALUES ('a0000000-0000-0000-0000-000000000002','90000000-0000-0000-0000-000000000002', 1, 8500, 'otc');
  PERFORM pg_temp.ok((SELECT schedule_snapshot FROM medicine_order_items WHERE order_id='a0000000-0000-0000-0000-000000000002') = 'H',
                     'schedule snapshot is set by the database, not trusted from the client');

  PERFORM pg_temp.expect_error($q$ SELECT accept_medicine_order('a0000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000004') $q$,
                               'RX_NOT_APPROVED');
  PERFORM pg_temp.expect_error($q$ SELECT accept_medicine_order('a0000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001') $q$,
                               'NOT_PHARMACIST_OF_PHARMACY');

  INSERT INTO prescription_reviews (prescription_id, order_id, pharmacist_user_id, pharmacist_reg_no, decision)
  VALUES (rx, 'a0000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000004','WBPC-999','approved');
  o := accept_medicine_order('a0000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000004');
  PERFORM pg_temp.ok(o.status = 'accepted', 'approved Rx order can be accepted');
  PERFORM pg_temp.ok((SELECT stock_qty FROM pharmacy_inventory WHERE medicine_id='90000000-0000-0000-0000-000000000002') = 0,
                     'stock decremented on acceptance');
  PERFORM pg_temp.ok(o.total_paise = 8500, 'order total computed by database');
END $$;

-- ---------- payments, reviews, audit ----------
DO $$
BEGIN
  PERFORM pg_temp.expect_error($q$ INSERT INTO payments (purpose, user_id, gateway, gateway_order_id, amount_paise, status)
                                   VALUES ('appointment','20000000-0000-0000-0000-000000000001','dev','ord_1', 1000, 'captured') $q$,
                               'check');
  PERFORM pg_temp.ok(true, 'payment cannot be marked captured without server-side signature verification');

  PERFORM pg_temp.expect_error($q$ INSERT INTO reviews (appointment_id, user_id, doctor_id, facility_id, rating)
                                   SELECT id, booked_by_user_id, '40000000-0000-0000-0000-000000000001','50000000-0000-0000-0000-000000000001', 5
                                   FROM appointments LIMIT 1 $q$, 'completed appointments');

  INSERT INTO audit_logs (action, entity_type) VALUES ('test.write','test');
  PERFORM pg_temp.expect_error($q$ UPDATE audit_logs SET action='tamper' $q$, 'append-only');
  PERFORM pg_temp.expect_error($q$ DELETE FROM audit_logs $q$, 'append-only');

  PERFORM pg_temp.expect_error($q$ INSERT INTO users (phone_e164) VALUES ('9800000009') $q$, 'check');
  PERFORM pg_temp.expect_error($q$ INSERT INTO user_roles (user_id, role) VALUES ('20000000-0000-0000-0000-000000000004','pharmacist') $q$, 'check');
  PERFORM pg_temp.ok(true, 'scoped roles must name their pharmacy/facility');
END $$;

DO $$ BEGIN RAISE NOTICE 'ALL TESTS PASSED'; END $$;
ROLLBACK;
