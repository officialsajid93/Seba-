# Seba — Healthcare Booking & Pharmacy Platform

Working name "Seba" (সেবা). Change it in one place: `NEXT_PUBLIC_BRAND_NAME` / `src/config/brand.ts`.

Status: **Phase 2 done.** The database foundation (Phase 1) plus the app shell: design system,
Bengali/English navigation, every screen's route, database connection, migration runner and
dev-mode adapters for SMS, payments, file storage and maps. Real listings, OTP login and
booking arrive in Phases 3–4.

## Quick start

Requires Node 22+ and PostgreSQL 15+.

```bash
npm install
cp .env.example .env.local          # then set DATABASE_URL and SESSION_SECRET
npm run db:migrate                   # creates all tables
npm run dev                          # http://localhost:3000 → redirects to /bn
```

Open `/bn/design-system` in development to see every component and state.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Development server |
| `npm run build` / `npm start` | Production build / server |
| `npm run check` | Lint + typecheck + unit tests |
| `npm run db:migrate` / `db:status` | Apply / list migrations (checksummed; an edited applied migration is refused) |
| `npm run test:db` | Booking and pharmacy rule tests + booking race test (**wipes data — throwaway DB only**) |
| `npm run test:e2e` | Browser smoke test: every screen in both languages on a phone-size screen, axe accessibility, redirects, language switch, health check (needs a running server, `BASE_URL`) |

## Folder structure

```
db/migrations/            SQL migrations (schema, booking + order functions)
db/tests/                 SQL rule tests and the booking race test
scripts/migrate.ts        migration runner
src/proxy.ts              adds the language prefix (/bn or /en) to every page URL
src/instrumentation.ts    validates configuration when the server boots
src/app/[lang]/           all screens, one folder per route
src/app/api/health        uptime + database check
src/app/api/files         private files via short-lived signed links only
src/components/ui         design system: buttons, cards, fields, badges, availability, states
src/components/layout     top bar, bottom navigation, language switch
src/i18n/                 bn.json, en.json, locale helpers (Hindi wired in, not switched on)
src/lib/env*.ts           environment validation
src/lib/db.ts             PostgreSQL pool, transactions, database error codes
src/lib/adapters/         SMS, payments, storage, maps — each with a labelled dev mode
tests/unit, tests/e2e     Vitest unit tests, Playwright smoke test
```

## Outside services and dev mode

Every service defaults to dev mode and the app shows a "Test mode" strip:

- **SMS** — messages are logged with the number masked; nothing is sent. Real provider: Phase 7 (needs DLT-registered sender ID and templates).
- **Payments** — simulated gateway, order IDs start with `test_`. Razorpay order creation and signature checks are implemented and unit-tested.
- **File storage** — local private folder, served only through signed links that expire in ≤15 minutes. S3-compatible storage: Phase 6.
- **Maps** — no API key: directions open Google Maps; OpenStreetMap as fallback.

**Production refuses to start with any dev adapter.** For a staging site that must never take
real users, set `ALLOW_DEV_ADAPTERS_IN_PRODUCTION=true`.

## Adding Hindi

1. Add `src/i18n/dictionaries/hi.json` with every key from `en.json` (the unit tests check parity).
2. Add `hi` to `activeLocales` in `src/i18n/config.ts` and a loader in `src/i18n/dictionaries.ts`.

## Conventions

- Money in paise (`bigint`), never floating point. Times as `timestamptz`, shown in Asia/Kolkata.
- No secrets in code. Prescriptions never get a public URL. `audit_logs` is append-only.
- Colour tokens are checked against WCAG AA by a unit test.

Not legal advice: policies and compliance need review by a lawyer before launch.
