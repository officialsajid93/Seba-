import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterAll, describe, expect, it } from "vitest";
import { DevPaymentAdapter, RazorpayAdapter, hmacHex } from "@/lib/adapters/payments";
import { LocalDevStorage, assertKey, signPath, sniffMime, verifySignedPath } from "@/lib/adapters/storage";
import { renderSms, smsTemplateKeys } from "@/lib/adapters/sms-templates";
import { maskPhone } from "@/lib/adapters/sms";
import { directionsUrl, distanceKm } from "@/lib/adapters/maps";
import { domainErrorCode } from "@/lib/db";

describe("payments", () => {
  const rp = new RazorpayAdapter("key_id", "key_secret", "hook_secret");

  it("accepts only a correct gateway signature", () => {
    const sig = hmacHex("key_secret", "order_1|pay_1");
    expect(rp.verifyPayment({ gatewayOrderId: "order_1", gatewayPaymentId: "pay_1", signature: sig })).toBe(true);
    expect(rp.verifyPayment({ gatewayOrderId: "order_1", gatewayPaymentId: "pay_2", signature: sig })).toBe(false);
    expect(rp.verifyPayment({ gatewayOrderId: "order_1", gatewayPaymentId: "pay_1", signature: "zz" })).toBe(false);
    expect(rp.verifyPayment({ gatewayOrderId: "order_1", gatewayPaymentId: "pay_1", signature: "" })).toBe(false);
  });

  it("verifies webhooks against the raw body", () => {
    const body = '{"event":"payment.captured"}';
    expect(rp.verifyWebhook(body, hmacHex("hook_secret", body))).toBe(true);
    expect(rp.verifyWebhook(body + " ", hmacHex("hook_secret", body))).toBe(false);
  });

  it("dev gateway marks orders as test and still verifies signatures", async () => {
    const dev = new DevPaymentAdapter("dev-secret");
    const order = await dev.createOrder({ amountPaise: 30000, receipt: "r1" });
    expect(order.isTest).toBe(true);
    expect(order.gatewayOrderId.startsWith("test_order_")).toBe(true);
    const paid = dev.simulatePayment(order.gatewayOrderId);
    expect(dev.verifyPayment({ gatewayOrderId: order.gatewayOrderId, ...paid })).toBe(true);
    expect(dev.verifyPayment({ gatewayOrderId: "order_real", ...paid })).toBe(false);
  });

  it("rejects fractional or tiny amounts", async () => {
    const dev = new DevPaymentAdapter("s");
    await expect(dev.createOrder({ amountPaise: 99.5, receipt: "r" })).rejects.toThrow();
    await expect(dev.createOrder({ amountPaise: 50, receipt: "r" })).rejects.toThrow();
  });
});

describe("private file storage", () => {
  const pdf = new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x34]);
  const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const exe = new Uint8Array([0x4d, 0x5a, 0x90, 0x00]);
  let dir = "";

  afterAll(async () => {
    if (dir) await rm(dir, { recursive: true, force: true });
  });

  it("detects file type from bytes, not the name", () => {
    expect(sniffMime(pdf)).toBe("application/pdf");
    expect(sniffMime(png)).toBe("image/png");
    expect(sniffMime(exe)).toBeNull();
  });

  it("rejects unsafe keys", () => {
    expect(() => assertKey("rx/u1/abc.pdf")).not.toThrow();
    for (const bad of ["../etc/passwd", "rx/../../x.pdf", "/rx/a.pdf", "rx/a.exe", "public/a.pdf", "rx//a.pdf"]) {
      expect(() => assertKey(bad), bad).toThrow();
    }
  });

  it("signed links expire and cannot be altered", () => {
    const exp = Math.floor(Date.now() / 1000) + 60;
    const sig = signPath("s", "rx/a.pdf", exp);
    expect(verifySignedPath("s", "rx/a.pdf", exp, sig)).toBe(true);
    expect(verifySignedPath("s", "rx/b.pdf", exp, sig)).toBe(false);
    expect(verifySignedPath("s", "rx/a.pdf", exp + 1, sig)).toBe(false);
    expect(verifySignedPath("other", "rx/a.pdf", exp, sig)).toBe(false);
    expect(verifySignedPath("s", "rx/a.pdf", exp, sig, (exp + 1) * 1000)).toBe(false);
  });

  it("stores, reads and refuses non-documents", async () => {
    dir = await mkdtemp(path.join(os.tmpdir(), "seba-store-"));
    const store = new LocalDevStorage(dir, "s");
    const saved = await store.put("rx/u1/test.pdf", pdf);
    expect(saved.mime).toBe("application/pdf");
    expect(saved.sha256).toMatch(/^[0-9a-f]{64}$/);
    expect(await store.get("rx/u1/test.pdf")).toEqual(pdf);
    await expect(store.put("rx/u1/virus.pdf", exe)).rejects.toThrow(/Only PDF/);
    expect(store.signedUrl("rx/u1/test.pdf")).toMatch(/^\/api\/files\/rx\/u1\/test\.pdf\?exp=\d+&sig=[0-9a-f]{64}$/);
  });
});

describe("sms", () => {
  it("every template renders in both languages with no leftover placeholders", () => {
    const vars = { code: "123456", brand: "Seba", doctor: "Dr X", place: "Dhuliyan", date: "21 Oct", time: "5 pm", serial: 7 };
    for (const key of smsTemplateKeys) {
      for (const lang of ["bn", "en"] as const) expect(renderSms(key, lang, vars)).not.toMatch(/\{\w+\}/);
    }
  });
  it("masks phone numbers in logs", () => {
    expect(maskPhone("+919812345678")).toBe("+91******5678");
  });
});

describe("maps", () => {
  it("builds a directions link and rejects bad coordinates", () => {
    expect(directionsUrl(24.68, 87.95)).toBe("https://www.google.com/maps/dir/?api=1&destination=24.680000,87.950000");
    expect(() => directionsUrl(200, 0)).toThrow();
  });
  it("computes distance", () => {
    // One degree of latitude is about 111.2 km anywhere on Earth.
    expect(distanceKm({ lat: 24, lng: 88 }, { lat: 25, lng: 88 })).toBeCloseTo(111.2, 0);
    expect(distanceKm({ lat: 24.5, lng: 88 }, { lat: 24.5, lng: 88 })).toBe(0);
  });
});

describe("database error mapping", () => {
  it("maps SQL business errors to codes and ignores others", () => {
    expect(domainErrorCode({ code: "P0001", message: "SESSION_FULL" })).toBe("SESSION_FULL");
    expect(domainErrorCode({ code: "P0001", message: "OUT_OF_STOCK:abc" })).toBe("OUT_OF_STOCK");
    expect(domainErrorCode({ code: "23505", message: "duplicate key" })).toBeNull();
    expect(domainErrorCode({ code: "P0001", message: "SOMETHING_ELSE" })).toBeNull();
  });
});
