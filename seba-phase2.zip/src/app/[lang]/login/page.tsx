import type { Metadata } from "next";
import { Info } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { Button, Card, Field, Input } from "@/components/ui/primitives";
import { Notice } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.login.title };
}

// Phase 3 wires this form to OTP send/verify. The layout and field rules are final.
export default async function LoginPage() {
  const t = await getDictionary();
  const s = t.screens.login;
  return (
    <div className="space-y-4">
      <PageHeader title={s.title} />
      <Card>
        <form className="space-y-4">
          <Field id="phone" label={s.phoneLabel} hint={s.phoneHint}>
            <div className="flex gap-2">
              <span className="grid min-h-12 place-items-center rounded-control bg-canvas px-3 font-semibold text-muted ring-1 ring-inset ring-line">
                +91
              </span>
              <Input
                id="phone"
                name="phone"
                type="tel"
                inputMode="numeric"
                autoComplete="tel-national"
                pattern="[6-9][0-9]{9}"
                maxLength={10}
                placeholder="98XXXXXXXX"
                aria-describedby="phone-hint"
                required
              />
            </div>
          </Field>
          <Button type="submit" full disabled>
            {s.sendCode}
          </Button>
        </form>
      </Card>
      <Notice tone="info" icon={<Info className="size-5" />}>
        {s.comingSoon}
      </Notice>
    </div>
  );
}
