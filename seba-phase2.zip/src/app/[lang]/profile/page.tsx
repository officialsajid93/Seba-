import type { Metadata } from "next";
import Link from "next/link";
import { ChevronRight, CircleHelp, FileText, Heart, Languages, LogIn, Pill, Users } from "lucide-react";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { ButtonLink, Card } from "@/components/ui/primitives";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.profile.title };
}

export default async function ProfilePage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  const s = t.screens.profile;
  const rows = [
    { href: `/${lang}/login`, Icon: Users, label: s.family },
    { href: `/${lang}/login`, Icon: Heart, label: s.saved },
    { href: `/${lang}/login`, Icon: Pill, label: s.orders },
    { href: `/${lang === "bn" ? "en" : "bn"}/profile`, Icon: Languages, label: `${s.language}: ${t.lang.name}` },
    { href: `/${lang}/help`, Icon: CircleHelp, label: s.help },
    { href: `/${lang}/legal/privacy`, Icon: FileText, label: s.policies },
  ];
  return (
    <div className="space-y-4">
      <PageHeader title={s.title} />
      <Card className="space-y-3 text-center">
        <div className="mx-auto grid size-14 place-items-center rounded-full bg-brand-50 text-brand-600" aria-hidden>
          <LogIn className="size-7" />
        </div>
        <h2 className="text-lg font-semibold">{s.signedOutTitle}</h2>
        <p className="text-muted">{s.signedOutBody}</p>
        <ButtonLink href={`/${lang}/login`} full>
          {t.screens.login.title}
        </ButtonLink>
      </Card>
      <Card className="p-0">
        <ul className="divide-y divide-line">
          {rows.map(({ href, Icon, label }) => (
            <li key={label}>
              <Link href={href} className="flex min-h-14 items-center gap-3 px-4 hover:bg-canvas">
                <Icon className="size-5 text-brand-600" aria-hidden />
                <span className="flex-1 font-medium">{label}</span>
                <ChevronRight className="size-5 text-subtle" aria-hidden />
              </Link>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
