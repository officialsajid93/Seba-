import type { Metadata } from "next";
import { BedDouble } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { DirectoryScreen } from "@/components/layout/DirectoryScreen";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.nursingHomes.title };
}

export default function Page() {
  return <DirectoryScreen section="nursingHomes" icon={<BedDouble className="size-7" />} />;
}
