import type { Metadata } from "next";
import { Hospital } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { DirectoryScreen } from "@/components/layout/DirectoryScreen";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.hospitals.title };
}

export default function Page() {
  return <DirectoryScreen section="hospitals" icon={<Hospital className="size-7" />} />;
}
