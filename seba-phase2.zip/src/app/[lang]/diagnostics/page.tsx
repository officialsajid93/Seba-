import type { Metadata } from "next";
import { FlaskConical } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { DirectoryScreen } from "@/components/layout/DirectoryScreen";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.diagnostics.title };
}

export default function Page() {
  return <DirectoryScreen section="diagnostics" icon={<FlaskConical className="size-7" />} />;
}
