import type { Metadata } from "next";
import { CalendarCheck } from "lucide-react";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { ButtonLink, Card } from "@/components/ui/primitives";
import { EmptyState } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.bookings.title };
}

export default async function BookingsPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  const s = t.screens.bookings;
  return (
    <div className="space-y-4">
      <PageHeader title={s.title} />
      <Card className="p-0">
        <EmptyState
          icon={<CalendarCheck className="size-7" />}
          title={s.emptyTitle}
          body={s.emptyBody}
          action={<ButtonLink href={`/${lang}/doctors`}>{s.findDoctor}</ButtonLink>}
        />
      </Card>
    </div>
  );
}
