import type { Metadata } from "next";
import { Stethoscope } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { DirectoryScreen } from "@/components/layout/DirectoryScreen";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.doctors.title };
}

export default function Page() {
  return <DirectoryScreen section="doctors" icon={<Stethoscope className="size-7" />} />;
}
