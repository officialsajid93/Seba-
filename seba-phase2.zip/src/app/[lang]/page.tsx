import { Suspense } from "react";
import { Phone, ShieldCheck, Stethoscope } from "lucide-react";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { SearchBar } from "@/components/home/SearchBar";
import { CategoryGrid } from "@/components/home/CategoryGrid";
import { TownChip, TownChipFallback } from "@/components/home/TownChip";
import { Card } from "@/components/ui/primitives";
import { EmptyState, Notice } from "@/components/ui/states";

export default async function HomePage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div className="space-y-6">
      <section className="space-y-3">
        <Suspense fallback={<TownChipFallback lang={lang} label={t.location.label} choose={t.location.choose} />}>
          <TownChip lang={lang} label={t.location.label} choose={t.location.choose} />
        </Suspense>
        <h1 className="text-2xl font-bold leading-snug tracking-tight text-ink">{t.meta.tagline}</h1>
        <SearchBar
          lang={lang}
          placeholder={t.search.placeholder}
          label={t.search.label}
          buttonLabel={t.search.button}
        />
      </section>

      <CategoryGrid lang={lang} t={t.categories} />

      <Notice tone="ok" icon={<ShieldCheck className="size-5" />}>
        {t.home.trust}
      </Notice>

      <section aria-labelledby="nearby-title">
        <h2 id="nearby-title" className="mb-3 text-lg font-semibold text-ink">
          {t.home.nearby}
        </h2>
        <Card className="p-0">
          <EmptyState
            icon={<Stethoscope className="size-7" />}
            title={t.screens.doctors.emptyTitle}
            body={t.screens.doctors.emptyBody}
          />
        </Card>
      </section>

      <Notice tone="bad" icon={<Phone className="size-5" />}>
        <p>{t.home.emergency}</p>
        <a href="tel:108" className="mt-1 inline-block min-h-10 py-2 font-semibold underline underline-offset-2">
          {t.home.callEmergency}
        </a>
      </Notice>
    </div>
  );
}
