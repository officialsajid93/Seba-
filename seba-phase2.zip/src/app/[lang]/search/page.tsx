import type { Metadata } from "next";
import { Suspense } from "react";
import { Search } from "lucide-react";
import { format } from "@/i18n/config";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { SearchBar } from "@/components/home/SearchBar";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).search.label, robots: { index: false } };
}

async function Results({
  searchParams,
  t,
  lang,
}: {
  searchParams: PageProps<"/[lang]/search">["searchParams"];
  t: Dictionary;
  lang: string;
}) {
  const raw = (await searchParams).q;
  const q = (Array.isArray(raw) ? raw[0] : raw)?.trim().slice(0, 80) ?? "";
  return (
    <div className="space-y-4">
      <SearchBar
        lang={lang}
        defaultValue={q}
        placeholder={t.search.placeholder}
        label={t.search.label}
        buttonLabel={t.search.button}
      />
      {q ? (
        <>
          <h2 className="font-semibold text-muted">{format(t.search.resultsFor, { query: q })}</h2>
          {/* Phase 3 replaces this with real results from verified listings. */}
          <Card className="p-0">
            <EmptyState icon={<Search className="size-7" />} title={t.screens.doctors.emptyTitle} body={t.screens.doctors.emptyBody} />
          </Card>
        </>
      ) : (
        <p className="text-muted">{t.search.noQuery}</p>
      )}
    </div>
  );
}

export default async function SearchPage({ searchParams }: PageProps<"/[lang]/search">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.search.label} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <Results searchParams={searchParams} t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
