// SMS wording in both languages. In India each template must also be
// registered with the SMS provider before real sending; keep these in sync.
import { format } from "@/i18n/config";

const templates = {
  otp: {
    bn: "আপনার লগ ইন কোড {code}। ১০ মিনিট বৈধ। কাউকে এই কোড বলবেন না। - {brand}",
    en: "Your login code is {code}. Valid for 10 minutes. Do not share it with anyone. - {brand}",
  },
  booking_confirmed: {
    bn: "বুকিং নিশ্চিত: {doctor}, {place}, {date} {time}। সিরিয়াল {serial}। বুকিং আইডি {code}। - {brand}",
    en: "Booking confirmed: {doctor}, {place}, {date} {time}. Serial {serial}. Booking ID {code}. - {brand}",
  },
  session_cancelled: {
    bn: "দুঃখিত, {doctor} {date} তারিখে বসবেন না। আপনার বুকিং {code} বাতিল হয়েছে। - {brand}",
    en: "Sorry, {doctor} will not sit on {date}. Your booking {code} is cancelled. - {brand}",
  },
  reminder: {
    bn: "মনে করিয়ে দিচ্ছি: কাল {time}-এ {doctor}, {place}। সিরিয়াল {serial}। - {brand}",
    en: "Reminder: {doctor} at {place} tomorrow {time}. Serial {serial}. - {brand}",
  },
} as const;

export type SmsTemplateKey = keyof typeof templates;

export function renderSms(key: SmsTemplateKey, lang: "bn" | "en", vars: Record<string, string | number>): string {
  return format(templates[key][lang], vars);
}

export const smsTemplateKeys = Object.keys(templates) as SmsTemplateKey[];
