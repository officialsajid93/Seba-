import type { ReactNode } from "react";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { SearchBar } from "@/components/home/SearchBar";
import { PageHeader } from "./PageHeader";
import { Card } from "@/components/ui/primitives";
import { EmptyState } from "@/components/ui/states";

type Section = "doctors" | "hospitals" | "nursingHomes" | "diagnostics";

// Shared shell for the four directory screens. Listings arrive in Phase 3;
// until a provider is verified the honest state is "none yet".
export async function DirectoryScreen({ section, icon }: { section: Section; icon: ReactNode }) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  const s = t.screens[section];
  return (
    <div className="space-y-4">
      <PageHeader title={s.title} />
      <SearchBar lang={lang} placeholder={t.search.placeholder} label={t.search.label} buttonLabel={t.search.button} />
      <Card className="p-0">
        <EmptyState icon={icon} title={s.emptyTitle} body={s.emptyBody} />
      </Card>
    </div>
  );
}
