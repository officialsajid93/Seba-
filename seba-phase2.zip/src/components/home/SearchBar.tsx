import { Search } from "lucide-react";

// Plain GET form: works before JavaScript loads and on very slow connections.
export function SearchBar({
  lang,
  placeholder,
  label,
  buttonLabel,
  defaultValue,
}: {
  lang: string;
  placeholder: string;
  label: string;
  buttonLabel: string;
  defaultValue?: string;
}) {
  return (
    <form action={`/${lang}/search`} method="get" role="search" className="relative">
      <label htmlFor="q" className="sr-only">
        {label}
      </label>
      <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-subtle" aria-hidden />
      <input
        id="q"
        name="q"
        type="search"
        defaultValue={defaultValue}
        placeholder={placeholder}
        enterKeyHint="search"
        autoComplete="off"
        maxLength={80}
        className="block min-h-14 w-full rounded-2xl bg-white pl-12 pr-24 text-base text-ink shadow-card ring-1 ring-inset ring-line placeholder:text-subtle focus:outline-none focus:ring-2 focus:ring-brand-500"
      />
      <button
        type="submit"
        className="absolute right-2 top-1/2 min-h-10 -translate-y-1/2 rounded-xl bg-brand-600 px-4 text-sm font-semibold text-white hover:bg-brand-700"
      >
        {buttonLabel}
      </button>
    </form>
  );
}
