// Runs once when the server starts. Validates configuration up front so a
// misconfigured deploy (for example dev adapters in production) fails at boot
// instead of on a patient's first request.
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  if (process.env.NEXT_PHASE === "phase-production-build") return;
  const { env } = await import("./lib/env-schema");
  env();
}
