import "server-only";
import { createHash } from "node:crypto";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { env } from "../env";
import { hmacHex, safeEqualHex } from "./payments";

// Private files: prescriptions and verification documents. Nothing is ever
// public; access is only through short-lived signed links checked on the server.

export const ALLOWED_MIME = ["application/pdf", "image/jpeg", "image/png", "image/webp"] as const;
export type AllowedMime = (typeof ALLOWED_MIME)[number];
export const MAX_BYTES = 10 * 1024 * 1024;

const KEY_RE = /^(rx|verification|avatars)\/[a-z0-9][a-z0-9/_-]{0,180}\.(pdf|jpg|png|webp)$/;

export function assertKey(key: string): void {
  if (!KEY_RE.test(key) || key.includes("..") || key.includes("//")) throw new Error("Invalid storage key");
}

// Check real file bytes, not the name or the browser's claim.
export function sniffMime(bytes: Uint8Array): AllowedMime | null {
  const b = bytes;
  if (b[0] === 0x25 && b[1] === 0x50 && b[2] === 0x44 && b[3] === 0x46) return "application/pdf"; // %PDF
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "image/jpeg";
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "image/png";
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) return "image/webp";
  return null;
}

export type StoredObject = { key: string; sha256: string; sizeBytes: number; mime: AllowedMime };

export interface StorageAdapter {
  readonly name: string;
  readonly isDev: boolean;
  put(key: string, bytes: Uint8Array): Promise<StoredObject>;
  get(key: string): Promise<Uint8Array>;
  remove(key: string): Promise<void>;
  /** Link valid for ttlSeconds (max 15 minutes). */
  signedUrl(key: string, ttlSeconds?: number): string;
}

export function validateUpload(bytes: Uint8Array): AllowedMime {
  if (bytes.byteLength === 0) throw new Error("Empty file");
  if (bytes.byteLength > MAX_BYTES) throw new Error("File is larger than 10 MB");
  const mime = sniffMime(bytes);
  if (!mime) throw new Error("Only PDF, JPEG, PNG or WebP files are allowed");
  return mime;
}

export function signPath(secret: string, key: string, expiresAt: number): string {
  return hmacHex(secret, `${key}\n${expiresAt}`);
}

export function verifySignedPath(secret: string, key: string, expiresAt: number, sig: string, nowMs = Date.now()): boolean {
  if (!Number.isFinite(expiresAt) || expiresAt * 1000 < nowMs) return false;
  return safeEqualHex(signPath(secret, key, expiresAt), sig);
}

export class LocalDevStorage implements StorageAdapter {
  readonly name = "dev-local";
  readonly isDev = true;
  constructor(
    private root: string,
    private secret: string,
  ) {}

  private file(key: string) {
    assertKey(key);
    const full = path.resolve(this.root, key);
    if (!full.startsWith(path.resolve(this.root) + path.sep)) throw new Error("Invalid storage key");
    return full;
  }

  async put(key: string, bytes: Uint8Array): Promise<StoredObject> {
    const mime = validateUpload(bytes);
    const full = this.file(key);
    await mkdir(path.dirname(full), { recursive: true });
    await writeFile(full, bytes, { mode: 0o600 });
    return { key, mime, sizeBytes: bytes.byteLength, sha256: createHash("sha256").update(bytes).digest("hex") };
  }

  async get(key: string) {
    return new Uint8Array(await readFile(this.file(key)));
  }

  async remove(key: string) {
    await rm(this.file(key), { force: true });
  }

  signedUrl(key: string, ttlSeconds = 300) {
    assertKey(key);
    const exp = Math.floor(Date.now() / 1000) + Math.min(Math.max(ttlSeconds, 30), 900);
    const sig = signPath(this.secret, key, exp);
    return `/api/files/${key}?exp=${exp}&sig=${sig}`;
  }
}

let instance: StorageAdapter | undefined;

export function storageSigningSecret(): string {
  return hmacHex(env().SESSION_SECRET, "file-links");
}

export function storage(): StorageAdapter {
  if (instance) return instance;
  const e = env();
  if (e.STORAGE_DRIVER === "dev-local") {
    return (instance = new LocalDevStorage(path.resolve(e.STORAGE_LOCAL_DIR), storageSigningSecret()));
  }
  // S3-compatible storage arrives with the prescription upload work (Phase 6).
  throw new Error(`Storage driver "${e.STORAGE_DRIVER}" is configured but not implemented yet (Phase 6).`);
}
