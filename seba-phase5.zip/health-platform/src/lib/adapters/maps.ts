// Maps without an API key: a directions link that opens Google Maps (app or
// web) on the patient's phone, and an OpenStreetMap link as a fallback.
export function directionsUrl(lat: number, lng: number): string {
  assertCoords(lat, lng);
  return `https://www.google.com/maps/dir/?api=1&destination=${lat.toFixed(6)},${lng.toFixed(6)}`;
}

export function osmUrl(lat: number, lng: number, zoom = 17): string {
  assertCoords(lat, lng);
  return `https://www.openstreetmap.org/?mlat=${lat.toFixed(6)}&mlon=${lng.toFixed(6)}#map=${zoom}/${lat.toFixed(6)}/${lng.toFixed(6)}`;
}

// Great-circle distance in km, for "2.4 km away" and pharmacy delivery radius.
export function distanceKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371;
  const rad = (d: number) => (d * Math.PI) / 180;
  const dLat = rad(b.lat - a.lat);
  const dLng = rad(b.lng - a.lng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function assertCoords(lat: number, lng: number) {
  if (!(lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180)) throw new Error("Invalid coordinates");
}
