import "server-only";
import { env } from "../env";
import { renderSms, type SmsTemplateKey } from "./sms-templates";

export type SmsResult = { status: "sent" | "dev_logged"; providerMessageId: string | null; text: string };

export interface SmsAdapter {
  readonly name: string;
  readonly isDev: boolean;
  send(input: { to: string; template: SmsTemplateKey; lang: "bn" | "en"; vars: Record<string, string | number> }): Promise<SmsResult>;
}

export const maskPhone = (e164: string) => e164.replace(/^(\+\d{2})\d{6}(\d{4})$/, "$1******$2");

// Dev mode: nothing leaves the server. The message is logged with the number
// masked, and callers record it with status 'dev_logged'.
class DevSmsAdapter implements SmsAdapter {
  readonly name = "dev";
  readonly isDev = true;
  async send({ to, template, lang, vars }: Parameters<SmsAdapter["send"]>[0]): Promise<SmsResult> {
    const text = renderSms(template, lang, vars);
    const shown = template === "otp" ? text.replace(/\d{6}/, "[code hidden]") : text;
    console.info(`[DEV SMS — NOT SENT] to ${maskPhone(to)}: ${shown}`);
    return { status: "dev_logged", providerMessageId: null, text };
  }
}

let instance: SmsAdapter | undefined;

export function sms(): SmsAdapter {
  if (instance) return instance;
  const provider = env().SMS_PROVIDER;
  if (provider === "dev") return (instance = new DevSmsAdapter());
  // Real provider is wired in Phase 7, once the DLT sender ID and templates are
  // registered. Failing loudly beats silently pretending to send.
  throw new Error(`SMS provider "${provider}" is configured but its adapter is not implemented yet (Phase 7).`);
}
