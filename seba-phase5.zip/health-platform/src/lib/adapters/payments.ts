import "server-only";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { env } from "../env";

export type CreatedOrder = {
  gateway: "dev" | "razorpay";
  gatewayOrderId: string;
  amountPaise: number;
  currency: "INR";
  isTest: boolean;
};

export interface PaymentAdapter {
  readonly name: "dev" | "razorpay";
  readonly isDev: boolean;
  createOrder(input: { amountPaise: number; receipt: string }): Promise<CreatedOrder>;
  /** Checkout callback: true only if the gateway really signed this order+payment. */
  verifyPayment(input: { gatewayOrderId: string; gatewayPaymentId: string; signature: string }): boolean;
  /** Webhook: verify the raw request body against the signature header. */
  verifyWebhook(rawBody: string, signature: string): boolean;
}

export function hmacHex(secret: string, data: string): string {
  return createHmac("sha256", secret).update(data).digest("hex");
}

export function safeEqualHex(a: string, b: string): boolean {
  if (!/^[0-9a-f]+$/i.test(a) || !/^[0-9a-f]+$/i.test(b) || a.length !== b.length) return false;
  return timingSafeEqual(Buffer.from(a, "hex"), Buffer.from(b, "hex"));
}

function assertAmount(amountPaise: number) {
  if (!Number.isInteger(amountPaise) || amountPaise < 100) {
    throw new Error("amountPaise must be a whole number of paise, at least ₹1");
  }
}

// Razorpay: order creation + HMAC-SHA256 signature checks, done on the server.
export class RazorpayAdapter implements PaymentAdapter {
  readonly name = "razorpay" as const;
  readonly isDev = false;
  constructor(
    private keyId: string,
    private keySecret: string,
    private webhookSecret: string,
  ) {}

  async createOrder({ amountPaise, receipt }: { amountPaise: number; receipt: string }): Promise<CreatedOrder> {
    assertAmount(amountPaise);
    const res = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(`${this.keyId}:${this.keySecret}`).toString("base64")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ amount: amountPaise, currency: "INR", receipt: receipt.slice(0, 40) }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) throw new Error(`Payment gateway refused the order (HTTP ${res.status})`);
    const body = (await res.json()) as { id: string };
    return { gateway: "razorpay", gatewayOrderId: body.id, amountPaise, currency: "INR", isTest: false };
  }

  verifyPayment({ gatewayOrderId, gatewayPaymentId, signature }: Parameters<PaymentAdapter["verifyPayment"]>[0]) {
    return safeEqualHex(hmacHex(this.keySecret, `${gatewayOrderId}|${gatewayPaymentId}`), signature);
  }

  verifyWebhook(rawBody: string, signature: string) {
    return safeEqualHex(hmacHex(this.webhookSecret, rawBody), signature);
  }
}

// Dev mode: a simulated gateway. Orders are prefixed "test_" and the UI shows
// "TEST PAYMENT — no money moved". Signatures use a dev-only key so the full
// verify path is still exercised.
export class DevPaymentAdapter implements PaymentAdapter {
  readonly name = "dev" as const;
  readonly isDev = true;
  constructor(private secret: string) {}

  async createOrder({ amountPaise }: { amountPaise: number; receipt: string }): Promise<CreatedOrder> {
    assertAmount(amountPaise);
    const id = `test_order_${randomBytes(9).toString("base64url")}`;
    console.info(`[DEV PAYMENT — NO MONEY MOVED] order ${id} for ₹${(amountPaise / 100).toFixed(2)}`);
    return { gateway: "dev", gatewayOrderId: id, amountPaise, currency: "INR", isTest: true };
  }

  /** Used only by the dev checkout page to simulate a successful payment. */
  simulatePayment(gatewayOrderId: string) {
    const gatewayPaymentId = `test_pay_${randomBytes(9).toString("base64url")}`;
    return { gatewayPaymentId, signature: hmacHex(this.secret, `${gatewayOrderId}|${gatewayPaymentId}`) };
  }

  verifyPayment({ gatewayOrderId, gatewayPaymentId, signature }: Parameters<PaymentAdapter["verifyPayment"]>[0]) {
    if (!gatewayOrderId.startsWith("test_order_")) return false;
    return safeEqualHex(hmacHex(this.secret, `${gatewayOrderId}|${gatewayPaymentId}`), signature);
  }

  verifyWebhook(rawBody: string, signature: string) {
    return safeEqualHex(hmacHex(this.secret, rawBody), signature);
  }
}

let instance: PaymentAdapter | undefined;

export function payments(): PaymentAdapter {
  if (instance) return instance;
  const e = env();
  if (e.PAYMENT_PROVIDER === "razorpay") {
    instance = new RazorpayAdapter(e.RAZORPAY_KEY_ID!, e.RAZORPAY_KEY_SECRET!, e.RAZORPAY_WEBHOOK_SECRET!);
  } else {
    instance = new DevPaymentAdapter(hmacHex(e.SESSION_SECRET, "dev-payments"));
  }
  return instance;
}
