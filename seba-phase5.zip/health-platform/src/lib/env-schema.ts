import { z } from "zod";

// No "server-only" here so instrumentation.ts can validate on boot;
// application code imports env() from "./env" (server-only).

// Every outside service defaults to a clearly labelled dev mode. Production
// refuses to start with a dev adapter so nothing can pretend to send an SMS or
// take a payment.
const schema = z
  .object({
    NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
    APP_URL: z.url().default("http://localhost:3000"),
    DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),
    SESSION_SECRET: z.string().min(32, "SESSION_SECRET must be at least 32 characters"),

    SMS_PROVIDER: z.enum(["dev", "msg91"]).default("dev"),
    MSG91_AUTH_KEY: z.string().optional(),
    MSG91_SENDER_ID: z.string().optional(),

    PAYMENT_PROVIDER: z.enum(["dev", "razorpay"]).default("dev"),
    RAZORPAY_KEY_ID: z.string().optional(),
    RAZORPAY_KEY_SECRET: z.string().optional(),
    RAZORPAY_WEBHOOK_SECRET: z.string().optional(),

    STORAGE_DRIVER: z.enum(["dev-local", "s3"]).default("dev-local"),
    STORAGE_LOCAL_DIR: z.string().default(".data/private-files"),
    S3_BUCKET: z.string().optional(),
    S3_REGION: z.string().optional(),
    S3_ENDPOINT: z.string().optional(),
    S3_ACCESS_KEY_ID: z.string().optional(),
    S3_SECRET_ACCESS_KEY: z.string().optional(),

    ALLOW_DEV_ADAPTERS_IN_PRODUCTION: z.enum(["true", "false"]).default("false"),
  })
  .superRefine((env, ctx) => {
    const need = (cond: boolean, keys: (keyof typeof env)[], why: string) => {
      if (!cond) return;
      for (const k of keys) {
        if (!env[k]) ctx.addIssue({ code: "custom", path: [k], message: `${k} is required when ${why}` });
      }
    };
    need(env.SMS_PROVIDER === "msg91", ["MSG91_AUTH_KEY", "MSG91_SENDER_ID"], "SMS_PROVIDER=msg91");
    need(env.PAYMENT_PROVIDER === "razorpay", ["RAZORPAY_KEY_ID", "RAZORPAY_KEY_SECRET", "RAZORPAY_WEBHOOK_SECRET"], "PAYMENT_PROVIDER=razorpay");
    need(env.STORAGE_DRIVER === "s3", ["S3_BUCKET", "S3_REGION", "S3_ACCESS_KEY_ID", "S3_SECRET_ACCESS_KEY"], "STORAGE_DRIVER=s3");

    if (env.NODE_ENV === "production" && env.ALLOW_DEV_ADAPTERS_IN_PRODUCTION !== "true") {
      for (const [k, v] of [
        ["SMS_PROVIDER", env.SMS_PROVIDER],
        ["PAYMENT_PROVIDER", env.PAYMENT_PROVIDER],
        ["STORAGE_DRIVER", env.STORAGE_DRIVER],
      ] as const) {
        if (v.startsWith("dev")) {
          ctx.addIssue({ code: "custom", path: [k], message: `${k}=${v} is a dev adapter and is not allowed in production` });
        }
      }
    }
  });

export type Env = z.infer<typeof schema>;

let cached: Env | undefined;

export function parseEnv(source: Record<string, string | undefined>): Env {
  const result = schema.safeParse(source);
  if (!result.success) {
    const lines = result.error.issues.map((i) => `  - ${i.path.join(".")}: ${i.message}`);
    throw new Error(`Invalid environment configuration:\n${lines.join("\n")}`);
  }
  return result.data;
}

export function env(): Env {
  cached ??= parseEnv(process.env);
  return cached;
}
