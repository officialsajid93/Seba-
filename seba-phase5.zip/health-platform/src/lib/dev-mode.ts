// True when any outside service runs in dev mode. Drives the "Test mode" strip
// so nobody mistakes a simulated SMS or payment for a real one.
export function isDevMode(): boolean {
  const e = process.env;
  return (
    (e.SMS_PROVIDER ?? "dev") === "dev" ||
    (e.PAYMENT_PROVIDER ?? "dev") === "dev" ||
    (e.STORAGE_DRIVER ?? "dev-local") === "dev-local"
  );
}
