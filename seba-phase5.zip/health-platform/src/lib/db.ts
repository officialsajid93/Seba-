import "server-only";
import { Pool, type PoolClient, type QueryResultRow } from "pg";
import { env } from "./env";

// One pool per server process. In dev, Next reloads modules, so the pool is
// kept on globalThis to avoid leaking connections on every edit.
const g = globalThis as unknown as { __pgPool?: Pool };

export function pool(): Pool {
  g.__pgPool ??= new Pool({
    connectionString: env().DATABASE_URL,
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 5_000,
    application_name: "seba-web",
  });
  return g.__pgPool;
}

export async function query<T extends QueryResultRow>(text: string, params: unknown[] = []): Promise<T[]> {
  const res = await pool().query<T>(text, params);
  return res.rows;
}

// Runs fn inside one transaction; rolls back on any error. Booking and order
// mutations always go through this so the database functions see one unit of work.
export async function withTransaction<T>(fn: (client: PoolClient) => Promise<T>): Promise<T> {
  const client = await pool().connect();
  try {
    await client.query("BEGIN");
    const out = await fn(client);
    await client.query("COMMIT");
    return out;
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

// Business errors raised by the SQL functions (RAISE ... ERRCODE 'P0001'),
// e.g. SESSION_FULL, ALREADY_BOOKED. The app maps these codes to user messages.
export const DOMAIN_ERRORS = [
  "PATIENT_NOT_OWNED",
  "SESSION_NOT_BOOKABLE",
  "INVALID_SLOT",
  "SLOT_NOT_APPLICABLE",
  "SESSION_FULL",
  "ALREADY_BOOKED",
  "NOT_FOUND",
  "NOT_CANCELLABLE",
  "NOT_RESCHEDULABLE",
  "SESSION_NOT_CANCELLABLE",
  "NOT_ACCEPTABLE",
  "NOT_PHARMACIST_OF_PHARMACY",
  "PHARMACY_NOT_ELIGIBLE",
  "RX_NOT_APPROVED",
  "OUT_OF_STOCK",
  "TOO_MANY_ACTIVE",
  "CANCEL_WINDOW_CLOSED",
] as const;
export type DomainErrorCode = (typeof DOMAIN_ERRORS)[number];

export function domainErrorCode(err: unknown): DomainErrorCode | null {
  if (typeof err !== "object" || err === null) return null;
  const e = err as { code?: string; message?: string };
  if (e.code !== "P0001" || !e.message) return null;
  const code = e.message.split(":")[0];
  return (DOMAIN_ERRORS as readonly string[]).includes(code) ? (code as DomainErrorCode) : null;
}
