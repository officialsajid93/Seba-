import "server-only";
import { headers } from "next/headers";
import { isIP } from "node:net";

// Client IP for rate limiting. Trusts the first X-Forwarded-For hop, which is
// set by the hosting platform's proxy; never used for anything but limits.
export async function clientMeta(): Promise<{ ip: string | null; userAgent: string | null }> {
  const h = await headers();
  const forwarded = h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? h.get("x-real-ip")?.trim() ?? null;
  return { ip: forwarded && isIP(forwarded) ? forwarded : null, userAgent: h.get("user-agent") };
}
