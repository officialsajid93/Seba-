import "server-only";
import { z } from "zod";
import { query, withTransaction } from "@/lib/db";

export const RELATIONS = ["spouse", "child", "parent", "sibling", "other"] as const;
export const MAX_FAMILY = 10;

export type Patient = {
  id: string;
  relation: "self" | (typeof RELATIONS)[number];
  fullName: string;
  sex: "female" | "male" | "other" | null;
  dateOfBirth: string | null;
};

const today = () => new Date().toISOString().slice(0, 10);

export const personSchema = z.object({
  fullName: z
    .string()
    .trim()
    .min(2)
    .max(80)
    // Letters in any script, spaces, dots, apostrophes and hyphens. No digits or symbols.
    .regex(/^[\p{L}\p{M} .'-]+$/u),
  sex: z.enum(["female", "male", "other"]).nullable(),
  dateOfBirth: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .refine((d) => d >= "1900-01-01" && d <= today() && !Number.isNaN(Date.parse(d)))
    .nullable(),
});

export function parsePerson(fd: FormData) {
  const sex = String(fd.get("sex") ?? "");
  const dob = String(fd.get("dateOfBirth") ?? "");
  return personSchema.safeParse({
    fullName: String(fd.get("fullName") ?? ""),
    sex: sex === "" ? null : sex,
    dateOfBirth: dob === "" ? null : dob,
  });
}

export async function listPatients(userId: string): Promise<Patient[]> {
  const rows = await query<{ id: string; relation: Patient["relation"]; full_name: string; sex: Patient["sex"]; dob: string | null }>(
    `SELECT id, relation, full_name, sex, to_char(date_of_birth, 'YYYY-MM-DD') AS dob
       FROM patients WHERE account_user_id = $1 AND deleted_at IS NULL
      ORDER BY (relation = 'self') DESC, created_at`,
    [userId],
  );
  return rows.map((r) => ({ id: r.id, relation: r.relation, fullName: r.full_name, sex: r.sex, dateOfBirth: r.dob }));
}

export async function saveSelf(userId: string, p: z.infer<typeof personSchema>, lang: "bn" | "en") {
  await withTransaction(async (db) => {
    await db.query(`UPDATE users SET display_name = $2, preferred_lang = $3 WHERE id = $1`, [userId, p.fullName, lang]);
    const updated = await db.query(
      `UPDATE patients SET full_name = $2, sex = $3, date_of_birth = $4
        WHERE account_user_id = $1 AND relation = 'self' AND deleted_at IS NULL`,
      [userId, p.fullName, p.sex, p.dateOfBirth],
    );
    if (updated.rowCount === 0) {
      await db.query(
        `INSERT INTO patients (account_user_id, relation, full_name, sex, date_of_birth) VALUES ($1, 'self', $2, $3, $4)`,
        [userId, p.fullName, p.sex, p.dateOfBirth],
      );
    }
  });
}

export async function addFamilyMember(
  userId: string,
  p: z.infer<typeof personSchema>,
  relation: (typeof RELATIONS)[number],
): Promise<"ok" | "limit"> {
  return withTransaction(async (db) => {
    // Lock the account row so two parallel adds cannot pass the limit together.
    await db.query(`SELECT 1 FROM users WHERE id = $1 FOR UPDATE`, [userId]);
    const { rows } = await db.query<{ n: number }>(
      `SELECT count(*)::int AS n FROM patients WHERE account_user_id = $1 AND relation <> 'self' AND deleted_at IS NULL`,
      [userId],
    );
    if (rows[0].n >= MAX_FAMILY) return "limit";
    await db.query(
      `INSERT INTO patients (account_user_id, relation, full_name, sex, date_of_birth) VALUES ($1, $2, $3, $4, $5)`,
      [userId, relation, p.fullName, p.sex, p.dateOfBirth],
    );
    return "ok";
  });
}

// Soft delete: the record stays for past bookings, but disappears from the account.
// "self" can never be removed here, and the WHERE clause enforces ownership.
export async function removeFamilyMember(userId: string, patientId: string): Promise<boolean> {
  if (!z.uuid().safeParse(patientId).success) return false;
  const rows = await query(
    `UPDATE patients SET deleted_at = now()
      WHERE id = $1 AND account_user_id = $2 AND relation <> 'self' AND deleted_at IS NULL
      RETURNING id`,
    [patientId, userId],
  );
  return rows.length === 1;
}
