import "server-only";
import { createHash, randomBytes } from "node:crypto";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { query } from "@/lib/db";

export const SESSION_COOKIE = "seba_session";
export const SESSION_DAYS = 30;

const hashToken = (token: string) => createHash("sha256").update(token).digest("hex");

export type CurrentUser = {
  id: string;
  phone: string;
  displayName: string | null;
  preferredLang: "bn" | "en" | "hi";
  sessionId: string;
};

// Opaque random token in an httpOnly cookie; only its hash is stored, so a
// database leak does not expose working sessions.
export async function createSession(userId: string, meta: { userAgent?: string | null; ip?: string | null }) {
  const token = randomBytes(32).toString("base64url");
  await query(
    `INSERT INTO auth_sessions (user_id, token_hash, user_agent, ip, expires_at)
     VALUES ($1, $2, $3, $4::inet, now() + make_interval(days => $5))`,
    [userId, hashToken(token), meta.userAgent?.slice(0, 300) ?? null, meta.ip, SESSION_DAYS],
  );
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DAYS * 86_400,
  });
}

// Read once per request (React cache), at request time. Callers sit behind <Suspense>.
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token || token.length > 100) return null;
  const rows = await query<{
    session_id: string;
    id: string;
    phone_e164: string;
    display_name: string | null;
    preferred_lang: CurrentUser["preferredLang"];
  }>(
    `SELECT s.id AS session_id, u.id, u.phone_e164, u.display_name, u.preferred_lang
       FROM auth_sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = $1 AND s.revoked_at IS NULL AND s.expires_at > now()
        AND u.status = 'active' AND u.deleted_at IS NULL`,
    [hashToken(token)],
  );
  const r = rows[0];
  return r
    ? { id: r.id, phone: r.phone_e164, displayName: r.display_name, preferredLang: r.preferred_lang, sessionId: r.session_id }
    : null;
});

export async function requireUser(lang: string, next: string): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect(`/${lang}/login?next=${encodeURIComponent(next)}`);
  return user;
}

export async function destroySession() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) await query(`UPDATE auth_sessions SET revoked_at = now() WHERE token_hash = $1`, [hashToken(token)]);
  store.delete(SESSION_COOKIE);
}

// Only same-site paths under a locale are allowed as post-login targets
// (prevents open redirects such as ?next=https://evil.example).
export function safeNext(next: string | null | undefined, lang: string): string {
  if (!next || !/^\/(bn|en)(\/[A-Za-z0-9\-/_?=&%.]*)?$/.test(next) || next.startsWith("//")) return `/${lang}/profile`;
  return next;
}
