// Accepts how people actually type Indian mobile numbers:
// "98123 45678", "098123-45678", "+91 98123 45678", "919812345678".
// Returns E.164 (+91XXXXXXXXXX) or null.
export function normalizeIndianMobile(input: string): string | null {
  const digits = input.replace(/[\s\-().]/g, "").replace(/^\+/, "");
  let local: string;
  if (/^91\d{10}$/.test(digits)) local = digits.slice(2);
  else if (/^0\d{10}$/.test(digits)) local = digits.slice(1);
  else if (/^\d{10}$/.test(digits)) local = digits;
  else return null;
  return /^[6-9]\d{9}$/.test(local) ? `+91${local}` : null;
}

// "+919812345678" -> "+91 98•••••678" for showing back to the user.
export function displayMaskedPhone(e164: string): string {
  const local = e164.replace(/^\+91/, "");
  return `+91 ${local.slice(0, 2)}•••••${local.slice(7)}`;
}
