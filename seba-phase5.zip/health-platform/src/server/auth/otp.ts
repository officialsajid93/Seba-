import "server-only";
import { createHmac, randomInt, timingSafeEqual } from "node:crypto";
import { env } from "@/lib/env";
import { query, withTransaction } from "@/lib/db";
import { sms } from "@/lib/adapters/sms";
import { brand } from "@/config/brand";

export const OTP_TTL_MINUTES = 10;
export const MAX_ATTEMPTS = 5;
export const LIMITS = {
  perPhoneCooldownSec: 60, // one code per minute per number
  perPhonePerHour: 5,
  perIpPerHour: 20,
} as const;

export function hashOtp(secret: string, phone: string, code: string): string {
  return createHmac("sha256", secret).update(`otp:${phone}:${code}`).digest("hex");
}

export type RequestOtpResult =
  | { ok: true; resendAfterSec: number }
  | { ok: false; error: "rate_limited"; retryAfterSec: number };

export async function requestOtp(phone: string, ip: string | null, lang: "bn" | "en"): Promise<RequestOtpResult> {
  const [usage] = await query<{ last_at: Date | null; phone_hour: number; ip_hour: number }>(
    `SELECT
       (SELECT max(created_at) FROM otp_challenges WHERE phone_e164 = $1) AS last_at,
       (SELECT count(*)::int FROM otp_challenges WHERE phone_e164 = $1 AND created_at > now() - interval '1 hour') AS phone_hour,
       (SELECT count(*)::int FROM otp_challenges WHERE $2::inet IS NOT NULL AND request_ip = $2::inet
                                                   AND created_at > now() - interval '1 hour') AS ip_hour`,
    [phone, ip],
  );
  const sinceLast = usage.last_at ? (Date.now() - usage.last_at.getTime()) / 1000 : Infinity;
  if (sinceLast < LIMITS.perPhoneCooldownSec) {
    return { ok: false, error: "rate_limited", retryAfterSec: Math.ceil(LIMITS.perPhoneCooldownSec - sinceLast) };
  }
  if (usage.phone_hour >= LIMITS.perPhonePerHour || usage.ip_hour >= LIMITS.perIpPerHour) {
    return { ok: false, error: "rate_limited", retryAfterSec: 3600 };
  }

  const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
  // Any older unused code for this number stops working once a new one is issued.
  await query(`UPDATE otp_challenges SET consumed_at = now() WHERE phone_e164 = $1 AND consumed_at IS NULL`, [phone]);
  await query(
    `INSERT INTO otp_challenges (phone_e164, code_hash, purpose, expires_at, request_ip)
     VALUES ($1, $2, 'login', now() + make_interval(mins => $3), $4::inet)`,
    [phone, hashOtp(env().SESSION_SECRET, phone, code), OTP_TTL_MINUTES, ip],
  );

  const adapter = sms();
  await adapter.send({ to: phone, template: "otp", lang, vars: { code, brand: lang === "bn" ? brand.nameBn : brand.name } });
  if (adapter.isDev && devCodeLoggingAllowed()) {
    // Dev mode only: no SMS is sent, so the code is printed for the developer.
    console.info(`[DEV OTP — NOT SENT] ${phone.slice(0, 3)}******${phone.slice(-4)} code: ${code}`);
  }
  return { ok: true, resendAfterSec: LIMITS.perPhoneCooldownSec };
}

function devCodeLoggingAllowed() {
  const e = env();
  return e.NODE_ENV !== "production" || e.ALLOW_DEV_ADAPTERS_IN_PRODUCTION === "true";
}

export type VerifyOtpResult =
  | { ok: true; userId: string; isNewUser: boolean; needsProfile: boolean }
  | { ok: false; error: "invalid_code"; attemptsLeft: number }
  | { ok: false; error: "expired" | "too_many_attempts" | "suspended" };

export async function verifyOtp(phone: string, code: string): Promise<VerifyOtpResult> {
  if (!/^\d{6}$/.test(code)) return { ok: false, error: "invalid_code", attemptsLeft: MAX_ATTEMPTS };
  const secret = env().SESSION_SECRET;

  return withTransaction(async (db) => {
    const { rows } = await db.query<{ id: string; code_hash: string; attempts: number }>(
      `SELECT id, code_hash, attempts FROM otp_challenges
        WHERE phone_e164 = $1 AND consumed_at IS NULL AND expires_at > now()
        ORDER BY created_at DESC LIMIT 1 FOR UPDATE`,
      [phone],
    );
    const ch = rows[0];
    if (!ch) return { ok: false, error: "expired" } as const;
    if (ch.attempts >= MAX_ATTEMPTS) return { ok: false, error: "too_many_attempts" } as const;

    const expected = Buffer.from(ch.code_hash, "hex");
    const actual = Buffer.from(hashOtp(secret, phone, code), "hex");
    if (!timingSafeEqual(expected, actual)) {
      const attempts = ch.attempts + 1;
      await db.query(
        `UPDATE otp_challenges SET attempts = $2::int, consumed_at = CASE WHEN $2::int >= $3::int THEN now() END WHERE id = $1`,
        [ch.id, attempts, MAX_ATTEMPTS],
      );
      return attempts >= MAX_ATTEMPTS
        ? ({ ok: false, error: "too_many_attempts" } as const)
        : ({ ok: false, error: "invalid_code", attemptsLeft: MAX_ATTEMPTS - attempts } as const);
    }

    await db.query(`UPDATE otp_challenges SET consumed_at = now() WHERE id = $1`, [ch.id]);
    const user = await db.query<{ id: string; status: string; display_name: string | null; inserted: boolean }>(
      `INSERT INTO users (phone_e164, last_login_at) VALUES ($1, now())
       ON CONFLICT (phone_e164) DO UPDATE SET last_login_at = now()
       RETURNING id, status, display_name, (xmax = 0) AS inserted`,
      [phone],
    );
    const u = user.rows[0];
    if (u.status !== "active") return { ok: false, error: "suspended" } as const;
    const hasSelf = await db.query(
      `SELECT 1 FROM patients WHERE account_user_id = $1 AND relation = 'self' AND deleted_at IS NULL`,
      [u.id],
    );
    return { ok: true, userId: u.id, isNewUser: u.inserted, needsProfile: !u.display_name || hasSelf.rowCount === 0 } as const;
  });
}
