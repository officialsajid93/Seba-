import "server-only";
import { z } from "zod";
import { domainErrorCode, query, withTransaction, type DomainErrorCode } from "@/lib/db";
import type { Named } from "./directory";
import { notifyAppointment, notifyUser, sessionVars, userLang } from "./notify";

// Patient-side booking. Every write goes through the database functions in
// one transaction; every read and write is scoped to the logged-in account.

const uuid = z.uuid();

export type BookingContext = {
  sessionId: string;
  doctor: { id: string; name: Named; isDemo: boolean };
  facility: { id: string; name: Named; address: string; town: Named };
  practiceId: string;
  feePaise: number;
  mode: "serial_token" | "time_slot";
  startsAt: Date;
  endsAt: Date;
  capacity: number;
  seatsLeft: number;
  bookable: boolean;
  freeSlots: Date[];
  patients: { id: string; name: string; relation: string; alreadyBooked: boolean }[];
  waitlisted: boolean;
};

export async function getBookingContext(sessionId: string, userId: string): Promise<BookingContext | null> {
  if (!uuid.safeParse(sessionId).success) return null;
  const [s] = await query<{
    id: string; practice_id: string; booking_mode: BookingContext["mode"]; starts_at: Date; ends_at: Date; slot_minutes: number | null;
    capacity: number; active_count: number; bookable: boolean; fee: string;
    d_id: string; d_en: string; d_bn: string | null; d_demo: boolean; f_id: string; f_en: string; f_bn: string | null; f_addr: string;
    t_en: string; t_bn: string | null;
  }>(
    `SELECT cs.id, cs.practice_id, cs.booking_mode, cs.starts_at, cs.ends_at, cs.slot_minutes, cs.capacity, cs.active_count,
            EXISTS (SELECT 1 FROM bookable_sessions b WHERE b.id = cs.id) AS bookable, dp.consultation_fee_paise AS fee,
            d.id AS d_id, d.full_name AS d_en, d.full_name_bn AS d_bn, d.is_demo AS d_demo,
            f.id AS f_id, f.name AS f_en, f.name_bn AS f_bn, f.address_line AS f_addr, l.name_en AS t_en, l.name_bn AS t_bn
       FROM consultation_sessions cs JOIN doctor_practices dp ON dp.id = cs.practice_id
       JOIN doctors d ON d.id = dp.doctor_id AND d.verification_status = 'verified'
       JOIN facilities f ON f.id = dp.facility_id AND f.is_published JOIN localities l ON l.id = f.locality_id
      WHERE cs.id = $1`,
    [sessionId],
  );
  if (!s) return null;

  const [patients, taken, wait] = await Promise.all([
    query<{ id: string; full_name: string; relation: string; booked: boolean }>(
      `SELECT p.id, p.full_name, p.relation,
              EXISTS (SELECT 1 FROM appointments a WHERE a.session_id = $2 AND a.patient_id = p.id
                        AND a.status IN ('pending_payment','confirmed','checked_in','completed')) AS booked
         FROM patients p WHERE p.account_user_id = $1 AND p.deleted_at IS NULL
        ORDER BY (p.relation = 'self') DESC, p.created_at`,
      [userId, sessionId],
    ),
    query<{ slot_starts_at: Date }>(
      `SELECT slot_starts_at FROM appointments WHERE session_id = $1 AND slot_starts_at IS NOT NULL
          AND status IN ('pending_payment','confirmed','checked_in','completed')`,
      [sessionId],
    ),
    query(`SELECT 1 FROM waitlist_entries WHERE session_id = $1 AND user_id = $2 AND status IN ('waiting','offered')`, [sessionId, userId]),
  ]);

  const freeSlots: Date[] = [];
  if (s.booking_mode === "time_slot" && s.slot_minutes) {
    const takenSet = new Set(taken.map((t) => t.slot_starts_at.getTime()));
    const step = s.slot_minutes * 60_000;
    for (let t = s.starts_at.getTime(); t + step <= s.ends_at.getTime(); t += step) {
      if (!takenSet.has(t)) freeSlots.push(new Date(t));
    }
  }

  return {
    sessionId: s.id,
    practiceId: s.practice_id,
    doctor: { id: s.d_id, name: { en: s.d_en, bn: s.d_bn }, isDemo: s.d_demo },
    facility: { id: s.f_id, name: { en: s.f_en, bn: s.f_bn }, address: s.f_addr, town: { en: s.t_en, bn: s.t_bn } },
    feePaise: Number(s.fee),
    mode: s.booking_mode,
    startsAt: s.starts_at,
    endsAt: s.ends_at,
    capacity: s.capacity,
    seatsLeft: Math.max(0, s.capacity - s.active_count),
    bookable: s.bookable,
    freeSlots,
    patients: patients.map((p) => ({ id: p.id, name: p.full_name, relation: p.relation, alreadyBooked: p.booked })),
    waitlisted: wait.length > 0,
  };
}

export type BookResult = { ok: true; appointmentId: string } | { ok: false; error: DomainErrorCode | "INVALID" };

export async function bookForUser(input: { userId: string; sessionId: string; patientId: string; slot?: string | null }): Promise<BookResult> {
  if (!uuid.safeParse(input.sessionId).success || !uuid.safeParse(input.patientId).success) return { ok: false, error: "INVALID" };
  const slot = input.slot ? new Date(input.slot) : null;
  if (slot && Number.isNaN(slot.getTime())) return { ok: false, error: "INVALID_SLOT" };
  try {
    const id = await withTransaction(async (db) => {
      const { rows } = await db.query<{ id: string }>(
        `SELECT id FROM book_appointment($1, $2, $3, $4, 0)`,
        [input.sessionId, input.patientId, input.userId, slot],
      );
      return rows[0].id;
    });
    await notifyAppointment(id, "booking_confirmed");
    return { ok: true, appointmentId: id };
  } catch (err) {
    const code = domainErrorCode(err);
    if (code) return { ok: false, error: code };
    throw err;
  }
}

export type MyAppointment = {
  id: string;
  code: string;
  status: string;
  serial: number;
  slotStartsAt: Date | null;
  startsAt: Date;
  endsAt: Date;
  sessionStatus: string;
  sessionNote: string | null;
  canChange: boolean;
  feePaise: number;
  patientName: string;
  practiceId: string;
  sessionId: string;
  doctor: { id: string; name: Named };
  facility: { id: string; name: Named; address: string; phone: string | null; lat: number | null; lng: number | null };
  createdAt: Date;
};

const APPT_SELECT = `
  SELECT a.id, a.booking_code, a.status::text, a.token_number, a.slot_starts_at, a.consultation_fee_paise, a.created_at,
         cs.id AS session_id, cs.starts_at, cs.ends_at, cs.status::text AS session_status, cs.public_note,
         (a.status = 'confirmed' AND coalesce(cs.booking_closes_at, cs.starts_at) > now()) AS can_change,
         p.full_name AS patient_name, dp.id AS practice_id,
         d.id AS d_id, d.full_name AS d_en, d.full_name_bn AS d_bn,
         f.id AS f_id, f.name AS f_en, f.name_bn AS f_bn, f.address_line, f.phone_e164, f.lat, f.lng
    FROM appointments a
    JOIN consultation_sessions cs ON cs.id = a.session_id
    JOIN doctor_practices dp ON dp.id = cs.practice_id
    JOIN doctors d ON d.id = dp.doctor_id
    JOIN facilities f ON f.id = dp.facility_id
    JOIN patients p ON p.id = a.patient_id`;

type ApptRow = {
  id: string; booking_code: string; status: string; token_number: number; slot_starts_at: Date | null; consultation_fee_paise: string;
  created_at: Date; session_id: string; starts_at: Date; ends_at: Date; session_status: string; public_note: string | null; can_change: boolean;
  patient_name: string; practice_id: string; d_id: string; d_en: string; d_bn: string | null; f_id: string; f_en: string; f_bn: string | null;
  address_line: string; phone_e164: string | null; lat: string | null; lng: string | null;
};

const toAppt = (r: ApptRow): MyAppointment => ({
  id: r.id, code: r.booking_code, status: r.status, serial: r.token_number, slotStartsAt: r.slot_starts_at,
  startsAt: r.starts_at, endsAt: r.ends_at, sessionStatus: r.session_status, sessionNote: r.public_note, canChange: r.can_change,
  feePaise: Number(r.consultation_fee_paise), patientName: r.patient_name, practiceId: r.practice_id, sessionId: r.session_id,
  doctor: { id: r.d_id, name: { en: r.d_en, bn: r.d_bn } },
  facility: { id: r.f_id, name: { en: r.f_en, bn: r.f_bn }, address: r.address_line, phone: r.phone_e164, lat: r.lat ? Number(r.lat) : null, lng: r.lng ? Number(r.lng) : null },
  createdAt: r.created_at,
});

export async function listMyAppointments(userId: string): Promise<{ upcoming: MyAppointment[]; past: MyAppointment[] }> {
  const rows = await query<ApptRow>(
    `${APPT_SELECT} WHERE a.booked_by_user_id = $1 AND a.status <> 'rescheduled' ORDER BY cs.starts_at DESC LIMIT 100`,
    [userId],
  );
  const all = rows.map(toAppt);
  const now = Date.now();
  const isUpcoming = (a: MyAppointment) => a.endsAt.getTime() > now && ["confirmed", "pending_payment", "checked_in"].includes(a.status);
  return { upcoming: all.filter(isUpcoming).reverse(), past: all.filter((a) => !isUpcoming(a)) };
}

export async function getMyAppointment(userId: string, id: string) {
  if (!uuid.safeParse(id).success) return null;
  const [row] = await query<ApptRow>(`${APPT_SELECT} WHERE a.id = $1 AND a.booked_by_user_id = $2`, [id, userId]);
  if (!row) return null;
  const events = await query<{ to_status: string; at: Date; note: string | null }>(
    `SELECT to_status::text, at, note FROM appointment_events WHERE appointment_id = $1 ORDER BY at, id`,
    [id],
  );
  return { ...toAppt(row), events };
}

export async function cancelMine(userId: string, id: string): Promise<{ ok: true } | { ok: false; error: DomainErrorCode | "INVALID" }> {
  if (!uuid.safeParse(id).success) return { ok: false, error: "INVALID" };
  try {
    const offered = await withTransaction(async (db) => {
      const { rows } = await db.query<{ session_id: string }>(
        `SELECT session_id FROM cancel_appointment($1, $2, false, 'cancelled by patient')`,
        [id, userId],
      );
      const w = await db.query<{ user_id: string | null; session_id: string | null }>(
        `SELECT user_id, session_id FROM offer_next_waitlist($1)`,
        [rows[0].session_id],
      );
      return w.rows[0]?.user_id ? { userId: w.rows[0].user_id, sessionId: w.rows[0].session_id! } : null;
    });
    await notifyAppointment(id, "booking_cancelled");
    if (offered) await notifySeatOffered(offered.userId, offered.sessionId);
    return { ok: true };
  } catch (err) {
    const code = domainErrorCode(err);
    if (code) return { ok: false, error: code };
    throw err;
  }
}

export async function rescheduleOptions(userId: string, id: string) {
  const appt = await getMyAppointment(userId, id);
  if (!appt || !appt.canChange) return [];
  return query<{ id: string; starts_at: Date; ends_at: Date; seats_left: number; booking_mode: string }>(
    `SELECT id, starts_at, ends_at, seats_left, booking_mode FROM bookable_sessions
      WHERE practice_id = $1 AND id <> $2 AND seats_left > 0 AND booking_mode = 'serial_token'
      ORDER BY starts_at LIMIT 10`,
    [appt.practiceId, appt.sessionId],
  );
}

export async function rescheduleMine(userId: string, id: string, newSessionId: string): Promise<BookResult> {
  if (!uuid.safeParse(id).success || !uuid.safeParse(newSessionId).success) return { ok: false, error: "INVALID" };
  try {
    const newId = await withTransaction(async (db) => {
      // Same doctor and place only: the fee and the patient stay the same.
      const same = await db.query(
        `SELECT 1 FROM appointments a JOIN consultation_sessions o ON o.id = a.session_id
           JOIN consultation_sessions n ON n.id = $2 AND n.practice_id = o.practice_id
          WHERE a.id = $1 AND a.booked_by_user_id = $3`,
        [id, newSessionId, userId],
      );
      if (!same.rowCount) throw Object.assign(new Error("NOT_FOUND"), { code: "P0001" });
      const { rows } = await db.query<{ id: string }>(`SELECT id FROM reschedule_appointment($1, $2, $3)`, [id, newSessionId, userId]);
      return rows[0].id;
    });
    await notifyAppointment(newId, "booking_confirmed");
    return { ok: true, appointmentId: newId };
  } catch (err) {
    const code = domainErrorCode(err);
    if (code) return { ok: false, error: code };
    throw err;
  }
}

export async function joinWaitlist(userId: string, sessionId: string, patientId: string): Promise<boolean> {
  if (!uuid.safeParse(sessionId).success || !uuid.safeParse(patientId).success) return false;
  const rows = await query(
    `INSERT INTO waitlist_entries (session_id, patient_id, user_id)
     SELECT cs.id, p.id, $3 FROM consultation_sessions cs, patients p
      WHERE cs.id = $1 AND p.id = $2 AND p.account_user_id = $3 AND p.deleted_at IS NULL
        AND cs.status IN ('scheduled', 'running_late') AND coalesce(cs.booking_closes_at, cs.starts_at) > now()
        AND cs.active_count >= cs.capacity
     ON CONFLICT (session_id, patient_id) DO UPDATE SET status = 'waiting' WHERE waitlist_entries.status IN ('cancelled', 'expired')
     RETURNING id`,
    [sessionId, patientId, userId],
  );
  return rows.length > 0;
}

async function notifySeatOffered(userId: string, sessionId: string) {
  const vars = await sessionVars(sessionId, await userLang(userId));
  if (vars) await notifyUser(userId, "seat_offered", vars, { session_id: sessionId });
}

export async function listMyNotifications(userId: string) {
  return query<{ id: string; template_key: string; payload: { text?: string; appointment_id?: string }; created_at: Date }>(
    `SELECT id, template_key, payload, created_at FROM notifications
      WHERE user_id = $1 AND channel = 'in_app' ORDER BY created_at DESC LIMIT 50`,
    [userId],
  );
}
