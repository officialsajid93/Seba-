import "server-only";
import { brand } from "@/config/brand";
import { query } from "@/lib/db";
import { sms } from "@/lib/adapters/sms";
import { renderSms, type SmsTemplateKey } from "@/lib/adapters/sms-templates";
import { formatNumber, formatSitting } from "@/lib/format";

// Sends an SMS (or logs it in dev mode) and records both the SMS and an
// in-app copy in `notifications`. Never throws: a failed SMS must not undo a
// booking that already committed. Call after the transaction commits.
export async function notifyUser(
  userId: string,
  template: SmsTemplateKey,
  vars: Record<string, string | number>,
  payload: Record<string, unknown> = {},
): Promise<void> {
  try {
    const [user] = await query<{ phone_e164: string; preferred_lang: string }>(
      `SELECT phone_e164, preferred_lang FROM users WHERE id = $1 AND status = 'active'`,
      [userId],
    );
    if (!user) return;
    const lang = user.preferred_lang === "en" ? "en" : "bn";
    const allVars = { ...vars, brand: lang === "bn" ? brand.nameBn : brand.name };
    const text = renderSms(template, lang, allVars);

    let status: "sent" | "dev_logged" | "failed" = "failed";
    let providerId: string | null = null;
    try {
      const res = await sms().send({ to: user.phone_e164, template, lang, vars: allVars });
      status = res.status;
      providerId = res.providerMessageId;
    } catch (err) {
      console.error(`[notify] SMS ${template} failed:`, err instanceof Error ? err.message : err);
    }
    await query(
      `INSERT INTO notifications (user_id, channel, template_key, lang, payload, status, provider_message_id, sent_at)
       VALUES ($1, 'sms', $2, $3::app_language, $4::jsonb, $5::notif_status, $6, CASE WHEN $5::text <> 'failed' THEN now() END),
              ($1, 'in_app', $2, $3::app_language, $7::jsonb, 'delivered', NULL, now())`,
      [userId, template, lang, JSON.stringify(payload), status, providerId, JSON.stringify({ ...payload, text })],
    );
  } catch (err) {
    console.error(`[notify] could not record ${template}:`, err instanceof Error ? err.message : err);
  }
}

// Everything an appointment SMS needs, in the recipient's language.
export async function appointmentVars(appointmentId: string, lang: "bn" | "en") {
  const [r] = await query<{
    booking_code: string; token_number: number; slot_starts_at: Date | null; starts_at: Date; ends_at: Date;
    doc_en: string; doc_bn: string | null; fac_en: string; fac_bn: string | null; user_id: string;
  }>(
    `SELECT a.booking_code, a.token_number, a.slot_starts_at, cs.starts_at, cs.ends_at,
            d.full_name AS doc_en, d.full_name_bn AS doc_bn, f.name AS fac_en, f.name_bn AS fac_bn, a.booked_by_user_id AS user_id
       FROM appointments a JOIN consultation_sessions cs ON cs.id = a.session_id
       JOIN doctor_practices dp ON dp.id = cs.practice_id JOIN doctors d ON d.id = dp.doctor_id
       JOIN facilities f ON f.id = dp.facility_id WHERE a.id = $1`,
    [appointmentId],
  );
  if (!r) return null;
  const when = formatSitting(r.slot_starts_at ?? r.starts_at, r.ends_at, lang);
  return {
    userId: r.user_id,
    vars: {
      code: r.booking_code,
      serial: formatNumber(r.token_number, lang),
      doctor: lang === "bn" && r.doc_bn ? r.doc_bn : r.doc_en,
      place: lang === "bn" && r.fac_bn ? r.fac_bn : r.fac_en,
      date: when.day,
      time: when.time.split(" – ")[0],
    },
  };
}

// Doctor, place, date and time of a sitting, for SMS about the sitting itself.
export async function sessionVars(sessionId: string, lang: "bn" | "en") {
  const [r] = await query<{ starts_at: Date; ends_at: Date; doc_en: string; doc_bn: string | null; fac_en: string; fac_bn: string | null }>(
    `SELECT cs.starts_at, cs.ends_at, d.full_name AS doc_en, d.full_name_bn AS doc_bn, f.name AS fac_en, f.name_bn AS fac_bn
       FROM consultation_sessions cs JOIN doctor_practices dp ON dp.id = cs.practice_id
       JOIN doctors d ON d.id = dp.doctor_id JOIN facilities f ON f.id = dp.facility_id WHERE cs.id = $1`,
    [sessionId],
  );
  if (!r) return null;
  const when = formatSitting(r.starts_at, r.ends_at, lang);
  return {
    doctor: lang === "bn" && r.doc_bn ? r.doc_bn : r.doc_en,
    place: lang === "bn" && r.fac_bn ? r.fac_bn : r.fac_en,
    date: when.day,
    time: when.time.split(" – ")[0],
  };
}

export async function userLang(userId: string): Promise<"bn" | "en"> {
  const [u] = await query<{ preferred_lang: string }>(`SELECT preferred_lang FROM users WHERE id = $1`, [userId]);
  return u?.preferred_lang === "en" ? "en" : "bn";
}

export async function notifyAppointment(appointmentId: string, template: SmsTemplateKey) {
  const [row] = await query<{ user_id: string }>(`SELECT booked_by_user_id AS user_id FROM appointments WHERE id = $1`, [appointmentId]);
  if (!row) return;
  const info = await appointmentVars(appointmentId, await userLang(row.user_id));
  if (info) await notifyUser(info.userId, template, info.vars, { appointment_id: appointmentId });
}
