import "server-only";
import { z } from "zod";
import { domainErrorCode, query, withTransaction, type DomainErrorCode } from "@/lib/db";
import { normalizeIndianMobile } from "@/server/auth/phone";
import { audit } from "@/server/audit";
import { appointmentVars, notifyAppointment, notifyUser, userLang } from "@/server/notify";
import type { Named } from "@/server/directory";
import { facilityRole, getProviderScope, practiceRole, sessionRole, appointmentRole, type ProviderRole } from "./access";

// Provider-side operations. Each function checks the caller's role for the
// exact practice / sitting / booking first, and writes an audit log row for
// every change. Patients affected by a change get an SMS.

export class Forbidden extends Error {
  constructor() {
    super("FORBIDDEN");
  }
}
export type Result<T = undefined> = { ok: true; value?: T } | { ok: false; error: DomainErrorCode | "INVALID" | "FORBIDDEN" | "TOO_EARLY" | "INVALID_TRANSITION" };

const uuid = z.uuid();

function mapError(err: unknown): Result<never> {
  if (err instanceof Forbidden) return { ok: false, error: "FORBIDDEN" };
  const code = domainErrorCode(err);
  if (code) return { ok: false, error: code };
  const msg = (err as { message?: string })?.message;
  if (msg === "TOO_EARLY" || msg === "INVALID_TRANSITION") return { ok: false, error: msg };
  throw err;
}

async function needPractice(userId: string, practiceId: string): Promise<ProviderRole> {
  const role = await practiceRole(userId, practiceId);
  if (!role) throw new Forbidden();
  return role;
}

// ------------------------------------------------------------------ reads

export type SittingSummary = {
  id: string; practiceId: string; startsAt: Date; endsAt: Date; status: string; note: string | null;
  capacity: number; booked: number; mode: "serial_token" | "time_slot"; doctor: Named; facility: Named; checkedIn: number;
};

const SITTING_SELECT = `
  SELECT cs.id, cs.practice_id, cs.starts_at, cs.ends_at, cs.status::text, cs.public_note, cs.capacity, cs.active_count AS booked,
         cs.booking_mode, d.full_name AS d_en, d.full_name_bn AS d_bn, f.name AS f_en, f.name_bn AS f_bn,
         (SELECT count(*)::int FROM appointments a WHERE a.session_id = cs.id AND a.status IN ('checked_in', 'completed')) AS checked_in
    FROM consultation_sessions cs JOIN doctor_practices dp ON dp.id = cs.practice_id
    JOIN doctors d ON d.id = dp.doctor_id JOIN facilities f ON f.id = dp.facility_id`;

type SittingRow = {
  id: string; practice_id: string; starts_at: Date; ends_at: Date; status: string; public_note: string | null; capacity: number;
  booked: number; booking_mode: SittingSummary["mode"]; d_en: string; d_bn: string | null; f_en: string; f_bn: string | null; checked_in: number;
};
const toSitting = (r: SittingRow): SittingSummary => ({
  id: r.id, practiceId: r.practice_id, startsAt: r.starts_at, endsAt: r.ends_at, status: r.status, note: r.public_note,
  capacity: r.capacity, booked: r.booked, mode: r.booking_mode, doctor: { en: r.d_en, bn: r.d_bn }, facility: { en: r.f_en, bn: r.f_bn },
  checkedIn: r.checked_in,
});

// Practices this user may manage, with schedule freshness.
export type ManagedPractice = {
  id: string; doctor: Named & { id: string; verified: boolean }; facility: Named & { id: string }; feePaise: number;
  mode: "serial_token" | "time_slot"; scheduleState: string; confirmedAt: Date | null; stale: boolean; role: ProviderRole;
  active: boolean;
};

export async function managedPractices(userId: string, facilityId?: string): Promise<ManagedPractice[]> {
  const rows = await query<{
    id: string; d_id: string; d_en: string; d_bn: string | null; d_status: string; f_id: string; f_en: string; f_bn: string | null;
    fee: string; booking_mode: ManagedPractice["mode"]; schedule_state: string; confirmed_at: Date | null; stale: boolean; role: ProviderRole;
    is_active: boolean;
  }>(
    `SELECT dp.id, d.id AS d_id, d.full_name AS d_en, d.full_name_bn AS d_bn, d.verification_status::text AS d_status,
            f.id AS f_id, f.name AS f_en, f.name_bn AS f_bn, dp.consultation_fee_paise AS fee, dp.booking_mode,
            dp.schedule_state::text, dp.schedule_confirmed_at AS confirmed_at, dp.is_active,
            (dp.schedule_state <> 'confirmed' OR dp.schedule_confirmed_at <= now() - make_interval(days => setting_int('schedule_stale_after_days'))) AS stale,
            coalesce((SELECT r.role::text FROM user_roles r WHERE r.user_id = $1 AND r.facility_id = dp.facility_id AND r.revoked_at IS NULL
                        AND r.role IN ('facility_admin','facility_staff') ORDER BY (r.role = 'facility_admin') DESC LIMIT 1),
                     CASE WHEN d.user_id = $1 THEN 'doctor' END) AS role
       FROM doctor_practices dp JOIN doctors d ON d.id = dp.doctor_id JOIN facilities f ON f.id = dp.facility_id
      WHERE ($2::uuid IS NULL OR dp.facility_id = $2)
        AND (EXISTS (SELECT 1 FROM user_roles r WHERE r.user_id = $1 AND r.facility_id = dp.facility_id AND r.revoked_at IS NULL
                       AND r.role IN ('facility_admin','facility_staff'))
             OR (d.user_id = $1 AND EXISTS (SELECT 1 FROM user_roles r WHERE r.user_id = $1 AND r.role = 'doctor' AND r.revoked_at IS NULL)))
      ORDER BY dp.is_active DESC, f.name, d.full_name`,
    [userId, facilityId ?? null],
  );
  return rows.map((r) => ({
    id: r.id, doctor: { id: r.d_id, en: r.d_en, bn: r.d_bn, verified: r.d_status === "verified" }, facility: { id: r.f_id, en: r.f_en, bn: r.f_bn },
    feePaise: Number(r.fee), mode: r.booking_mode, scheduleState: r.schedule_state, confirmedAt: r.confirmed_at, stale: r.stale, role: r.role,
    active: r.is_active,
  }));
}

export async function upcomingSittings(practiceIds: string[], days: number): Promise<SittingSummary[]> {
  if (!practiceIds.length) return [];
  const rows = await query<SittingRow>(
    `${SITTING_SELECT} WHERE cs.practice_id = ANY($1::uuid[]) AND cs.ends_at > now()
       AND cs.session_date <= (now() AT TIME ZONE 'Asia/Kolkata')::date + $2::int ORDER BY cs.starts_at`,
    [practiceIds, days],
  );
  return rows.map(toSitting);
}

export async function providerHome(userId: string) {
  const scope = await getProviderScope(userId);
  const practices = await managedPractices(userId);
  const today = await upcomingSittings(practices.map((p) => p.id), 0);
  return { scope, practices, today };
}

export type Template = { id?: string; weekday: number; start: string; end: string; capacity: number; slotMinutes: number | null };

export async function practiceDetail(userId: string, practiceId: string) {
  const role = await practiceRole(userId, practiceId);
  if (!role) return null;
  const [practice] = (await managedPractices(userId)).filter((p) => p.id === practiceId);
  if (!practice) return null;
  const [templates, exceptions, sittings] = await Promise.all([
    query<{ id: string; weekday: number; start: string; end: string; capacity: number; slot_minutes: number | null }>(
      `SELECT id, weekday, to_char(start_time, 'HH24:MI') AS start, to_char(end_time, 'HH24:MI') AS "end", capacity, slot_minutes
         FROM schedule_templates WHERE practice_id = $1 AND (effective_to IS NULL OR effective_to >= current_date)
        ORDER BY weekday, start_time`,
      [practiceId],
    ),
    query<{ id: string; kind: string; starts_on: string; ends_on: string; new_start: string | null; new_end: string | null; reason_public: string | null }>(
      `SELECT se.id, se.kind::text, to_char(se.starts_on, 'YYYY-MM-DD') AS starts_on, to_char(se.ends_on, 'YYYY-MM-DD') AS ends_on,
              to_char(se.new_start_time, 'HH24:MI') AS new_start, to_char(se.new_end_time, 'HH24:MI') AS new_end, se.reason_public
         FROM schedule_exceptions se JOIN doctor_practices dp ON dp.doctor_id = se.doctor_id
        WHERE dp.id = $1 AND (se.practice_id IS NULL OR se.practice_id = $1) AND se.ends_on >= (now() AT TIME ZONE 'Asia/Kolkata')::date
        ORDER BY se.starts_on`,
      [practiceId],
    ),
    upcomingSittings([practiceId], 14),
  ]);
  return {
    role,
    practice,
    templates: templates.map((t) => ({ id: t.id, weekday: t.weekday, start: t.start, end: t.end, capacity: t.capacity, slotMinutes: t.slot_minutes })),
    exceptions,
    sittings,
  };
}

export async function sittingQueue(userId: string, sessionId: string) {
  const access = await sessionRole(userId, sessionId);
  if (!access?.role) return null;
  const [sitting] = (await query<SittingRow>(`${SITTING_SELECT} WHERE cs.id = $1`, [sessionId])).map(toSitting);
  const patients = await query<{
    id: string; token_number: number; slot_starts_at: Date | null; status: string; patient: string; phone: string;
    by_clinic: boolean; booking_code: string;
  }>(
    `SELECT a.id, a.token_number, a.slot_starts_at, a.status::text, p.full_name AS patient, u.phone_e164 AS phone, a.booking_code,
            EXISTS (SELECT 1 FROM appointment_events e WHERE e.appointment_id = a.id AND e.note = 'booked by clinic') AS by_clinic
       FROM appointments a JOIN patients p ON p.id = a.patient_id JOIN users u ON u.id = a.booked_by_user_id
      WHERE a.session_id = $1 AND a.status NOT IN ('rescheduled')
      ORDER BY a.slot_starts_at NULLS LAST, a.token_number`,
    [sessionId],
  );
  return { role: access.role, sitting, patients };
}

// ----------------------------------------------------------------- writes

export async function confirmSchedule(userId: string, practiceId: string): Promise<Result> {
  try {
    const role = await needPractice(userId, practiceId);
    await withTransaction(async (db) => {
      await db.query(`SELECT confirm_schedule($1, $2)`, [practiceId, userId]);
      await audit({ actorId: userId, actorRole: role, action: "schedule.confirm", entityType: "doctor_practice", entityId: practiceId }, db);
    });
    return { ok: true };
  } catch (err) {
    return mapError(err);
  }
}

const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/);
export const templateSchema = z
  .object({
    weekday: z.coerce.number().int().min(0).max(6),
    start: hhmm,
    end: hhmm,
    capacity: z.coerce.number().int().min(1).max(500),
    slotMinutes: z.coerce.number().int().min(5).max(120).nullable(),
  })
  .refine((t) => t.end > t.start, { message: "END_BEFORE_START" });

export function parseTemplates(fd: FormData): { ok: true; value: Template[] } | { ok: false; error: string } {
  const days = fd.getAll("weekday").map(String);
  const starts = fd.getAll("start").map(String);
  const ends = fd.getAll("end").map(String);
  const caps = fd.getAll("capacity").map(String);
  const slots = fd.getAll("slotMinutes").map(String);
  if (days.length > 21 || starts.length !== days.length || ends.length !== days.length || caps.length !== days.length) {
    return { ok: false, error: "INVALID" };
  }
  const out: Template[] = [];
  for (let i = 0; i < days.length; i++) {
    const r = templateSchema.safeParse({
      weekday: days[i], start: starts[i], end: ends[i], capacity: caps[i], slotMinutes: slots[i] ? slots[i] : null,
    });
    if (!r.success) return { ok: false, error: r.error.issues[0]?.message === "END_BEFORE_START" ? "END_BEFORE_START" : "INVALID" };
    out.push(r.data);
  }
  // No two sittings on the same day may overlap.
  for (const a of out) {
    for (const b of out) {
      if (a !== b && a.weekday === b.weekday && a.start < b.end && b.start < a.end) return { ok: false, error: "OVERLAP" };
    }
  }
  return { ok: true, value: out };
}

// Replace the weekly schedule and rebuild unbooked future sittings. Saving a
// schedule also counts as confirming it.
export async function saveTemplates(userId: string, practiceId: string, templates: Template[]): Promise<Result<{ removed: number; created: number; keptWithBookings: number }>> {
  try {
    const role = await needPractice(userId, practiceId);
    const value = await withTransaction(async (db) => {
      const { rows: [p] } = await db.query<{ booking_mode: string }>(`SELECT booking_mode FROM doctor_practices WHERE id = $1 FOR UPDATE`, [practiceId]);
      if (p.booking_mode === "time_slot" && templates.some((t) => !t.slotMinutes)) throw Object.assign(new Error("INVALID"), { code: "P0001" });
      const before = (await db.query(`SELECT weekday, start_time, end_time, capacity, slot_minutes FROM schedule_templates WHERE practice_id = $1 ORDER BY weekday, start_time`, [practiceId])).rows;
      await db.query(`DELETE FROM schedule_templates WHERE practice_id = $1`, [practiceId]);
      for (const t of templates) {
        await db.query(
          `INSERT INTO schedule_templates (practice_id, weekday, shift_label, start_time, end_time, capacity, slot_minutes)
           VALUES ($1, $2, CASE WHEN $3::time < '12:00' THEN 'morning' WHEN $3::time < '16:00' THEN 'afternoon' ELSE 'evening' END, $3, $4, $5, $6)`,
          [practiceId, t.weekday, t.start, t.end, t.capacity, p.booking_mode === "time_slot" ? t.slotMinutes : null],
        );
      }
      const { rows: [r] } = await db.query<{ removed: number; created: number; kept_with_bookings: number }>(
        `SELECT * FROM rebuild_future_sessions($1)`, [practiceId]);
      await db.query(`SELECT confirm_schedule($1, $2)`, [practiceId, userId]);
      await audit({ actorId: userId, actorRole: role, action: "schedule.templates.save", entityType: "doctor_practice", entityId: practiceId, before, after: templates }, db);
      return { removed: r.removed, created: r.created, keptWithBookings: r.kept_with_bookings };
    });
    return { ok: true, value };
  } catch (err) {
    if ((err as Error).message === "INVALID") return { ok: false, error: "INVALID" };
    return mapError(err);
  }
}

const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/);
export const exceptionSchema = z.discriminatedUnion("kind", [
  z.object({ kind: z.literal("leave"), from: isoDate, to: isoDate, reason: z.string().trim().max(120).default(""), allPractices: z.boolean().default(false) }),
  z.object({ kind: z.literal("time_change"), from: isoDate, to: isoDate, newStart: hhmm, newEnd: hhmm, reason: z.string().trim().max(120).default("") }),
  z.object({ kind: z.literal("extra_session"), from: isoDate, newStart: hhmm, newEnd: hhmm, capacity: z.coerce.number().int().min(1).max(500), reason: z.string().trim().max(120).default("") }),
]);
export type ExceptionInput = z.infer<typeof exceptionSchema>;

// Leave / time change / extra sitting. Existing sittings are updated at once
// and every affected patient gets an SMS.
export async function addException(userId: string, practiceId: string, input: ExceptionInput): Promise<Result<{ affected: number }>> {
  try {
    const role = await needPractice(userId, practiceId);
    const today = new Date(Date.now() + 330 * 60_000).toISOString().slice(0, 10);
    const to = input.kind === "extra_session" ? input.from : input.to;
    if (input.from < today || to < input.from || daysBetween(input.from, to) > 90) return { ok: false, error: "INVALID" };
    if (input.kind !== "leave" && input.newEnd <= input.newStart) return { ok: false, error: "INVALID" };
    // Only the doctor can mark leave across all their practices.
    const doctorWide = input.kind === "leave" && input.allPractices && role === "doctor";

    const { affected, kind } = await withTransaction(async (db) => {
      const { rows: [dp] } = await db.query<{ doctor_id: string }>(`SELECT doctor_id FROM doctor_practices WHERE id = $1`, [practiceId]);
      const { rows: [ex] } = await db.query<{ id: string }>(
        `INSERT INTO schedule_exceptions (doctor_id, practice_id, kind, starts_on, ends_on, new_start_time, new_end_time, capacity, reason_public, created_by)
         VALUES ($1, $2, $3::exception_kind, $4, $5, $6, $7, $8, nullif($9, ''), $10) RETURNING id`,
        [
          dp.doctor_id, doctorWide ? null : practiceId, input.kind, input.from, to,
          input.kind === "leave" ? null : input.newStart, input.kind === "leave" ? null : input.newEnd,
          input.kind === "extra_session" ? input.capacity : null, input.reason, userId,
        ],
      );
      let ids: string[] = [];
      if (input.kind === "extra_session") {
        await db.query(`SELECT generate_sessions($1::date, 1, $2)`, [input.from, practiceId]);
      } else {
        ids = (await db.query<{ id: string }>(`SELECT x AS id FROM apply_schedule_exception($1, $2) x`, [ex.id, userId])).rows.map((r) => r.id);
      }
      await audit({ actorId: userId, actorRole: role, action: `schedule.exception.${input.kind}`, entityType: "schedule_exception", entityId: ex.id, after: input }, db);
      return { affected: [...new Set(ids)], kind: input.kind };
    });
    for (const id of affected) {
      const [a] = await query<{ status: string }>(`SELECT status::text FROM appointments WHERE id = $1`, [id]);
      await notifyAppointment(id, kind === "time_change" && a?.status === "confirmed" ? "time_changed" : "session_cancelled");
    }
    return { ok: true, value: { affected: affected.length } };
  } catch (err) {
    return mapError(err);
  }
}

function daysBetween(a: string, b: string) {
  return Math.round((Date.parse(b) - Date.parse(a)) / 86_400_000);
}

export async function cancelSitting(userId: string, sessionId: string, reason: string): Promise<Result<{ affected: number }>> {
  try {
    const access = await sessionRole(userId, sessionId);
    if (!access?.role) throw new Forbidden();
    const ids = await withTransaction(async (db) => {
      const r = (await db.query<{ id: string }>(`SELECT x AS id FROM cancel_session($1, $2, $3) x`, [sessionId, userId, reason.slice(0, 120) || "Cancelled by clinic"])).rows.map((x) => x.id);
      await audit({ actorId: userId, actorRole: access.role, action: "sitting.cancel", entityType: "consultation_session", entityId: sessionId, after: { reason, affected: r.length } }, db);
      return r;
    });
    for (const id of ids) await notifyAppointment(id, "session_cancelled");
    return { ok: true, value: { affected: ids.length } };
  } catch (err) {
    return mapError(err);
  }
}

export async function setRunningLate(userId: string, sessionId: string, minutes: number | null): Promise<Result<{ notified: number }>> {
  try {
    const access = await sessionRole(userId, sessionId);
    if (!access?.role) throw new Forbidden();
    if (minutes !== null && (!Number.isInteger(minutes) || minutes < 5 || minutes > 240)) return { ok: false, error: "INVALID" };
    await withTransaction(async (db) => {
      await db.query(`SELECT set_running_late($1, $2, $3, $4)`, [sessionId, minutes !== null, minutes !== null ? `+${minutes} min` : null, userId]);
      await audit({ actorId: userId, actorRole: access.role, action: "sitting.running_late", entityType: "consultation_session", entityId: sessionId, after: { minutes } }, db);
    });
    let notified = 0;
    if (minutes !== null) {
      const waiting = await query<{ id: string; user_id: string }>(
        `SELECT id, booked_by_user_id AS user_id FROM appointments WHERE session_id = $1 AND status = 'confirmed'`, [sessionId]);
      for (const a of waiting) {
        const lang = await userLang(a.user_id);
        const info = await appointmentVars(a.id, lang);
        if (!info) continue;
        const note = lang === "bn" ? `প্রায় ${new Intl.NumberFormat("bn-IN").format(minutes)} মিনিট` : `about ${minutes} minutes`;
        await notifyUser(a.user_id, "running_late", { ...info.vars, note }, { appointment_id: a.id });
        notified++;
      }
    }
    return { ok: true, value: { notified } };
  } catch (err) {
    return mapError(err);
  }
}

export async function setVisitStatus(userId: string, appointmentId: string, to: "checked_in" | "completed" | "no_show"): Promise<Result> {
  try {
    const access = await appointmentRole(userId, appointmentId);
    if (!access?.role) throw new Forbidden();
    await withTransaction(async (db) => {
      await db.query(`SELECT set_visit_status($1, $2::appointment_status, $3)`, [appointmentId, to, userId]);
      await audit({ actorId: userId, actorRole: access.role, action: `visit.${to}`, entityType: "appointment", entityId: appointmentId }, db);
    });
    return { ok: true };
  } catch (err) {
    return mapError(err);
  }
}

export const staffBookingSchema = z.object({
  name: z.string().trim().min(2).max(80).regex(/^[\p{L}\p{M} .'-]+$/u),
  phone: z.string().max(20),
});

// Phone or walk-in booking by clinic staff. The patient's number gets an
// account (or uses theirs), so they receive the SMS and can see the booking
// in the app if they ever log in.
export async function staffBook(userId: string, sessionId: string, input: { name: string; phone: string }): Promise<Result<{ appointmentId: string; serial: number }>> {
  try {
    const access = await sessionRole(userId, sessionId);
    if (!access?.role) throw new Forbidden();
    const parsed = staffBookingSchema.safeParse(input);
    const phone = normalizeIndianMobile(input.phone);
    if (!parsed.success || !phone) return { ok: false, error: "INVALID" };
    const name = parsed.data.name;

    const value = await withTransaction(async (db) => {
      const { rows: [u] } = await db.query<{ id: string }>(
        `INSERT INTO users (phone_e164, display_name, created_by_staff) VALUES ($1, $2, $3)
         ON CONFLICT (phone_e164) DO UPDATE SET phone_e164 = EXCLUDED.phone_e164 RETURNING id`,
        [phone, name, userId],
      );
      let { rows: [p] } = await db.query<{ id: string }>(
        `SELECT id FROM patients WHERE account_user_id = $1 AND deleted_at IS NULL AND lower(trim(full_name)) = lower($2) LIMIT 1`,
        [u.id, name],
      );
      if (!p) {
        ({ rows: [p] } = await db.query<{ id: string }>(
          `INSERT INTO patients (account_user_id, relation, full_name)
           VALUES ($1, CASE WHEN EXISTS (SELECT 1 FROM patients WHERE account_user_id = $1 AND relation = 'self' AND deleted_at IS NULL)
                            THEN 'other' ELSE 'self' END, $2) RETURNING id`,
          [u.id, name],
        ));
      }
      const { rows: [a] } = await db.query<{ id: string; token_number: number }>(
        `SELECT id, token_number FROM book_by_staff($1, $2, $3, $4)`, [sessionId, p.id, u.id, userId]);
      await audit({ actorId: userId, actorRole: access.role, action: "booking.staff", entityType: "appointment", entityId: a.id, after: { sessionId } }, db);
      return { appointmentId: a.id, serial: a.token_number };
    });
    await notifyAppointment(value.appointmentId, "booking_confirmed");
    return { ok: true, value };
  } catch (err) {
    return mapError(err);
  }
}

export async function canAddDoctors(userId: string, facilityId: string) {
  return (await facilityRole(userId, facilityId)) === "facility_admin";
}

export { uuid as uuidSchema };
