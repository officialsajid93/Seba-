import "server-only";
import { z } from "zod";
import { query } from "@/lib/db";

// Who may manage what. Least privilege:
//  - facility_admin / facility_staff: practices and sittings at THEIR facility only
//  - doctor: their own practices (any facility)
//  - facility_admin only: add doctors to the facility
// Every provider action calls one of these before touching data.

export type ProviderRole = "facility_admin" | "facility_staff" | "doctor";

export type ProviderScope = {
  facilities: { id: string; name: string; nameBn: string | null; role: "facility_admin" | "facility_staff"; published: boolean; verification: string }[];
  doctorIds: string[];
};

const uuid = z.uuid();

export async function getProviderScope(userId: string): Promise<ProviderScope> {
  const [facilities, doctors] = await Promise.all([
    query<{ id: string; name: string; name_bn: string | null; role: "facility_admin" | "facility_staff"; is_published: boolean; verification_status: string }>(
      `SELECT DISTINCT ON (f.id) f.id, f.name, f.name_bn, r.role, f.is_published, f.verification_status::text
         FROM user_roles r JOIN facilities f ON f.id = r.facility_id
        WHERE r.user_id = $1 AND r.revoked_at IS NULL AND r.role IN ('facility_admin', 'facility_staff')
        ORDER BY f.id, (r.role = 'facility_admin') DESC`,
      [userId],
    ),
    query<{ id: string }>(
      `SELECT d.id FROM doctors d
        WHERE d.user_id = $1
          AND EXISTS (SELECT 1 FROM user_roles r WHERE r.user_id = $1 AND r.role = 'doctor' AND r.revoked_at IS NULL)`,
      [userId],
    ),
  ]);
  return {
    facilities: facilities.map((f) => ({ id: f.id, name: f.name, nameBn: f.name_bn, role: f.role, published: f.is_published, verification: f.verification_status })),
    doctorIds: doctors.map((d) => d.id),
  };
}

export const hasProviderAccess = (s: ProviderScope) => s.facilities.length > 0 || s.doctorIds.length > 0;

export async function facilityRole(userId: string, facilityId: string): Promise<"facility_admin" | "facility_staff" | null> {
  if (!uuid.safeParse(facilityId).success) return null;
  const rows = await query<{ role: "facility_admin" | "facility_staff" }>(
    `SELECT role FROM user_roles WHERE user_id = $1 AND facility_id = $2 AND revoked_at IS NULL
        AND role IN ('facility_admin', 'facility_staff') ORDER BY (role = 'facility_admin') DESC LIMIT 1`,
    [userId, facilityId],
  );
  return rows[0]?.role ?? null;
}

// Role through which this user may manage the practice, or null.
export async function practiceRole(userId: string, practiceId: string): Promise<ProviderRole | null> {
  if (!uuid.safeParse(practiceId).success) return null;
  const rows = await query<{ via_facility: string | null; via_doctor: boolean }>(
    `SELECT (SELECT r.role::text FROM user_roles r
              WHERE r.user_id = $1 AND r.facility_id = dp.facility_id AND r.revoked_at IS NULL
                AND r.role IN ('facility_admin', 'facility_staff')
              ORDER BY (r.role = 'facility_admin') DESC LIMIT 1) AS via_facility,
            EXISTS (SELECT 1 FROM doctors d JOIN user_roles r ON r.user_id = d.user_id AND r.role = 'doctor' AND r.revoked_at IS NULL
                     WHERE d.id = dp.doctor_id AND d.user_id = $1) AS via_doctor
       FROM doctor_practices dp WHERE dp.id = $2`,
    [userId, practiceId],
  );
  const r = rows[0];
  if (!r) return null;
  return (r.via_facility as ProviderRole | null) ?? (r.via_doctor ? "doctor" : null);
}

export async function sessionPractice(sessionId: string): Promise<string | null> {
  if (!uuid.safeParse(sessionId).success) return null;
  const [r] = await query<{ practice_id: string }>(`SELECT practice_id FROM consultation_sessions WHERE id = $1`, [sessionId]);
  return r?.practice_id ?? null;
}

export async function sessionRole(userId: string, sessionId: string) {
  const practiceId = await sessionPractice(sessionId);
  return practiceId ? { practiceId, role: await practiceRole(userId, practiceId) } : null;
}

export async function appointmentRole(userId: string, appointmentId: string) {
  if (!uuid.safeParse(appointmentId).success) return null;
  const [r] = await query<{ session_id: string }>(`SELECT session_id FROM appointments WHERE id = $1`, [appointmentId]);
  return r ? sessionRole(userId, r.session_id) : null;
}
