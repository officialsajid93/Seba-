import "server-only";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import { query, withTransaction } from "@/lib/db";
import { storage, validateUpload, type AllowedMime } from "@/lib/adapters/storage";
import { normalizeIndianMobile } from "@/server/auth/phone";
import { audit } from "@/server/audit";
import { facilityRole } from "./access";

// Clinic and doctor onboarding. Nothing created here is public: facilities
// stay unpublished and doctors stay unverified until an admin checks the
// documents (Phase 7 admin queue). The person who registers a clinic becomes
// its admin, so they can prepare schedules in the meantime.

const ext: Record<AllowedMime, string> = { "application/pdf": "pdf", "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp" };

export type Upload = { docType: string; file: File };

async function readUploads(uploads: Upload[]) {
  const out: { docType: string; bytes: Uint8Array; mime: AllowedMime }[] = [];
  for (const u of uploads) {
    if (!u.file || u.file.size === 0) continue;
    if (u.file.size > 10 * 1024 * 1024) throw new OnboardingError("FILE_TOO_LARGE");
    const bytes = new Uint8Array(await u.file.arrayBuffer());
    let mime: AllowedMime;
    try {
      mime = validateUpload(bytes);
    } catch {
      throw new OnboardingError("FILE_TYPE");
    }
    out.push({ docType: u.docType, bytes, mime });
  }
  return out;
}

export class OnboardingError extends Error {}

async function storeDocuments(requestId: string, files: Awaited<ReturnType<typeof readUploads>>) {
  const stored = [];
  for (const f of files) {
    const key = `verification/${requestId}/${f.docType}-${randomBytes(8).toString("hex")}.${ext[f.mime]}`;
    const obj = await storage().put(key, f.bytes);
    stored.push({ ...obj, docType: f.docType });
  }
  return stored;
}

export const facilitySchema = z.object({
  type: z.enum(["hospital", "nursing_home", "clinic", "diagnostic_centre", "chamber"]),
  name: z.string().trim().min(3).max(120),
  nameBn: z.string().trim().max(120).optional().transform((v) => v || null),
  address: z.string().trim().min(5).max(200),
  town: z.string().regex(/^[a-z-]{2,40}$/),
  pincode: z.string().regex(/^[1-9]\d{5}$/),
  phone: z.string().max(20),
  licenceNo: z.string().trim().max(60).optional().transform((v) => v || null),
});

export async function registerFacility(userId: string, raw: unknown, uploads: Upload[]) {
  const parsed = facilitySchema.safeParse(raw);
  if (!parsed.success) return { ok: false as const, error: "INVALID" as const, field: String(parsed.error.issues[0]?.path[0] ?? "") };
  const phone = normalizeIndianMobile(parsed.data.phone);
  if (!phone) return { ok: false as const, error: "INVALID" as const, field: "phone" };
  let files;
  try {
    files = await readUploads(uploads);
  } catch (e) {
    return { ok: false as const, error: (e as Error).message as "FILE_TOO_LARGE" | "FILE_TYPE" };
  }
  if (!files.some((f) => f.docType === "establishment_licence")) return { ok: false as const, error: "LICENCE_REQUIRED" as const };
  // A user may register at most 3 clinics while they are unreviewed (stops spam).
  const [{ n }] = await query<{ n: number }>(
    `SELECT count(*)::int AS n FROM verification_requests WHERE submitted_by = $1 AND entity_type = 'facility' AND status = 'submitted'`, [userId]);
  if (n >= 3) return { ok: false as const, error: "TOO_MANY_PENDING" as const };

  const d = parsed.data;
  const requestId = await withTransaction(async (db) => {
    const { rows: [town] } = await db.query<{ id: string }>(`SELECT id FROM localities WHERE slug = $1 AND is_launched`, [d.town]);
    if (!town) throw new OnboardingError("INVALID");
    const { rows: [f] } = await db.query<{ id: string }>(
      `INSERT INTO facilities (type, name, name_bn, address_line, locality_id, pincode, phone_e164, establishment_reg_no, verification_status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'submitted') RETURNING id`,
      [d.type, d.name, d.nameBn, d.address, town.id, d.pincode, phone, d.licenceNo],
    );
    await db.query(`INSERT INTO user_roles (user_id, role, facility_id, granted_by) VALUES ($1, 'facility_admin', $2, $1)`, [userId, f.id]);
    const { rows: [vr] } = await db.query<{ id: string }>(
      `INSERT INTO verification_requests (entity_type, entity_id, submitted_by) VALUES ('facility', $1, $2) RETURNING id`, [f.id, userId]);
    await audit({ actorId: userId, action: "facility.register", entityType: "facility", entityId: f.id, after: { ...d, phone } }, db);
    return vr.id;
  });
  const stored = await storeDocuments(requestId, files);
  for (const s of stored) {
    await query(
      `INSERT INTO verification_documents (request_id, doc_type, file_key, sha256, mime_type, size_bytes) VALUES ($1, $2, $3, $4, $5, $6)`,
      [requestId, s.docType, s.key, s.sha256, s.mime, s.sizeBytes],
    );
  }
  return { ok: true as const, requestId };
}

export const doctorSchema = z.object({
  fullName: z.string().trim().min(3).max(80).regex(/^[\p{L}\p{M} .'-]+$/u),
  fullNameBn: z.string().trim().max(80).optional().transform((v) => v || null),
  registrationNumber: z.string().trim().min(2).max(40).regex(/^[A-Za-z0-9/\-. ]+$/),
  council: z.string().trim().min(3).max(80),
  degrees: z.string().trim().min(2).max(160),
  speciality: z.string().regex(/^[a-z-]{2,40}$/),
  practisingSince: z.coerce.number().int().min(1950).max(new Date().getFullYear()).optional(),
  feeRupees: z.coerce.number().int().min(0).max(10000),
  mode: z.enum(["serial_token", "time_slot"]),
});

export async function addDoctorToFacility(userId: string, facilityId: string, raw: unknown, uploads: Upload[]) {
  if ((await facilityRole(userId, facilityId)) !== "facility_admin") return { ok: false as const, error: "FORBIDDEN" as const };
  const parsed = doctorSchema.safeParse(raw);
  if (!parsed.success) return { ok: false as const, error: "INVALID" as const, field: String(parsed.error.issues[0]?.path[0] ?? "") };
  let files;
  try {
    files = await readUploads(uploads);
  } catch (e) {
    return { ok: false as const, error: (e as Error).message as "FILE_TOO_LARGE" | "FILE_TYPE" };
  }
  const d = parsed.data;

  const result = await withTransaction(async (db) => {
    // Same registration = same doctor: link them instead of creating a duplicate.
    let { rows: [doc] } = await db.query<{ id: string; verification_status: string }>(
      `SELECT id, verification_status::text FROM doctors WHERE registration_council = $1 AND registration_number = $2`,
      [d.council, d.registrationNumber],
    );
    const isNew = !doc;
    if (!doc) {
      ({ rows: [doc] } = await db.query<{ id: string; verification_status: string }>(
        `INSERT INTO doctors (full_name, full_name_bn, registration_number, registration_council, practising_since, verification_status)
         VALUES ($1, $2, $3, $4, $5, 'submitted') RETURNING id, verification_status::text`,
        [d.fullName, d.fullNameBn, d.registrationNumber, d.council, d.practisingSince ?? null],
      ));
      for (const degree of d.degrees.split(",").map((x) => x.trim()).filter(Boolean).slice(0, 6)) {
        await db.query(`INSERT INTO doctor_qualifications (doctor_id, degree) VALUES ($1, $2)`, [doc.id, degree.slice(0, 80)]);
      }
      await db.query(
        `INSERT INTO doctor_specialities (doctor_id, speciality_id, is_primary) SELECT $1, id, true FROM specialities WHERE slug = $2`,
        [doc.id, d.speciality],
      );
    }
    const exists = await db.query(`SELECT 1 FROM doctor_practices WHERE doctor_id = $1 AND facility_id = $2`, [doc.id, facilityId]);
    if (exists.rowCount) throw new OnboardingError("ALREADY_LINKED");
    const { rows: [pr] } = await db.query<{ id: string }>(
      // Inactive until an admin confirms this doctor really practises here.
      `INSERT INTO doctor_practices (doctor_id, facility_id, consultation_fee_paise, booking_mode, is_active) VALUES ($1, $2, $3, $4, false) RETURNING id`,
      [doc.id, facilityId, d.feeRupees * 100, d.mode],
    );
    // Always review the link; also review the doctor if they are new.
    const { rows: [link] } = await db.query<{ id: string }>(
      `INSERT INTO verification_requests (entity_type, entity_id, submitted_by) VALUES ('doctor_facility', $1, $2) RETURNING id`, [pr.id, userId]);
    let requestId = link.id;
    if (doc.verification_status !== "verified") {
      ({ rows: [{ id: requestId }] } = await db.query<{ id: string }>(
        `INSERT INTO verification_requests (entity_type, entity_id, submitted_by) VALUES ('doctor', $1, $2) RETURNING id`, [doc.id, userId]));
    }
    await audit({ actorId: userId, actorRole: "facility_admin", action: "doctor.add", entityType: "doctor_practice", entityId: pr.id, after: { ...d, isNew } }, db);
    return { practiceId: pr.id, requestId, isNew };
  }).catch((e) => {
    if (e instanceof OnboardingError) return { error: e.message };
    throw e;
  });
  if ("error" in result) return { ok: false as const, error: result.error as "ALREADY_LINKED" | "INVALID" };
  {
    for (const s of await storeDocuments(result.requestId, files)) {
      await query(
        `INSERT INTO verification_documents (request_id, doc_type, file_key, sha256, mime_type, size_bytes) VALUES ($1, $2, $3, $4, $5, $6)`,
        [result.requestId, s.docType, s.key, s.sha256, s.mime, s.sizeBytes],
      );
    }
  }
  return { ok: true as const, practiceId: result.practiceId };
}

export async function myPendingRequests(userId: string) {
  return query<{ id: string; entity_type: string; status: string; submitted_at: Date; name: string | null; decision_note: string | null }>(
    `SELECT vr.id, vr.entity_type, vr.status::text, vr.submitted_at, vr.decision_note,
            coalesce((SELECT name FROM facilities WHERE id = vr.entity_id), (SELECT full_name FROM doctors WHERE id = vr.entity_id),
                     (SELECT d.full_name FROM doctor_practices dp JOIN doctors d ON d.id = dp.doctor_id WHERE dp.id = vr.entity_id)) AS name
       FROM verification_requests vr WHERE vr.submitted_by = $1 ORDER BY vr.submitted_at DESC LIMIT 20`,
    [userId],
  );
}
