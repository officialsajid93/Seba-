import "server-only";
import { z } from "zod";
import { query } from "@/lib/db";
import type { SittingState } from "@/components/ui/availability";

// Read-only queries for listings. Only verified doctors and published
// (verified) facilities are ever returned. Availability comes from the
// `bookable_sessions` view, the single definition of "can be booked".

const HORIZON_DAYS = 7;

export type Named = { en: string; bn: string | null };
export type FacilityType = "hospital" | "nursing_home" | "clinic" | "diagnostic_centre" | "chamber";

export const pick = (n: Named, lang: string) => (lang === "bn" && n.bn ? n.bn : n.en);

const likeEscape = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

export const searchSchema = z.object({
  q: z.string().trim().max(80).default(""),
  speciality: z.string().regex(/^[a-z-]{2,40}$/).optional(),
  town: z.string().regex(/^[a-z-]{2,40}$/).optional(),
  maxFee: z.coerce.number().int().min(0).max(100_000).optional(), // rupees
  available: z.boolean().default(false),
});
export type SearchInput = z.infer<typeof searchSchema>;

export function parseSearchParams(sp: Record<string, string | string[] | undefined>): SearchInput {
  const one = (k: string) => {
    const v = sp[k];
    const s = Array.isArray(v) ? v[0] : v;
    return s === "" || s === undefined ? undefined : s;
  };
  const parsed = searchSchema.safeParse({
    q: one("q") ?? "",
    speciality: one("speciality"),
    town: one("town"),
    maxFee: one("maxFee"),
    available: one("available") === "1",
  });
  return parsed.success ? parsed.data : { q: "", available: false };
}

export async function listSpecialities(): Promise<{ slug: string; name: Named }[]> {
  const rows = await query<{ slug: string; name_en: string; name_bn: string | null }>(
    `SELECT slug, name_en, name_bn FROM specialities ORDER BY name_en`,
  );
  return rows.map((r) => ({ slug: r.slug, name: { en: r.name_en, bn: r.name_bn } }));
}

export async function listTowns(): Promise<{ slug: string; name: Named }[]> {
  const rows = await query<{ slug: string; name_en: string; name_bn: string | null }>(
    `SELECT slug, name_en, name_bn FROM localities WHERE is_launched AND slug IS NOT NULL ORDER BY name_en`,
  );
  return rows.map((r) => ({ slug: r.slug, name: { en: r.name_en, bn: r.name_bn } }));
}

export type DoctorCard = {
  id: string;
  name: Named;
  isDemo: boolean;
  specialities: Named[];
  yearsExperience: number | null;
  feeFromPaise: number;
  towns: Named[];
  scheduleConfirmedAt: Date | null;
  next: null | { startsAt: Date; endsAt: Date; seatsLeft: number; capacity: number; facility: Named; status: string };
};

export async function searchDoctors(input: SearchInput, limit = 30, ids?: string[]): Promise<DoctorCard[]> {
  const q = input.q;
  const rows = await query<{
    id: string; full_name: string; full_name_bn: string | null; is_demo: boolean; practising_since: number | null;
    specs: Named[] | null; fee_from: string; towns: Named[]; confirmed_at: Date | null;
    n_starts: Date | null; n_ends: Date | null; n_left: number | null; n_cap: number | null; n_status: string | null;
    n_fac_en: string | null; n_fac_bn: string | null;
  }>(
    `WITH matched AS (
       SELECT d.id
         FROM doctors d
         JOIN doctor_practices dp ON dp.doctor_id = d.id AND dp.is_active
         JOIN facilities f ON f.id = dp.facility_id AND f.is_published
         JOIN localities l ON l.id = f.locality_id
        WHERE d.verification_status = 'verified'
          AND ($1 = '' OR d.full_name ILIKE '%' || $2 || '%' ESCAPE '\\' OR d.full_name_bn ILIKE '%' || $2 || '%' ESCAPE '\\'
               OR d.full_name % $1 OR f.name ILIKE '%' || $2 || '%' ESCAPE '\\' OR f.name_bn ILIKE '%' || $2 || '%' ESCAPE '\\'
               OR EXISTS (SELECT 1 FROM doctor_specialities ds JOIN specialities sp ON sp.id = ds.speciality_id
                           WHERE ds.doctor_id = d.id AND (sp.name_en ILIKE '%' || $2 || '%' ESCAPE '\\'
                                 OR sp.name_bn ILIKE '%' || $2 || '%' ESCAPE '\\' OR sp.slug = lower($1))))
          AND ($3::text IS NULL OR EXISTS (SELECT 1 FROM doctor_specialities ds JOIN specialities sp ON sp.id = ds.speciality_id
                                          WHERE ds.doctor_id = d.id AND sp.slug = $3))
          AND ($4::text IS NULL OR l.slug = $4)
          AND ($5::bigint IS NULL OR dp.consultation_fee_paise <= $5)
          AND ($8::uuid[] IS NULL OR d.id = ANY($8::uuid[]))
        GROUP BY d.id
     )
     SELECT d.id, d.full_name, d.full_name_bn, d.is_demo, d.practising_since,
            (SELECT json_agg(json_build_object('en', sp.name_en, 'bn', sp.name_bn) ORDER BY ds.is_primary DESC, sp.name_en)
               FROM doctor_specialities ds JOIN specialities sp ON sp.id = ds.speciality_id WHERE ds.doctor_id = d.id) AS specs,
            (SELECT min(consultation_fee_paise) FROM doctor_practices WHERE doctor_id = d.id AND is_active) AS fee_from,
            (SELECT json_agg(DISTINCT jsonb_build_object('en', l.name_en, 'bn', l.name_bn))
               FROM doctor_practices dp JOIN facilities f ON f.id = dp.facility_id AND f.is_published
               JOIN localities l ON l.id = f.locality_id WHERE dp.doctor_id = d.id AND dp.is_active) AS towns,
            (SELECT max(schedule_confirmed_at) FROM doctor_practices WHERE doctor_id = d.id AND is_active AND schedule_state = 'confirmed') AS confirmed_at,
            nx.starts_at AS n_starts, nx.ends_at AS n_ends, nx.seats_left AS n_left, nx.capacity AS n_cap, nx.status::text AS n_status,
            nx.fac_en AS n_fac_en, nx.fac_bn AS n_fac_bn
       FROM matched m
       JOIN doctors d ON d.id = m.id
       LEFT JOIN LATERAL (
         SELECT bs.starts_at, bs.ends_at, bs.seats_left, bs.capacity, bs.status, f.name AS fac_en, f.name_bn AS fac_bn
           FROM bookable_sessions bs JOIN facilities f ON f.id = bs.facility_id
           LEFT JOIN localities l ON l.id = f.locality_id
          WHERE bs.doctor_id = d.id AND bs.seats_left > 0
            AND bs.starts_at < now() + make_interval(days => ${HORIZON_DAYS})
            AND ($4::text IS NULL OR l.slug = $4)
          ORDER BY bs.starts_at LIMIT 1
       ) nx ON true
      WHERE NOT $6 OR nx.starts_at IS NOT NULL
      ORDER BY (nx.starts_at IS NULL), nx.starts_at, d.full_name
      LIMIT $7`,
    [q, likeEscape(q), input.speciality ?? null, input.town ?? null, input.maxFee != null ? input.maxFee * 100 : null, input.available, limit, ids ?? null],
  );
  const thisYear = new Date().getFullYear();
  return rows.map((r) => ({
    id: r.id,
    name: { en: r.full_name, bn: r.full_name_bn },
    isDemo: r.is_demo,
    specialities: r.specs ?? [],
    yearsExperience: r.practising_since ? thisYear - r.practising_since : null,
    feeFromPaise: Number(r.fee_from),
    towns: r.towns ?? [],
    scheduleConfirmedAt: r.confirmed_at,
    next: r.n_starts
      ? {
          startsAt: r.n_starts,
          endsAt: r.n_ends!,
          seatsLeft: r.n_left!,
          capacity: r.n_cap!,
          status: r.n_status!,
          facility: { en: r.n_fac_en!, bn: r.n_fac_bn },
        }
      : null,
  }));
}

export type Sitting = {
  id: string;
  startsAt: Date;
  endsAt: Date;
  state: SittingState;
  bookable: boolean;
  note: string | null;
};

export type Practice = {
  id: string;
  feePaise: number;
  bookingMode: "time_slot" | "serial_token";
  scheduleOk: boolean;
  confirmedAt: Date | null;
  facility: { id: string; name: Named; type: FacilityType; address: string; town: Named; phone: string | null; lat: number | null; lng: number | null; isDemo: boolean };
  sittings: Sitting[];
};

export type DoctorDetail = {
  id: string;
  name: Named;
  isDemo: boolean;
  bio: Named | null;
  registration: { number: string; council: string };
  yearsExperience: number | null;
  languages: string[];
  specialities: Named[];
  qualifications: { degree: string; institution: string | null; year: number | null }[];
  practices: Practice[];
};

function sittingState(r: { status: string; on_leave: boolean; capacity: number; active_count: number }, scheduleOk: boolean): SittingState {
  if (r.on_leave) return { kind: "on_leave" };
  if (r.status === "cancelled") return { kind: "cancelled" };
  if (!scheduleOk) return { kind: "unverified" };
  if (r.capacity - r.active_count <= 0) return { kind: "full" };
  if (r.status === "running_late") return { kind: "running_late" };
  return { kind: "open", seatsLeft: r.capacity - r.active_count, capacity: r.capacity };
}

export async function getDoctor(id: string): Promise<DoctorDetail | null> {
  if (!z.uuid().safeParse(id).success) return null;
  const [doc] = await query<{
    id: string; full_name: string; full_name_bn: string | null; is_demo: boolean; bio_en: string | null; bio_bn: string | null;
    registration_number: string; registration_council: string; practising_since: number | null; languages: string[];
  }>(
    `SELECT id, full_name, full_name_bn, is_demo, bio_en, bio_bn, registration_number, registration_council, practising_since, languages
       FROM doctors WHERE id = $1 AND verification_status = 'verified'`,
    [id],
  );
  if (!doc) return null;

  const [specs, quals, practices, sittings] = await Promise.all([
    query<{ name_en: string; name_bn: string | null }>(
      `SELECT sp.name_en, sp.name_bn FROM doctor_specialities ds JOIN specialities sp ON sp.id = ds.speciality_id
        WHERE ds.doctor_id = $1 ORDER BY ds.is_primary DESC, sp.name_en`, [id]),
    query<{ degree: string; institution: string | null; year: number | null }>(
      `SELECT degree, institution, year FROM doctor_qualifications WHERE doctor_id = $1 ORDER BY year NULLS LAST`, [id]),
    query<{
      id: string; fee: string; booking_mode: Practice["bookingMode"]; schedule_ok: boolean; confirmed_at: Date | null;
      f_id: string; f_name: string; f_name_bn: string | null; f_type: FacilityType; f_addr: string; t_en: string; t_bn: string | null;
      phone: string | null; lat: string | null; lng: string | null; f_demo: boolean;
    }>(
      `SELECT dp.id, dp.consultation_fee_paise AS fee, dp.booking_mode,
              (dp.schedule_state = 'confirmed' AND dp.schedule_confirmed_at > now() - make_interval(days =>
                 (SELECT value::int FROM platform_settings WHERE key = 'schedule_stale_after_days'))) AS schedule_ok,
              dp.schedule_confirmed_at AS confirmed_at,
              f.id AS f_id, f.name AS f_name, f.name_bn AS f_name_bn, f.type AS f_type, f.address_line AS f_addr,
              l.name_en AS t_en, l.name_bn AS t_bn, f.phone_e164 AS phone, f.lat, f.lng, f.is_demo AS f_demo
         FROM doctor_practices dp JOIN facilities f ON f.id = dp.facility_id AND f.is_published
         JOIN localities l ON l.id = f.locality_id
        WHERE dp.doctor_id = $1 AND dp.is_active
        ORDER BY l.name_en, f.name`, [id]),
    query<{
      id: string; practice_id: string; starts_at: Date; ends_at: Date; status: string; capacity: number; active_count: number;
      public_note: string | null; bookable: boolean; on_leave: boolean;
    }>(
      `SELECT cs.id, cs.practice_id, cs.starts_at, cs.ends_at, cs.status::text, cs.capacity, cs.active_count, cs.public_note,
              EXISTS (SELECT 1 FROM bookable_sessions b WHERE b.id = cs.id) AS bookable,
              EXISTS (SELECT 1 FROM schedule_exceptions se
                       WHERE se.doctor_id = $1 AND se.kind = 'leave' AND cs.session_date BETWEEN se.starts_on AND se.ends_on
                         AND (se.practice_id IS NULL OR se.practice_id = cs.practice_id)) AS on_leave
         FROM consultation_sessions cs JOIN doctor_practices dp ON dp.id = cs.practice_id
        WHERE dp.doctor_id = $1 AND cs.ends_at > now() AND cs.starts_at < now() + make_interval(days => ${HORIZON_DAYS})
        ORDER BY cs.starts_at`, [id]),
  ]);

  return {
    id: doc.id,
    name: { en: doc.full_name, bn: doc.full_name_bn },
    isDemo: doc.is_demo,
    bio: doc.bio_en ? { en: doc.bio_en, bn: doc.bio_bn } : null,
    registration: { number: doc.registration_number, council: doc.registration_council },
    yearsExperience: doc.practising_since ? new Date().getFullYear() - doc.practising_since : null,
    languages: doc.languages,
    specialities: specs.map((s) => ({ en: s.name_en, bn: s.name_bn })),
    qualifications: quals,
    practices: practices.map((p) => ({
      id: p.id,
      feePaise: Number(p.fee),
      bookingMode: p.booking_mode,
      scheduleOk: p.schedule_ok,
      confirmedAt: p.confirmed_at,
      facility: {
        id: p.f_id, name: { en: p.f_name, bn: p.f_name_bn }, type: p.f_type, address: p.f_addr,
        town: { en: p.t_en, bn: p.t_bn }, phone: p.phone, lat: p.lat ? Number(p.lat) : null, lng: p.lng ? Number(p.lng) : null,
        isDemo: p.f_demo,
      },
      sittings: sittings
        .filter((s) => s.practice_id === p.id)
        .map((s) => ({
          id: s.id, startsAt: s.starts_at, endsAt: s.ends_at, note: s.public_note, bookable: s.bookable,
          state: sittingState(s, p.schedule_ok),
        })),
    })),
  };
}

export type FacilityCard = {
  id: string; type: FacilityType; name: Named; address: string; town: Named; phone: string | null;
  open247: boolean; emergency: boolean; doctorCount: number; isDemo: boolean; lat: number | null; lng: number | null;
};

export async function listFacilities(opts: { types?: FacilityType[]; town?: string; q?: string; id?: string; limit?: number }): Promise<FacilityCard[]> {
  const q = (opts.q ?? "").trim().slice(0, 80);
  const rows = await query<{
    id: string; type: FacilityType; name: string; name_bn: string | null; address_line: string; t_en: string; t_bn: string | null;
    phone_e164: string | null; open_24x7: boolean; emergency_available: boolean; doctors: number; is_demo: boolean; lat: string | null; lng: string | null;
  }>(
    `SELECT f.id, f.type, f.name, f.name_bn, f.address_line, l.name_en AS t_en, l.name_bn AS t_bn, f.phone_e164,
            f.open_24x7, f.emergency_available, f.is_demo, f.lat, f.lng,
            (SELECT count(*)::int FROM doctor_practices dp JOIN doctors d ON d.id = dp.doctor_id
              WHERE dp.facility_id = f.id AND dp.is_active AND d.verification_status = 'verified') AS doctors
       FROM facilities f JOIN localities l ON l.id = f.locality_id
      WHERE f.is_published
        AND ($1::facility_type[] IS NULL OR f.type = ANY($1::facility_type[]))
        AND ($2::text IS NULL OR l.slug = $2)
        AND ($3 = '' OR f.name ILIKE '%' || $4 || '%' ESCAPE '\\' OR f.name_bn ILIKE '%' || $4 || '%' ESCAPE '\\'
             OR f.name % $3 OR f.address_line ILIKE '%' || $4 || '%' ESCAPE '\\'
             OR EXISTS (SELECT 1 FROM facility_services s WHERE s.facility_id = f.id AND s.name ILIKE '%' || $4 || '%' ESCAPE '\\'))
        AND ($6::uuid IS NULL OR f.id = $6)
      ORDER BY f.emergency_available DESC, f.name
      LIMIT $5`,
    [opts.types ?? null, opts.town ?? null, q, likeEscape(q), opts.limit ?? 50, opts.id ?? null],
  );
  return rows.map((r) => ({
    id: r.id, type: r.type, name: { en: r.name, bn: r.name_bn }, address: r.address_line, town: { en: r.t_en, bn: r.t_bn },
    phone: r.phone_e164, open247: r.open_24x7, emergency: r.emergency_available, doctorCount: r.doctors, isDemo: r.is_demo,
    lat: r.lat ? Number(r.lat) : null, lng: r.lng ? Number(r.lng) : null,
  }));
}

export type FacilityDetail = FacilityCard & {
  departments: Named[];
  services: { category: string; name: string }[];
  tests: { name: Named; pricePaise: number; homeCollection: boolean }[];
  doctorIds: string[];
};

export async function getFacility(id: string): Promise<FacilityDetail | null> {
  if (!z.uuid().safeParse(id).success) return null;
  const [card] = await listFacilities({ id, limit: 1 });
  if (!card) return null;
  const [departments, services, tests, doctors] = await Promise.all([
    query<{ name: string; name_bn: string | null }>(`SELECT name, name_bn FROM departments WHERE facility_id = $1 ORDER BY name`, [id]),
    query<{ category: string; name: string }>(`SELECT category, name FROM facility_services WHERE facility_id = $1 ORDER BY category, name`, [id]),
    query<{ name: string; name_bn: string | null; price_paise: string; home_collection: boolean }>(
      `SELECT name, name_bn, price_paise, home_collection FROM lab_tests WHERE facility_id = $1 AND is_active ORDER BY name`, [id]),
    query<{ doctor_id: string }>(
      `SELECT dp.doctor_id FROM doctor_practices dp JOIN doctors d ON d.id = dp.doctor_id
        WHERE dp.facility_id = $1 AND dp.is_active AND d.verification_status = 'verified'`, [id]),
  ]);
  return {
    ...card,
    departments: departments.map((d) => ({ en: d.name, bn: d.name_bn })),
    services,
    tests: tests.map((t) => ({ name: { en: t.name, bn: t.name_bn }, pricePaise: Number(t.price_paise), homeCollection: t.home_collection })),
    doctorIds: doctors.map((d) => d.doctor_id),
  };
}

export async function savedDoctorIds(userId: string): Promise<string[]> {
  return (await query<{ doctor_id: string }>(`SELECT doctor_id FROM saved_doctors WHERE user_id = $1 ORDER BY created_at DESC`, [userId])).map(
    (r) => r.doctor_id,
  );
}

export async function doctorCardsByIds(ids: string[]): Promise<DoctorCard[]> {
  if (!ids.length) return [];
  const cards = await searchDoctors({ q: "", available: false }, ids.length, ids);
  const byId = new Map(cards.map((d) => [d.id, d]));
  return ids.map((i) => byId.get(i)).filter((d): d is DoctorCard => !!d);
}
