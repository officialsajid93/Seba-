import "server-only";
import type { PoolClient } from "pg";
import { query } from "@/lib/db";

// Append-only record of sensitive changes (the table rejects UPDATE/DELETE).
// Pass the transaction client when the change happens inside one, so the audit
// row commits or rolls back together with the change it describes.
export async function audit(
  entry: {
    actorId: string | null;
    actorRole?: string | null;
    action: string; // e.g. "schedule.templates.save", "sitting.cancel", "booking.staff"
    entityType: string;
    entityId?: string | null;
    before?: unknown;
    after?: unknown;
  },
  db?: PoolClient,
): Promise<void> {
  const sql = `INSERT INTO audit_logs (actor_user_id, actor_role, action, entity_type, entity_id, before_data, after_data)
               VALUES ($1, $2::role_name, $3, $4, $5, $6::jsonb, $7::jsonb)`;
  const params = [
    entry.actorId,
    entry.actorRole ?? null,
    entry.action,
    entry.entityType,
    entry.entityId ?? null,
    entry.before === undefined ? null : JSON.stringify(entry.before),
    entry.after === undefined ? null : JSON.stringify(entry.after),
  ];
  if (db) await db.query(sql, params);
  else await query(sql, params);
}
