import "server-only";
import { query } from "@/lib/db";
import { notifyAppointment } from "./notify";

// Background jobs. Run them on a schedule (see README):
//   generate-sessions  every night  — keeps sittings created 14 days ahead
//   send-reminders     every evening — SMS for tomorrow's bookings, once each

export async function generateSessionsJob(): Promise<{ created: number }> {
  const [row] = await query<{ created: number }>(
    `SELECT generate_sessions((now() AT TIME ZONE 'Asia/Kolkata')::date, setting_int('booking_horizon_days')) AS created`,
  );
  return { created: row.created };
}

export async function sendRemindersJob(): Promise<{ sent: number }> {
  // Tomorrow in India time; each booking is reminded at most once.
  const due = await query<{ id: string }>(
    `SELECT a.id FROM appointments a JOIN consultation_sessions cs ON cs.id = a.session_id
      WHERE a.status = 'confirmed' AND cs.status IN ('scheduled', 'running_late')
        AND cs.session_date = (now() AT TIME ZONE 'Asia/Kolkata')::date + 1
        AND NOT EXISTS (SELECT 1 FROM notifications n
                         WHERE n.user_id = a.booked_by_user_id AND n.template_key = 'reminder'
                           AND n.payload->>'appointment_id' = a.id::text)`,
  );
  for (const a of due) await notifyAppointment(a.id, "reminder");
  return { sent: due.length };
}

export const jobs = {
  "generate-sessions": generateSessionsJob,
  "send-reminders": sendRemindersJob,
} as const;
export type JobName = keyof typeof jobs;
