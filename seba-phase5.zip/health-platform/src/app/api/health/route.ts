import { connection } from "next/server";
import { query } from "@/lib/db";

// Liveness + database check for uptime monitoring. Never returns secrets or
// configuration details.
export async function GET() {
  await connection(); // always run at request time, never prerendered
  const started = Date.now();
  try {
    const [row] = await query<{ ok: number; migrations: string }>(
      "SELECT 1 AS ok, (SELECT count(*) FROM schema_migrations)::text AS migrations",
    );
    return Response.json(
      { status: "ok", database: "up", migrations: Number(row.migrations), latencyMs: Date.now() - started },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (err) {
    // Reason goes to server logs only; the response never reveals configuration.
    console.error("[health] database check failed:", err instanceof Error ? err.message : err);
    return Response.json(
      { status: "degraded", database: "down" },
      { status: 503, headers: { "Cache-Control": "no-store" } },
    );
  }
}
