import { timingSafeEqual } from "node:crypto";
import { connection } from "next/server";
import { jobs, type JobName } from "@/server/jobs";

// For hosting platforms whose cron calls a URL. Requires CRON_SECRET; without
// it the endpoint does not exist. Call with:  Authorization: Bearer <CRON_SECRET>
async function run(request: Request, ctx: RouteContext<"/api/jobs/[name]">) {
  await connection();
  const secret = process.env.CRON_SECRET;
  if (!secret || secret.length < 32) return new Response("Not found", { status: 404 });
  const given = Buffer.from(request.headers.get("authorization") ?? "");
  const expected = Buffer.from(`Bearer ${secret}`);
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) {
    return new Response("Unauthorized", { status: 401 });
  }
  const { name } = await ctx.params;
  if (!(name in jobs)) return new Response("Not found", { status: 404 });
  const result = await jobs[name as JobName]();
  return Response.json({ job: name, ...result }, { headers: { "Cache-Control": "no-store" } });
}

export const GET = run;
export const POST = run;
