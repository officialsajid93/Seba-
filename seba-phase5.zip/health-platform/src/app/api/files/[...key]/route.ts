import { connection } from "next/server";
import { assertKey, sniffMime, storage, storageSigningSecret, verifySignedPath } from "@/lib/adapters/storage";

// Serves a private file only with a valid, unexpired signature. Links are
// minted server-side after the caller's permission check (patient who owns the
// prescription, or the reviewing pharmacist). Never cached, never indexed.
export async function GET(request: Request, ctx: RouteContext<"/api/files/[...key]">) {
  await connection();
  const { key: parts } = await ctx.params;
  const key = parts.join("/");
  const url = new URL(request.url);
  const exp = Number(url.searchParams.get("exp"));
  const sig = url.searchParams.get("sig") ?? "";

  try {
    assertKey(key);
  } catch {
    return new Response("Not found", { status: 404 });
  }
  if (!verifySignedPath(storageSigningSecret(), key, exp, sig)) {
    return new Response("Link expired or invalid", { status: 403, headers: { "Cache-Control": "no-store" } });
  }

  let bytes: Uint8Array;
  try {
    bytes = await storage().get(key);
  } catch {
    return new Response("Not found", { status: 404 });
  }
  return new Response(Buffer.from(bytes), {
    headers: {
      "Content-Type": sniffMime(bytes) ?? "application/octet-stream",
      "Content-Disposition": "inline",
      "Cache-Control": "private, no-store",
      "X-Robots-Tag": "noindex",
      "Content-Security-Policy": "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; sandbox",
    },
  });
}
