import type { Metadata } from "next";
import { FlaskConical } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { FacilityDirectory } from "@/components/directory/FacilityDirectory";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.diagnostics.title };
}

export default function Page({ searchParams }: PageProps<"/[lang]/diagnostics">) {
  return <FacilityDirectory section="diagnostics" types={["diagnostic_centre"]} slug="diagnostics" icon={<FlaskConical className="size-7" />} searchParams={searchParams} />;
}
