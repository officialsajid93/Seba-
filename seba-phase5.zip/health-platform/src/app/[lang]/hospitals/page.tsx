import type { Metadata } from "next";
import { Hospital } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { FacilityDirectory } from "@/components/directory/FacilityDirectory";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.hospitals.title };
}

export default function Page({ searchParams }: PageProps<"/[lang]/hospitals">) {
  return <FacilityDirectory section="hospitals" types={["hospital", "clinic"]} slug="hospitals" icon={<Hospital className="size-7" />} searchParams={searchParams} />;
}
