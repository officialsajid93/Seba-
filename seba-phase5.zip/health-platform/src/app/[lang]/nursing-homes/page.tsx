import type { Metadata } from "next";
import { BedDouble } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { FacilityDirectory } from "@/components/directory/FacilityDirectory";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.nursingHomes.title };
}

export default function Page({ searchParams }: PageProps<"/[lang]/nursing-homes">) {
  return <FacilityDirectory section="nursingHomes" types={["nursing_home"]} slug="nursing-homes" icon={<BedDouble className="size-7" />} searchParams={searchParams} />;
}
