import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { MapPin, Navigation, Phone, Siren } from "lucide-react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatMoney } from "@/lib/format";
import { directionsUrl } from "@/lib/adapters/maps";
import { doctorCardsByIds, getFacility, pick } from "@/server/directory";
import { Badge, buttonClass, Card } from "@/components/ui/primitives";
import { ListSkeleton } from "@/components/ui/states";
import { DemoBadge, DoctorCard, facilityIcon } from "@/components/directory/cards";

export async function generateMetadata({ params }: PageProps<"/[lang]/facilities/[id]">): Promise<Metadata> {
  const { id } = await params;
  const [f, lang] = await Promise.all([getFacility(id), getLocale()]);
  return f ? { title: pick(f.name, lang), robots: f.isDemo ? { index: false } : undefined } : {};
}

async function FacilityContent({ params, t, lang }: { params: PageProps<"/[lang]/facilities/[id]">["params"]; t: Dictionary; lang: string }) {
  const { id } = await params;
  const f = await getFacility(id);
  if (!f) notFound();
  const d = t.directory;
  const Icon = facilityIcon[f.type];
  const doctors = await doctorCardsByIds(f.doctorIds);
  const now = new Date();
  return (
    <div className="space-y-4">
      <Card className="space-y-3">
        <div className="flex gap-3">
          <div className="grid size-16 shrink-0 place-items-center rounded-2xl bg-teal-50 text-teal-700" aria-hidden>
            <Icon className="size-8" />
          </div>
          <div className="min-w-0">
            <h1 className="text-xl font-bold leading-snug">{pick(f.name, lang)}</h1>
            <p className="text-muted">{d.facilityTypes[f.type]} · {pick(f.town, lang)}</p>
          </div>
        </div>
        <p className="flex items-start gap-1.5 text-sm text-muted">
          <MapPin className="mt-0.5 size-4 shrink-0" aria-hidden />
          {f.address}, {pick(f.town, lang)}
        </p>
        <div className="flex flex-wrap gap-1.5">
          {f.emergency && <Badge tone="bad" icon={<Siren className="size-3.5" aria-hidden />}>{d.emergency}</Badge>}
          {f.open247 && <Badge tone="info">{d.open247}</Badge>}
          {f.isDemo && <DemoBadge label={d.demoFacility} />}
        </div>
        <div className="flex gap-2">
          {f.phone && (
            <a href={`tel:${f.phone}`} className={buttonClass("primary", "md", true)}>
              <Phone className="size-5" aria-hidden />
              {d.call}
            </a>
          )}
          {f.lat !== null && f.lng !== null && (
            <a href={directionsUrl(f.lat, f.lng)} target="_blank" rel="noopener noreferrer" className={buttonClass("secondary", "md", true)}>
              <Navigation className="size-5" aria-hidden />
              {d.directions}
            </a>
          )}
        </div>
      </Card>

      {(f.departments.length > 0 || f.services.length > 0) && (
        <Card className="space-y-3">
          {f.departments.length > 0 && (
            <section>
              <h2 className="mb-1.5 font-semibold">{d.departments}</h2>
              <div className="flex flex-wrap gap-1.5">
                {f.departments.map((x) => <Badge key={x.en} tone="brand">{pick(x, lang)}</Badge>)}
              </div>
            </section>
          )}
          {f.services.length > 0 && (
            <section>
              <h2 className="mb-1.5 font-semibold">{d.services}</h2>
              <ul className="list-inside list-disc text-muted">
                {f.services.map((x) => <li key={x.name}>{x.name}</li>)}
              </ul>
            </section>
          )}
        </Card>
      )}

      {f.tests.length > 0 && (
        <Card className="p-0">
          <h2 className="px-4 pt-4 font-semibold">{d.tests}</h2>
          <ul className="divide-y divide-line">
            {f.tests.map((x) => (
              <li key={x.name.en} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <p className="font-medium">{pick(x.name, lang)}</p>
                  {x.homeCollection && <p className="text-sm text-teal-700">{d.homeCollection}</p>}
                </div>
                <span className="shrink-0 font-semibold">{formatMoney(x.pricePaise, lang)}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {doctors.length > 0 && (
        <section className="space-y-3">
          <h2 className="pt-2 text-lg font-semibold">{d.doctorsHere}</h2>
          <ul className="space-y-3">
            {doctors.map((doc) => <li key={doc.id}><DoctorCard d={doc} lang={lang} t={t} now={now} /></li>)}
          </ul>
        </section>
      )}
    </div>
  );
}

export default async function FacilityPage({ params }: PageProps<"/[lang]/facilities/[id]">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <Suspense fallback={<ListSkeleton rows={2} label={t.states.loading} />}>
      <FacilityContent params={params} t={t} lang={lang} />
    </Suspense>
  );
}
