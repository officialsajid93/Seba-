import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { CalendarClock, MapPin, Stethoscope, Users } from "lucide-react";
import { format } from "@/i18n/config";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatMoney, formatNumber, formatSitting, formatTime } from "@/lib/format";
import { requireUser } from "@/server/auth/session";
import { getBookingContext, type BookingContext } from "@/server/booking";
import { pick } from "@/server/directory";
import { PageHeader } from "@/components/layout/PageHeader";
import { BookForm } from "@/components/booking/BookForm";
import { DemoBadge } from "@/components/directory/cards";
import { Button, ButtonLink, Card } from "@/components/ui/primitives";
import { ListSkeleton, Notice } from "@/components/ui/states";
import { joinWaitlistAction } from "../actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).booking.title, robots: { index: false } };
}

function Summary({ ctx, t, lang }: { ctx: BookingContext; t: Dictionary; lang: string }) {
  const when = formatSitting(ctx.startsAt, ctx.endsAt, lang);
  return (
    <Card className="space-y-2">
      <p className="flex items-center gap-2 font-semibold">
        <Stethoscope className="size-5 text-brand-600" aria-hidden />
        {pick(ctx.doctor.name, lang)}
      </p>
      <p className="flex items-start gap-2 text-sm text-muted">
        <MapPin className="mt-0.5 size-5 shrink-0 text-brand-600" aria-hidden />
        {pick(ctx.facility.name, lang)}, {ctx.facility.address}, {pick(ctx.facility.town, lang)}
      </p>
      <p className="flex items-center gap-2 text-sm">
        <CalendarClock className="size-5 text-brand-600" aria-hidden />
        <span className="font-semibold">{when.day}</span> · {when.time}
      </p>
      <p className="flex items-center gap-2 text-sm text-muted">
        <Users className="size-5 text-brand-600" aria-hidden />
        {format(t.booking.seatsLeft, { left: formatNumber(ctx.seatsLeft, lang), total: formatNumber(ctx.capacity, lang) })}
      </p>
      {ctx.doctor.isDemo && <DemoBadge label={t.directory.demo} />}
    </Card>
  );
}

async function BookContent({ params, t, lang }: { params: PageProps<"/[lang]/book/[sessionId]">["params"]; t: Dictionary; lang: string }) {
  const { sessionId } = await params;
  const user = await requireUser(lang, `/${lang}/book/${sessionId}`);
  const ctx = await getBookingContext(sessionId, user.id);
  if (!ctx) notFound();
  const b = t.booking;
  const relations = t.account.family.relations as Record<string, string>;

  // No profile yet: ask for the patient's name first.
  if (ctx.patients.length === 0) {
    return (
      <div className="space-y-4">
        <Summary ctx={ctx} t={t} lang={lang} />
        <ButtonLink href={`/${lang}/profile/details?next=${encodeURIComponent(`/${lang}/book/${sessionId}`)}`} full>
          {t.account.detailsTitle}
        </ButtonLink>
      </div>
    );
  }

  if (!ctx.bookable) {
    return (
      <div className="space-y-4">
        <Summary ctx={ctx} t={t} lang={lang} />
        <Notice tone="warn">{b.notBookable}</Notice>
        <ButtonLink href={`/${lang}/doctors/${ctx.doctor.id}`} variant="secondary" full>{t.directory.viewProfile}</ButtonLink>
      </div>
    );
  }

  if (ctx.seatsLeft === 0) {
    const self = ctx.patients[0];
    return (
      <div className="space-y-4">
        <Summary ctx={ctx} t={t} lang={lang} />
        <Card className="space-y-3">
          <h2 className="text-lg font-semibold">{b.fullTitle}</h2>
          {ctx.waitlisted ? (
            <Notice tone="ok">{b.waitlistJoined}</Notice>
          ) : (
            <>
              <p className="text-muted">{b.waitlistBody}</p>
              <form action={joinWaitlistAction}>
                <input type="hidden" name="lang" value={lang} />
                <input type="hidden" name="sessionId" value={ctx.sessionId} />
                <input type="hidden" name="patientId" value={self.id} />
                <Button type="submit" full>{b.joinWaitlist}</Button>
              </form>
            </>
          )}
        </Card>
      </div>
    );
  }

  const slots = ctx.mode === "time_slot" ? ctx.freeSlots.map((d) => ({ value: d.toISOString(), label: formatTime(d, lang) })) : null;
  return (
    <div className="space-y-4">
      <Summary ctx={ctx} t={t} lang={lang} />
      <Card>
        <BookForm
          lang={lang}
          sessionId={ctx.sessionId}
          t={b}
          slots={slots}
          patients={ctx.patients.map((p) => ({
            id: p.id,
            name: p.name,
            alreadyBooked: p.alreadyBooked,
            relationLabel: p.relation === "self" ? t.account.family.you : relations[p.relation] ?? p.relation,
          }))}
          summary={{
            fee: formatMoney(ctx.feePaise, lang),
            note: ctx.mode === "serial_token" ? format(b.serialNote, { time: formatTime(ctx.startsAt, lang) }) : b.slotNote,
          }}
        />
      </Card>
    </div>
  );
}

export default async function BookPage({ params }: PageProps<"/[lang]/book/[sessionId]">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.booking.title} />
      <Suspense fallback={<ListSkeleton rows={2} label={t.states.loading} />}>
        <BookContent params={params} t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
