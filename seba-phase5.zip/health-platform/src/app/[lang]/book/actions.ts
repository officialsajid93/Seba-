"use server";

import { redirect } from "next/navigation";
import { refresh } from "next/cache";
import { isActiveLocale } from "@/i18n/config";
import { getCurrentUser } from "@/server/auth/session";
import { bookForUser, cancelMine, joinWaitlist, rescheduleMine } from "@/server/booking";

export type BookState = { error?: string };

const langOf = (fd: FormData) => {
  const l = String(fd.get("lang") ?? "");
  return isActiveLocale(l) ? l : "bn";
};
const str = (fd: FormData, k: string) => String(fd.get(k) ?? "");

async function userOrLogin(lang: string, next: string) {
  const user = await getCurrentUser();
  if (!user) redirect(`/${lang}/login?next=${encodeURIComponent(next)}`);
  return user;
}

export async function bookAction(_prev: BookState, fd: FormData): Promise<BookState> {
  const lang = langOf(fd);
  const sessionId = str(fd, "sessionId");
  const user = await userOrLogin(lang, `/${lang}/book/${sessionId}`);
  const res = await bookForUser({ userId: user.id, sessionId, patientId: str(fd, "patientId"), slot: str(fd, "slot") || null });
  if (!res.ok) return { error: res.error === "INVALID" ? "PATIENT_NOT_OWNED" : res.error };
  redirect(`/${lang}/bookings/${res.appointmentId}?new=1`);
}

export async function joinWaitlistAction(fd: FormData): Promise<void> {
  const lang = langOf(fd);
  const sessionId = str(fd, "sessionId");
  const user = await userOrLogin(lang, `/${lang}/book/${sessionId}`);
  await joinWaitlist(user.id, sessionId, str(fd, "patientId"));
  refresh();
}

export async function cancelAction(_prev: BookState, fd: FormData): Promise<BookState> {
  const lang = langOf(fd);
  const id = str(fd, "appointmentId");
  const user = await userOrLogin(lang, `/${lang}/bookings/${id}`);
  const res = await cancelMine(user.id, id);
  if (!res.ok) return { error: res.error === "INVALID" ? "NOT_FOUND" : res.error };
  redirect(`/${lang}/bookings/${id}?cancelled=1`);
}

export async function rescheduleAction(_prev: BookState, fd: FormData): Promise<BookState> {
  const lang = langOf(fd);
  const id = str(fd, "appointmentId");
  const user = await userOrLogin(lang, `/${lang}/bookings/${id}`);
  const res = await rescheduleMine(user.id, id, str(fd, "sessionId"));
  if (!res.ok) return { error: res.error === "INVALID" ? "NOT_FOUND" : res.error };
  redirect(`/${lang}/bookings/${res.appointmentId}?new=1`);
}
