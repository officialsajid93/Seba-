import type { Metadata } from "next";
import { Suspense } from "react";
import { cookies } from "next/headers";
import { launchTowns } from "@/config/brand";
import type { ActiveLocale } from "@/i18n/config";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { TownPicker } from "@/components/home/TownPicker";
import { TOWN_COOKIE } from "@/components/home/TownChip";
import { Card } from "@/components/ui/primitives";
import { ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).location.choose };
}

const districtsBn: Record<string, string> = { Murshidabad: "মুর্শিদাবাদ", Malda: "মালদা" };

async function Picker({ lang }: { lang: ActiveLocale }) {
  const current = (await cookies()).get(TOWN_COOKIE)?.value;
  const towns = launchTowns.map((t) => ({
    slug: t.slug,
    name: t[lang],
    district: lang === "bn" ? districtsBn[t.district] ?? t.district : t.district,
  }));
  return <TownPicker lang={lang} towns={towns} current={current} />;
}

export default async function LocationPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div className="space-y-4">
      <PageHeader title={t.location.choose} subtitle={t.location.launchNote} />
      <Card className="p-0">
        <Suspense fallback={<div className="p-4"><ListSkeleton rows={4} label={t.states.loading} /></div>}>
          <Picker lang={lang} />
        </Suspense>
      </Card>
    </div>
  );
}
