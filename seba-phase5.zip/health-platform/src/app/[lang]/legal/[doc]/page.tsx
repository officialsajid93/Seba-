import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { TriangleAlert } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { Notice } from "@/components/ui/states";

const docs = ["privacy", "terms", "cancellation"] as const;
type Doc = (typeof docs)[number];
const isDoc = (v: string): v is Doc => (docs as readonly string[]).includes(v);

export async function generateStaticParams() {
  return docs.map((doc) => ({ doc }));
}

export async function generateMetadata({ params }: PageProps<"/[lang]/legal/[doc]">): Promise<Metadata> {
  const { doc } = await params;
  if (!isDoc(doc)) return {};
  return { title: (await getDictionary()).screens.legal[doc], robots: { index: false } };
}

// Policy text is written with a lawyer before launch; until then the page says so.
export default async function LegalPage({ params }: PageProps<"/[lang]/legal/[doc]">) {
  const { doc } = await params;
  if (!isDoc(doc)) notFound();
  const t = await getDictionary();
  return (
    <div className="space-y-4">
      <PageHeader title={t.screens.legal[doc]} />
      <Notice tone="warn" icon={<TriangleAlert className="size-5" />}>
        {t.screens.legal.draftNotice}
      </Notice>
    </div>
  );
}
