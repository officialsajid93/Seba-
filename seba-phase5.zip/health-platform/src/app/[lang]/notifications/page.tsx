import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { Bell } from "lucide-react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatSitting } from "@/lib/format";
import { requireUser } from "@/server/auth/session";
import { listMyNotifications } from "@/server/booking";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).booking.notifications.title, robots: { index: false } };
}

async function List({ t, lang }: { t: Dictionary; lang: string }) {
  const user = await requireUser(lang, `/${lang}/notifications`);
  const items = await listMyNotifications(user.id);
  if (!items.length) {
    return <Card className="p-0"><EmptyState icon={<Bell className="size-7" />} title={t.booking.notifications.empty} /></Card>;
  }
  return (
    <Card className="p-0">
      <ul className="divide-y divide-line">
        {items.map((n) => {
          const when = formatSitting(n.created_at, n.created_at, lang);
          const body = (
            <>
              <p>{n.payload.text}</p>
              <p className="mt-1 text-xs text-muted">{when.day} · {when.time.split(" – ")[0]}</p>
            </>
          );
          return (
            <li key={n.id}>
              {n.payload.appointment_id ? (
                <Link href={`/${lang}/bookings/${n.payload.appointment_id}`} className="block px-4 py-3 hover:bg-canvas">{body}</Link>
              ) : (
                <div className="px-4 py-3">{body}</div>
              )}
            </li>
          );
        })}
      </ul>
    </Card>
  );
}

export default async function NotificationsPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.booking.notifications.title} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <List t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
