import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { ButtonLink } from "@/components/ui/primitives";
import { ErrorMessage } from "@/components/ui/states";

export default async function NotFound() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <ErrorMessage
      asPageTitle
      title={t.states.notFoundTitle}
      body={t.states.notFoundBody}
      action={<ButtonLink href={`/${lang}`}>{t.states.goHome}</ButtonLink>}
    />
  );
}
