import type { Metadata, Viewport } from "next";
import { Suspense } from "react";
import "@fontsource-variable/inter";
import "@fontsource-variable/noto-sans-bengali";
import "../globals.css";
import { brand } from "@/config/brand";
import { activeLocales } from "@/i18n/config";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { TopBar } from "@/components/layout/TopBar";
import { BottomNav, BottomNavView, type BottomNavLabels } from "@/components/layout/BottomNav";
import { isDevMode } from "@/lib/dev-mode";

export async function generateStaticParams() {
  return activeLocales.map((lang) => ({ lang }));
}

export async function generateMetadata(): Promise<Metadata> {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  const name = lang === "bn" ? brand.nameBn : brand.name;
  return {
    title: { default: `${name} — ${t.meta.tagline}`, template: `%s · ${name}` },
    description: t.meta.description,
    applicationName: brand.name,
    alternates: { languages: Object.fromEntries(activeLocales.map((l) => [l, `/${l}`])) },
    appleWebApp: { capable: true, title: name, statusBarStyle: "default" },
    formatDetection: { telephone: false },
  };
}

export const viewport: Viewport = {
  themeColor: brand.themeColor,
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({ children }: LayoutProps<"/[lang]">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  const navLabels: BottomNavLabels = {
    home: t.nav.home,
    doctors: t.nav.doctors,
    medicines: t.nav.medicines,
    bookings: t.nav.bookings,
    profile: t.nav.profile,
    mainMenu: t.nav.mainMenu,
  };
  return (
    <html lang={lang}>
      <body className="min-h-dvh">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-3 focus:top-3 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:font-semibold focus:text-brand-700 focus:shadow-card"
        >
          {t.nav.skipToContent}
        </a>
        {isDevMode() && (
          <div className="bg-warn-50 px-4 py-1.5 text-center text-xs font-semibold text-warn-700">
            {t.footer.devMode}
          </div>
        )}
        <TopBar lang={lang} switchTo={t.lang.switchTo} switchLabel={t.lang.switchLabel} />
        <main id="main" className="mx-auto max-w-lg px-4 pb-28 pt-5">
          {children}
        </main>
        <Suspense fallback={<BottomNavView lang={lang} labels={navLabels} rest={null} />}>
          <BottomNav lang={lang} labels={navLabels} />
        </Suspense>
      </body>
    </html>
  );
}
