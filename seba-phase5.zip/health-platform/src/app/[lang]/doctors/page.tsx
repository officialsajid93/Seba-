import type { Metadata } from "next";
import { Suspense } from "react";
import { Stethoscope } from "lucide-react";
import { format } from "@/i18n/config";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatNumber } from "@/lib/format";
import { listSpecialities, listTowns, parseSearchParams, searchDoctors } from "@/server/directory";
import { SearchBar } from "@/components/home/SearchBar";
import { PageHeader } from "@/components/layout/PageHeader";
import { DoctorCard } from "@/components/directory/cards";
import { DoctorFilters } from "@/components/directory/DoctorFilters";
import { Card } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.doctors.title };
}

async function Results({ t, lang, searchParams }: { t: Dictionary; lang: string; searchParams: PageProps<"/[lang]/doctors">["searchParams"] }) {
  const input = parseSearchParams(await searchParams);
  const [doctors, specialities, towns] = await Promise.all([searchDoctors(input), listSpecialities(), listTowns()]);
  const now = new Date();
  const filtered = Boolean(input.q || input.speciality || input.town || input.maxFee || input.available);
  return (
    <div className="space-y-4">
      <SearchBar lang={lang} action={`/${lang}/doctors`} defaultValue={input.q} placeholder={t.search.placeholder} label={t.search.label} buttonLabel={t.search.button} />
      <DoctorFilters lang={lang} t={t} input={input} specialities={specialities} towns={towns} action={`/${lang}/doctors`} />
      {doctors.length > 0 ? (
        <>
          <p className="text-sm font-semibold text-muted" role="status">
            {format(t.directory.results, { count: formatNumber(doctors.length, lang) })}
          </p>
          <ul className="space-y-3">
            {doctors.map((d) => (
              <li key={d.id}>
                <DoctorCard d={d} lang={lang} t={t} now={now} />
              </li>
            ))}
          </ul>
        </>
      ) : (
        <Card className="p-0">
          <EmptyState
            icon={<Stethoscope className="size-7" />}
            title={filtered ? t.directory.noResults : t.screens.doctors.emptyTitle}
            body={filtered ? undefined : t.screens.doctors.emptyBody}
          />
        </Card>
      )}
    </div>
  );
}

export default async function DoctorsPage({ searchParams }: PageProps<"/[lang]/doctors">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.screens.doctors.title} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <Results t={t} lang={lang} searchParams={searchParams} />
      </Suspense>
    </div>
  );
}
