import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { UserPlus } from "lucide-react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { requireUser } from "@/server/auth/session";
import { facilityRole } from "@/server/provider/access";
import { managedPractices, upcomingSittings } from "@/server/provider/service";
import { query } from "@/lib/db";
import { PageHeader } from "@/components/layout/PageHeader";
import { PracticeCard } from "@/components/provider/cards";
import { ButtonLink } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton, Notice } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).provider.portal, robots: { index: false } };
}

async function Facility({ params, t, lang }: { params: PageProps<"/[lang]/provider/facility/[id]">["params"]; t: Dictionary; lang: string }) {
  const { id } = await params;
  const user = await requireUser(lang, `/${lang}/provider/facility/${id}`);
  const role = await facilityRole(user.id, id);
  if (!role) notFound();
  const [[facility], practices] = await Promise.all([
    query<{ name: string; name_bn: string | null; is_published: boolean }>(`SELECT name, name_bn, is_published FROM facilities WHERE id = $1`, [id]),
    managedPractices(user.id, id),
  ]);
  const sittings = await upcomingSittings(practices.filter((p) => p.active).map((p) => p.id), 7);
  const now = new Date();
  const p = t.provider;
  return (
    <div className="space-y-4">
      <PageHeader title={lang === "bn" && facility.name_bn ? facility.name_bn : facility.name} subtitle={p.role[role]} />
      {!facility.is_published && <Notice tone="warn">{p.waitingVerification}</Notice>}
      {practices.length === 0 ? (
        <EmptyState icon={<UserPlus className="size-7" />} title={p.addDoctor} body={p.doctorForm.body} />
      ) : (
        practices.map((pr) => (
          <PracticeCard key={pr.id} p={pr} lang={lang} t={t} now={now} sittings={sittings.filter((s) => s.practiceId === pr.id)} />
        ))
      )}
      {role === "facility_admin" && (
        <ButtonLink href={`/${lang}/provider/facility/${id}/add-doctor`} variant="secondary" full>
          <UserPlus className="size-5" aria-hidden />
          {p.addDoctor}
        </ButtonLink>
      )}
    </div>
  );
}

export default async function FacilityPage({ params }: PageProps<"/[lang]/provider/facility/[id]">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
      <Facility params={params} t={t} lang={lang} />
    </Suspense>
  );
}
