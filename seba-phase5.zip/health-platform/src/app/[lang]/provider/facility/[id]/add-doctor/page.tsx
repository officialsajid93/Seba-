import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { requireUser } from "@/server/auth/session";
import { listSpecialities, pick } from "@/server/directory";
import { canAddDoctors } from "@/server/provider/service";
import { PageHeader } from "@/components/layout/PageHeader";
import { AddDoctorForm } from "@/components/provider/forms";
import { Card } from "@/components/ui/primitives";
import { ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).provider.doctorForm.title, robots: { index: false } };
}

async function Form({ params, t, lang }: { params: PageProps<"/[lang]/provider/facility/[id]/add-doctor">["params"]; t: Dictionary; lang: string }) {
  const { id } = await params;
  const user = await requireUser(lang, `/${lang}/provider/facility/${id}/add-doctor`);
  if (!(await canAddDoctors(user.id, id))) notFound();
  const specialities = await listSpecialities();
  return <AddDoctorForm lang={lang} facilityId={id} t={t.provider} specialities={specialities.map((s) => ({ slug: s.slug, name: pick(s.name, lang) }))} />;
}

export default async function AddDoctorPage({ params }: PageProps<"/[lang]/provider/facility/[id]/add-doctor">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.provider.doctorForm.title} subtitle={t.provider.doctorForm.body} />
      <Card>
        <Suspense fallback={<ListSkeleton rows={2} label={t.states.loading} />}>
          <Form params={params} t={t} lang={lang} />
        </Suspense>
      </Card>
    </div>
  );
}
