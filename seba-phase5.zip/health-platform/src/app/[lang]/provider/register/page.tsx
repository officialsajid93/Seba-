import type { Metadata } from "next";
import { Suspense } from "react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { requireUser } from "@/server/auth/session";
import { listTowns, pick } from "@/server/directory";
import { PageHeader } from "@/components/layout/PageHeader";
import { RegisterFacilityForm } from "@/components/provider/forms";
import { Card } from "@/components/ui/primitives";
import { ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).provider.registerForm.title, robots: { index: false } };
}

async function Form({ t, lang }: { t: Dictionary; lang: string }) {
  await requireUser(lang, `/${lang}/provider/register`);
  const towns = await listTowns();
  return (
    <RegisterFacilityForm
      lang={lang}
      t={t.provider}
      types={t.directory.facilityTypes}
      towns={towns.map((x) => ({ slug: x.slug, name: pick(x.name, lang) }))}
    />
  );
}

export default async function RegisterPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.provider.registerForm.title} subtitle={t.provider.registerForm.body} />
      <Card>
        <Suspense fallback={<ListSkeleton rows={2} label={t.states.loading} />}>
          <Form t={t} lang={lang} />
        </Suspense>
      </Card>
    </div>
  );
}
