"use server";

import { redirect } from "next/navigation";
import { refresh } from "next/cache";
import { isActiveLocale } from "@/i18n/config";
import { getCurrentUser } from "@/server/auth/session";
import {
  addException,
  cancelSitting,
  confirmSchedule,
  exceptionSchema,
  parseTemplates,
  saveTemplates,
  setRunningLate,
  setVisitStatus,
  staffBook,
} from "@/server/provider/service";
import { addDoctorToFacility, registerFacility } from "@/server/provider/onboarding";

// All provider actions: re-check the session, delegate to the service (which
// checks the role for the exact practice / sitting / booking and audit-logs).

export type ActionState = { ok?: boolean; error?: string; field?: string; values?: Record<string, number> };

const langOf = (fd: FormData) => {
  const l = String(fd.get("lang") ?? "");
  return isActiveLocale(l) ? l : "bn";
};
const str = (fd: FormData, k: string) => String(fd.get(k) ?? "");

async function provider(fd: FormData, next: string) {
  const lang = langOf(fd);
  const user = await getCurrentUser();
  if (!user) redirect(`/${lang}/login?next=${encodeURIComponent(`/${lang}${next}`)}`);
  return user;
}

export async function confirmScheduleAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const user = await provider(fd, "/provider");
  const res = await confirmSchedule(user.id, str(fd, "practiceId"));
  if (!res.ok) return { error: res.error };
  refresh();
  return { ok: true };
}

export async function saveScheduleAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const practiceId = str(fd, "practiceId");
  const user = await provider(fd, `/provider/practice/${practiceId}`);
  const parsed = parseTemplates(fd);
  if (!parsed.ok) return { error: parsed.error };
  const res = await saveTemplates(user.id, practiceId, parsed.value);
  if (!res.ok) return { error: res.error };
  refresh();
  return { ok: true, values: { created: res.value!.created, kept: res.value!.keptWithBookings } };
}

export async function addExceptionAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const practiceId = str(fd, "practiceId");
  const user = await provider(fd, `/provider/practice/${practiceId}`);
  const kind = str(fd, "kind");
  const parsed = exceptionSchema.safeParse({
    kind,
    from: str(fd, "from"),
    to: kind === "extra_session" ? undefined : str(fd, "to") || str(fd, "from"),
    newStart: str(fd, "newStart") || undefined,
    newEnd: str(fd, "newEnd") || undefined,
    capacity: str(fd, "capacity") || undefined,
    reason: str(fd, "reason"),
    allPractices: fd.get("allPractices") === "on",
  });
  if (!parsed.success) return { error: "INVALID" };
  const res = await addException(user.id, practiceId, parsed.data);
  if (!res.ok) return { error: res.error };
  refresh();
  return { ok: true, values: { n: res.value!.affected } };
}

export async function cancelSittingAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const sessionId = str(fd, "sessionId");
  const user = await provider(fd, `/provider/sitting/${sessionId}`);
  const res = await cancelSitting(user.id, sessionId, str(fd, "reason").trim());
  if (!res.ok) return { error: res.error };
  refresh();
  return { ok: true, values: { n: res.value!.affected } };
}

export async function runningLateAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const sessionId = str(fd, "sessionId");
  const user = await provider(fd, `/provider/sitting/${sessionId}`);
  const raw = str(fd, "minutes");
  const res = await setRunningLate(user.id, sessionId, raw === "clear" ? null : Number(raw));
  if (!res.ok) return { error: res.error };
  refresh();
  return { ok: true, values: { n: res.value!.notified, late: raw === "clear" ? 0 : 1 } };
}

export async function visitAction(fd: FormData): Promise<void> {
  const user = await provider(fd, "/provider");
  const to = str(fd, "to");
  if (to !== "checked_in" && to !== "completed" && to !== "no_show") return;
  await setVisitStatus(user.id, str(fd, "appointmentId"), to);
  refresh();
}

export async function staffBookAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const sessionId = str(fd, "sessionId");
  const user = await provider(fd, `/provider/sitting/${sessionId}`);
  const res = await staffBook(user.id, sessionId, { name: str(fd, "name"), phone: str(fd, "phone") });
  if (!res.ok) return { error: res.error };
  refresh();
  return { ok: true, values: { serial: res.value!.serial } };
}

export async function registerFacilityAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const lang = langOf(fd);
  const user = await provider(fd, "/provider/register");
  const res = await registerFacility(
    user.id,
    {
      type: str(fd, "type"), name: str(fd, "name"), nameBn: str(fd, "nameBn"), address: str(fd, "address"),
      town: str(fd, "town"), pincode: str(fd, "pincode"), phone: str(fd, "phone"), licenceNo: str(fd, "licenceNo"),
    },
    [{ docType: "establishment_licence", file: fd.get("licence") as File }],
  );
  if (!res.ok) return { error: res.error, field: "field" in res ? res.field : undefined };
  redirect(`/${lang}/provider?registered=1`);
}

export async function addDoctorAction(_p: ActionState, fd: FormData): Promise<ActionState> {
  const lang = langOf(fd);
  const facilityId = str(fd, "facilityId");
  const user = await provider(fd, `/provider/facility/${facilityId}/add-doctor`);
  const res = await addDoctorToFacility(
    user.id,
    facilityId,
    {
      fullName: str(fd, "fullName"), fullNameBn: str(fd, "fullNameBn"), registrationNumber: str(fd, "registrationNumber"),
      council: str(fd, "council"), degrees: str(fd, "degrees"), speciality: str(fd, "speciality"),
      practisingSince: str(fd, "practisingSince") || undefined, feeRupees: str(fd, "feeRupees"), mode: str(fd, "mode"),
    },
    [{ docType: "medical_registration", file: fd.get("certificate") as File }],
  );
  if (!res.ok) return { error: res.error, field: "field" in res ? res.field : undefined };
  redirect(`/${lang}/provider/practice/${res.practiceId}?added=1`);
}
