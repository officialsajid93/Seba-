import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { Phone } from "lucide-react";
import { format } from "@/i18n/config";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatNumber, formatSitting, formatTime, istDate } from "@/lib/format";
import { requireUser } from "@/server/auth/session";
import { pick } from "@/server/directory";
import { sittingQueue } from "@/server/provider/service";
import { StatusBadge } from "@/components/booking/parts";
import { CancelSittingForm, LateForm, StaffBookForm } from "@/components/provider/forms";
import { Badge, Button, Card } from "@/components/ui/primitives";
import { ListSkeleton, Notice } from "@/components/ui/states";
import { visitAction } from "../../actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).provider.sitting.queue, robots: { index: false } };
}

function VisitButton({ lang, id, to, label, variant = "secondary" }: { lang: string; id: string; to: string; label: string; variant?: "primary" | "secondary" | "ghost" }) {
  return (
    <form action={visitAction}>
      <input type="hidden" name="lang" value={lang} />
      <input type="hidden" name="appointmentId" value={id} />
      <input type="hidden" name="to" value={to} />
      <Button type="submit" size="sm" variant={variant}>{label}</Button>
    </form>
  );
}

async function Queue({ params, t, lang }: { params: PageProps<"/[lang]/provider/sitting/[id]">["params"]; t: Dictionary; lang: string }) {
  const { id } = await params;
  const user = await requireUser(lang, `/${lang}/provider/sitting/${id}`);
  const q = await sittingQueue(user.id, id);
  if (!q) notFound();
  const { sitting, patients } = q;
  const s = t.provider.sitting;
  const when = formatSitting(sitting.startsAt, sitting.endsAt, lang);
  const now = new Date();
  const active = sitting.status !== "cancelled" && sitting.endsAt > now;
  const canMarkVisits = istDate(sitting.startsAt) <= istDate(now);
  const live = patients.filter((p) => !["cancelled_by_patient", "cancelled_by_provider"].includes(p.status));
  const cancelled = patients.length - live.length;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">{when.day} · {when.time}</h1>
        <p className="text-muted">{pick(sitting.doctor, lang)} · {pick(sitting.facility, lang)}</p>
        <p className="mt-1 text-sm font-semibold">
          {format(t.provider.booked, { booked: formatNumber(sitting.booked, lang), capacity: formatNumber(sitting.capacity, lang) })}
          {sitting.checkedIn > 0 && ` · ${format(t.provider.seen, { n: formatNumber(sitting.checkedIn, lang) })}`}
        </p>
      </div>
      {sitting.status === "cancelled" && <Notice tone="bad">{t.availability.cancelled}{sitting.note ? `: ${sitting.note}` : ""}</Notice>}
      {sitting.status === "running_late" && <Notice tone="warn">{s.lateNow}{sitting.note ? `: ${sitting.note}` : ""}</Notice>}

      <Card className="p-0">
        <h2 className="px-4 pt-4 text-lg font-semibold">{s.queue}</h2>
        {live.length === 0 ? (
          <p className="px-4 py-4 text-muted">{s.empty}</p>
        ) : (
          <ol className="divide-y divide-line">
            {live.map((p) => (
              <li key={p.id} className="space-y-2 px-4 py-3">
                <div className="flex items-center gap-3">
                  <span className="grid size-11 shrink-0 place-items-center rounded-full bg-brand-50 text-lg font-bold text-brand-700">
                    {p.slot_starts_at ? formatTime(p.slot_starts_at, lang).replace(/\s?[AP]M$/i, "") : formatNumber(p.token_number, lang)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{p.patient}</p>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <StatusBadge status={p.status} t={t.booking} />
                      <Badge tone={p.by_clinic ? "neutral" : "brand"}>{p.by_clinic ? s.byClinic : s.online}</Badge>
                    </div>
                  </div>
                  <a href={`tel:${p.phone}`} className="grid size-11 shrink-0 place-items-center rounded-full text-brand-700 ring-1 ring-brand-200" aria-label={`${s.call}: ${p.patient}`}>
                    <Phone className="size-5" aria-hidden />
                  </a>
                </div>
                {canMarkVisits && (
                  <div className="flex flex-wrap gap-2 pl-14">
                    {(p.status === "confirmed" || p.status === "no_show") && <VisitButton lang={lang} id={p.id} to="checked_in" label={s.checkIn} variant="primary" />}
                    {(p.status === "confirmed" || p.status === "checked_in") && <VisitButton lang={lang} id={p.id} to="completed" label={s.done} />}
                    {(p.status === "confirmed" || p.status === "checked_in") && <VisitButton lang={lang} id={p.id} to="no_show" label={s.absent} variant="ghost" />}
                  </div>
                )}
              </li>
            ))}
          </ol>
        )}
        {cancelled > 0 && <p className="px-4 pb-3 text-xs text-muted">+{formatNumber(cancelled, lang)} {t.booking.statuses.cancelled_by_patient.toLowerCase()}</p>}
      </Card>

      {active && (
        <>
          {sitting.mode === "serial_token" && (
            <Card className="space-y-3">
              <h2 className="text-lg font-semibold">{s.addPatient}</h2>
              <StaffBookForm lang={lang} sessionId={sitting.id} t={t.provider} />
            </Card>
          )}
          <Card className="space-y-3">
            <h2 className="text-lg font-semibold">{s.markLate}</h2>
            <LateForm lang={lang} sessionId={sitting.id} t={t.provider} late={sitting.status === "running_late"} />
          </Card>
          <CancelSittingForm lang={lang} sessionId={sitting.id} t={t.provider} />
        </>
      )}
    </div>
  );
}

export default async function SittingPage({ params }: PageProps<"/[lang]/provider/sitting/[id]">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
      <Queue params={params} t={t} lang={lang} />
    </Suspense>
  );
}
