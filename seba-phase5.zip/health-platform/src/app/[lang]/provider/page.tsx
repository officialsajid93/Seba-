import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { Building2, ChevronRight, Plus } from "lucide-react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatSitting } from "@/lib/format";
import { requireUser } from "@/server/auth/session";
import { hasProviderAccess } from "@/server/provider/access";
import { myPendingRequests } from "@/server/provider/onboarding";
import { providerHome, upcomingSittings } from "@/server/provider/service";
import { PageHeader } from "@/components/layout/PageHeader";
import { PracticeCard, SittingRow } from "@/components/provider/cards";
import { Badge, ButtonLink, Card } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton, Notice } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).provider.portal, robots: { index: false } };
}

type SP = PageProps<"/[lang]/provider">["searchParams"];

async function Home({ t, lang, searchParams }: { t: Dictionary; lang: string; searchParams: SP }) {
  const user = await requireUser(lang, `/${lang}/provider`);
  const [{ scope, practices, today }, requests, sp] = await Promise.all([providerHome(user.id), myPendingRequests(user.id), searchParams]);
  const p = t.provider;
  const now = new Date();
  const week = await upcomingSittings(practices.filter((x) => x.active).map((x) => x.id), 7);

  const requestList = requests.length > 0 && (
    <section className="space-y-2">
      <h2 className="text-lg font-semibold">{p.myRequests}</h2>
      <Card className="p-0">
        <ul className="divide-y divide-line">
          {requests.map((r) => (
            <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
              <div className="min-w-0">
                <p className="truncate font-semibold">{r.name}</p>
                <p className="text-xs text-muted">
                  {(p.entity as Record<string, string>)[r.entity_type]} · {formatSitting(r.submitted_at, r.submitted_at, lang).day}
                </p>
              </div>
              <Badge tone={r.status === "verified" ? "ok" : r.status === "rejected" ? "bad" : "warn"}>
                {(p.reqStatus as Record<string, string>)[r.status] ?? r.status}
              </Badge>
            </li>
          ))}
        </ul>
      </Card>
    </section>
  );

  if (!hasProviderAccess(scope)) {
    return (
      <div className="space-y-4">
        <Card className="p-0">
          <EmptyState
            icon={<Building2 className="size-7" />}
            title={p.noAccessTitle}
            body={p.noAccessBody}
            action={<ButtonLink href={`/${lang}/provider/register`}>{p.register}</ButtonLink>}
          />
        </Card>
        {requestList}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {sp.registered === "1" && <Notice tone="ok">{p.registerForm.done}</Notice>}

      <section className="space-y-2">
        <h2 className="text-lg font-semibold">{p.today}</h2>
        {today.length ? (
          <ul className="space-y-2">{today.map((s) => <li key={s.id}><SittingRow s={s} lang={lang} t={t} showDoctor /></li>)}</ul>
        ) : (
          <p className="rounded-control bg-white px-4 py-3 text-muted ring-1 ring-line">{p.noToday}</p>
        )}
      </section>

      {scope.facilities.length > 0 && (
        <section className="space-y-2">
          <h2 className="text-lg font-semibold">{p.yourPlaces}</h2>
          <Card className="p-0">
            <ul className="divide-y divide-line">
              {scope.facilities.map((f) => (
                <li key={f.id}>
                  <Link href={`/${lang}/provider/facility/${f.id}`} className="flex min-h-14 items-center gap-3 px-4 hover:bg-canvas">
                    <Building2 className="size-5 text-brand-600" aria-hidden />
                    <span className="flex-1">
                      <span className="block font-semibold">{lang === "bn" && f.nameBn ? f.nameBn : f.name}</span>
                      <span className="block text-xs text-muted">
                        {p.role[f.role]}{!f.published && ` · ${p.waitingVerification}`}
                      </span>
                    </span>
                    <ChevronRight className="size-5 text-subtle" aria-hidden />
                  </Link>
                </li>
              ))}
            </ul>
          </Card>
        </section>
      )}

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">{p.yourDoctors}</h2>
        {practices.map((pr) => (
          <PracticeCard key={pr.id} p={pr} lang={lang} t={t} now={now} sittings={week.filter((s) => s.practiceId === pr.id)} />
        ))}
      </section>

      <ButtonLink href={`/${lang}/provider/register`} variant="secondary" full>
        <Plus className="size-5" aria-hidden />
        {p.register}
      </ButtonLink>
      {requestList}
    </div>
  );
}

export default async function ProviderPage({ searchParams }: PageProps<"/[lang]/provider">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.provider.portal} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <Home t={t} lang={lang} searchParams={searchParams} />
      </Suspense>
    </div>
  );
}
