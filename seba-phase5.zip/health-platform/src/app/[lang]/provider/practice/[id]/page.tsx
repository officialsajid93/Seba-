import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatDay, istDate } from "@/lib/format";
import { requireUser } from "@/server/auth/session";
import { pick } from "@/server/directory";
import { practiceDetail } from "@/server/provider/service";
import { PageHeader } from "@/components/layout/PageHeader";
import { SittingRow } from "@/components/provider/cards";
import { ConfirmScheduleButton, ExceptionForm, ScheduleEditor } from "@/components/provider/forms";
import { ConfirmedAgo } from "@/components/ui/availability";
import { Badge, Card } from "@/components/ui/primitives";
import { ListSkeleton, Notice } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).provider.schedule.title, robots: { index: false } };
}

type P = PageProps<"/[lang]/provider/practice/[id]">;

async function Practice({ params, searchParams, t, lang }: { params: P["params"]; searchParams: P["searchParams"]; t: Dictionary; lang: string }) {
  const { id } = await params;
  const user = await requireUser(lang, `/${lang}/provider/practice/${id}`);
  const detail = await practiceDetail(user.id, id);
  if (!detail) notFound();
  const sp = await searchParams;
  const { practice, templates, exceptions, sittings, role } = detail;
  const p = t.provider;
  const now = new Date();
  const today = istDate(now);
  const dateLabel = (iso: string) => formatDay(new Date(`${iso}T12:00:00+05:30`), lang);

  return (
    <div className="space-y-4">
      <PageHeader title={pick(practice.doctor, lang)} subtitle={pick(practice.facility, lang)} />
      {sp.added === "1" && <Notice tone="ok">{p.doctorForm.done}</Notice>}
      {(!practice.active || !practice.doctor.verified) && <Notice tone="warn">{p.waitingVerification}</Notice>}

      {practice.active && practice.doctor.verified && (
        <Card className="space-y-3">
          {practice.stale ? (
            <>
              <Notice tone="warn">{p.scheduleStale}</Notice>
              <ConfirmScheduleButton lang={lang} practiceId={practice.id} t={p} />
            </>
          ) : (
            <ConfirmedAgo t={t.availability} confirmedAt={practice.confirmedAt} now={now} />
          )}
        </Card>
      )}

      <Card className="space-y-3">
        <h2 className="text-lg font-semibold">{p.schedule.title}</h2>
        <ScheduleEditor lang={lang} practiceId={practice.id} t={p} mode={practice.mode} initial={templates} />
      </Card>

      <Card className="space-y-3">
        <h2 className="text-lg font-semibold">{p.changes.title}</h2>
        <ExceptionForm lang={lang} practiceId={practice.id} t={p} isDoctor={role === "doctor"} today={today} />
        <div className="space-y-2 pt-2">
          <h3 className="text-sm font-semibold text-muted">{p.changes.upcoming}</h3>
          {exceptions.length === 0 ? (
            <p className="text-sm text-muted">{p.changes.none}</p>
          ) : (
            <ul className="space-y-2">
              {exceptions.map((e) => (
                <li key={e.id} className="flex flex-wrap items-center gap-2 rounded-control bg-canvas px-3 py-2 text-sm">
                  <Badge tone={e.kind === "extra_session" ? "ok" : e.kind === "time_change" ? "info" : "bad"}>
                    {(p.changes.kinds as Record<string, string>)[e.kind] ?? e.kind}
                  </Badge>
                  <span className="font-semibold">
                    {dateLabel(e.starts_on)}{e.ends_on !== e.starts_on && ` – ${dateLabel(e.ends_on)}`}
                  </span>
                  {e.new_start && <span className="text-muted">{e.new_start}–{e.new_end}</span>}
                  {e.reason_public && <span className="w-full text-muted">{e.reason_public}</span>}
                </li>
              ))}
            </ul>
          )}
        </div>
      </Card>

      {sittings.length > 0 && (
        <Card className="space-y-2">
          <h2 className="text-lg font-semibold">{p.next7}</h2>
          <ul className="space-y-2">{sittings.map((s) => <li key={s.id}><SittingRow s={s} lang={lang} t={t} /></li>)}</ul>
        </Card>
      )}
    </div>
  );
}

export default async function PracticePage({ params, searchParams }: P) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
      <Practice params={params} searchParams={searchParams} t={t} lang={lang} />
    </Suspense>
  );
}
