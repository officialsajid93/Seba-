import { getDictionary } from "@/i18n/dictionaries";
import { ListSkeleton } from "@/components/ui/states";
import { Skeleton } from "@/components/ui/primitives";

export default async function Loading() {
  const t = await getDictionary();
  return (
    <div className="space-y-4">
      <Skeleton className="h-8 w-40" />
      <ListSkeleton label={t.states.loading} />
    </div>
  );
}
