"use client";

import { useEffect } from "react";
import { useParams } from "next/navigation";
import { RefreshCw } from "lucide-react";
import bn from "@/i18n/dictionaries/bn.json";
import en from "@/i18n/dictionaries/en.json";
import { Button } from "@/components/ui/primitives";
import { ErrorMessage } from "@/components/ui/states";

const strings = { bn: bn.states, en: en.states };

export default function ErrorBoundary({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const params = useParams<{ lang: string }>();
  const t = params?.lang === "en" ? strings.en : strings.bn;
  useEffect(() => {
    // Only the digest is logged client-side; details stay in server logs.
    console.error("page error", error.digest ?? "");
  }, [error]);
  return (
    <ErrorMessage
      asPageTitle
      title={t.errorTitle}
      body={t.errorBody}
      action={
        <Button onClick={reset}>
          <RefreshCw className="size-5" aria-hidden />
          {t.retry}
        </Button>
      }
    />
  );
}
