import type { Metadata } from "next";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { Onboarding } from "@/components/home/Onboarding";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).onboarding.s1Title };
}

export default async function OnboardingPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  const o = t.onboarding;
  return (
    <Onboarding
      lang={lang}
      slides={[
        { title: o.s1Title, body: o.s1Body },
        { title: o.s2Title, body: o.s2Body },
        { title: o.s3Title, body: o.s3Body },
      ]}
      labels={{ skip: o.skip, next: o.next, start: o.start }}
    />
  );
}
