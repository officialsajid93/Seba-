import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { BadgeCheck, Info, MapPin, RefreshCw, Stethoscope, TriangleAlert } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { AvailabilityBadge, ConfirmedAgo } from "@/components/ui/availability";
import { Badge, Button, ButtonLink, Card, Field, Input } from "@/components/ui/primitives";
import { EmptyState, ErrorMessage, ListSkeleton, Notice, SuccessMessage } from "@/components/ui/states";

export const metadata: Metadata = { title: "Design system", robots: { index: false } };

// Living style guide: every shared component and state in both languages.
// Hidden in production unless SHOW_DESIGN_SYSTEM=true.
const FIXED_NOW = new Date("2026-10-21T12:00:00+05:30");
const daysAgo = (n: number) => new Date(FIXED_NOW.getTime() - n * 86_400_000);

function Swatch({ name, className }: { name: string; className: string }) {
  return (
    <div className="space-y-1 text-center">
      <div className={`h-12 rounded-xl ring-1 ring-line ${className}`} />
      <p className="text-xs text-muted">{name}</p>
    </div>
  );
}

export default async function DesignSystemPage() {
  if (process.env.NODE_ENV === "production" && process.env.SHOW_DESIGN_SYSTEM !== "true") notFound();
  const t = await getDictionary();
  const a = t.availability;
  return (
    <div className="space-y-8">
      <PageHeader title="Design system" subtitle="Shared components and states" />

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Colour</h2>
        <div className="grid grid-cols-4 gap-3">
          <Swatch name="brand-600" className="bg-brand-600" />
          <Swatch name="teal-600" className="bg-teal-600" />
          <Swatch name="ink" className="bg-ink" />
          <Swatch name="canvas" className="bg-canvas" />
          <Swatch name="ok-700" className="bg-ok-700" />
          <Swatch name="warn-700" className="bg-warn-700" />
          <Swatch name="bad-700" className="bg-bad-700" />
          <Swatch name="info-700" className="bg-info-700" />
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Buttons</h2>
        <div className="flex flex-wrap gap-3">
          <Button>Primary</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="ghost">Ghost</Button>
          <Button variant="danger">Danger</Button>
          <Button disabled>Disabled</Button>
          <Button size="sm">Small</Button>
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Availability (every state)</h2>
        <div className="flex flex-wrap gap-2">
          <AvailabilityBadge t={a} state={{ kind: "open", seatsLeft: 18, capacity: 30 }} />
          <AvailabilityBadge t={a} state={{ kind: "open", seatsLeft: 3, capacity: 30 }} />
          <AvailabilityBadge t={a} state={{ kind: "full" }} />
          <AvailabilityBadge t={a} state={{ kind: "running_late" }} />
          <AvailabilityBadge t={a} state={{ kind: "on_leave" }} />
          <AvailabilityBadge t={a} state={{ kind: "cancelled" }} />
          <AvailabilityBadge t={a} state={{ kind: "unverified" }} />
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Doctor card (example data — not a real doctor)</h2>
        <Card className="space-y-3">
          <div className="flex gap-3">
            <div className="grid size-14 shrink-0 place-items-center rounded-full bg-brand-50 text-brand-600" aria-hidden>
              <Stethoscope className="size-7" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-1.5 font-semibold">
                Dr. Example Name
                <BadgeCheck className="size-4 text-teal-700" aria-label="Verified" />
              </p>
              <p className="text-sm text-muted">MBBS, MD (Medicine) · General physician</p>
              <p className="mt-1 flex items-center gap-1 text-sm text-muted">
                <MapPin className="size-4" aria-hidden /> Example Chamber, Dhuliyan
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between gap-2 rounded-control bg-canvas px-3 py-2">
            <div>
              <p className="text-sm font-semibold">Thu · 5:00–8:00 pm</p>
              <p className="text-sm text-muted">Fee ₹300 · Serial booking</p>
            </div>
            <AvailabilityBadge t={a} state={{ kind: "open", seatsLeft: 4, capacity: 30 }} />
          </div>
          <ConfirmedAgo t={a} confirmedAt={daysAgo(2)} now={FIXED_NOW} />
          <ButtonLink href="#" full>
            Book serial
          </ButtonLink>
        </Card>
        <Card className="space-y-2">
          <p className="font-semibold">Unverified listing (cannot be booked)</p>
          <AvailabilityBadge t={a} state={{ kind: "unverified" }} />
          <ConfirmedAgo t={a} confirmedAt={null} now={FIXED_NOW} />
        </Card>
      </section>

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Form fields</h2>
        <Card className="space-y-4">
          <Field id="ds-name" label="Patient name" hint="As written on ID">
            <Input id="ds-name" placeholder="Full name" />
          </Field>
          <Field id="ds-phone" label="Mobile number" error="Enter a 10-digit mobile number">
            <Input id="ds-phone" invalid defaultValue="98123" aria-describedby="ds-phone-error" />
          </Field>
        </Card>
      </section>

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Notices</h2>
        <Notice tone="info" icon={<Info className="size-5" />}>Information notice</Notice>
        <Notice tone="warn" icon={<TriangleAlert className="size-5" />}>Doctor is running 45 minutes late</Notice>
        <Notice tone="bad" icon={<TriangleAlert className="size-5" />}>Sitting cancelled — you will get a full refund</Notice>
      </section>

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Loading · Empty · Error · Success</h2>
        <ListSkeleton rows={2} label={t.states.loading} />
        <Card className="p-0">
          <EmptyState title={t.screens.bookings.emptyTitle} body={t.screens.bookings.emptyBody} />
        </Card>
        <Card className="p-0">
          <ErrorMessage
            title={t.states.errorTitle}
            body={t.states.errorBody}
            action={
              <Button variant="secondary">
                <RefreshCw className="size-5" aria-hidden />
                {t.states.retry}
              </Button>
            }
          />
        </Card>
        <Card className="p-0">
          <SuccessMessage title={t.states.successTitle} body="Booking ID BK7Q2M9P · Serial 7" />
        </Card>
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Badges</h2>
        <div className="flex flex-wrap gap-2">
          <Badge>Neutral</Badge>
          <Badge tone="brand">Brand</Badge>
          <Badge tone="ok">OK</Badge>
          <Badge tone="warn">Warning</Badge>
          <Badge tone="bad">Problem</Badge>
          <Badge tone="info">Info</Badge>
          <Badge tone="brand">Sponsored</Badge>
        </div>
      </section>
    </div>
  );
}
