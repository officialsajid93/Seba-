import type { Metadata } from "next";
import Link from "next/link";
import { ChevronRight, FileText, Phone } from "lucide-react";
import { brand } from "@/config/brand";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { ButtonLink, Card } from "@/components/ui/primitives";
import { Notice } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.help.title };
}

export default async function HelpPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  const s = t.screens.help;
  const docs = [
    { slug: "cancellation", label: t.screens.legal.cancellation },
    { slug: "privacy", label: t.screens.legal.privacy },
    { slug: "terms", label: t.screens.legal.terms },
  ];
  return (
    <div className="space-y-4">
      <PageHeader title={s.title} />
      <Card className="space-y-4">
        <p>{s.body}</p>
        {brand.supportPhone ? (
          <ButtonLink href={`tel:${brand.supportPhone}`} full>
            <Phone className="size-5" aria-hidden />
            {s.callSupport}
          </ButtonLink>
        ) : (
          <Notice tone="info">{s.noPhone}</Notice>
        )}
      </Card>
      <Card className="p-0">
        <ul className="divide-y divide-line">
          {docs.map((d) => (
            <li key={d.slug}>
              <Link href={`/${lang}/legal/${d.slug}`} className="flex min-h-14 items-center gap-3 px-4 hover:bg-canvas">
                <FileText className="size-5 text-brand-600" aria-hidden />
                <span className="flex-1 font-medium">{d.label}</span>
                <ChevronRight className="size-5 text-subtle" aria-hidden />
              </Link>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
}
