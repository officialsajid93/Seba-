import { notFound } from "next/navigation";

// Any unknown path under /bn or /en shows the app's own 404 page, inside the
// layout (correct language, navigation, and lang attribute), not a bare default.
export default function CatchAll() {
  notFound();
}
