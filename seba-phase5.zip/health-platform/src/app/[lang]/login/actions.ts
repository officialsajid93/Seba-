"use server";

import { redirect } from "next/navigation";
import { isActiveLocale } from "@/i18n/config";
import { query } from "@/lib/db";
import { normalizeIndianMobile, displayMaskedPhone } from "@/server/auth/phone";
import { requestOtp, verifyOtp } from "@/server/auth/otp";
import { createSession, safeNext } from "@/server/auth/session";
import { clientMeta } from "@/server/request";

// Version of the privacy notice the user agrees to at login; bump when the notice changes.
const CONSENT_NOTICE_VERSION = "draft-2026-10";

export type LoginState =
  | { step: "phone"; error?: LoginError; retryAfterSec?: number; phoneInput?: string }
  | { step: "code"; phone: string; masked: string; resendAfterSec: number; sentAt: number; error?: LoginError; attemptsLeft?: number };

export type LoginError =
  | "invalidPhone" | "consentRequired" | "rateLimited" | "invalidCode" | "expired" | "tooMany" | "suspended" | "generic";

const langOf = (fd: FormData) => {
  const l = String(fd.get("lang") ?? "");
  return isActiveLocale(l) ? l : "bn";
};

export async function sendCodeAction(_prev: LoginState, fd: FormData): Promise<LoginState> {
  const lang = langOf(fd);
  const raw = String(fd.get("phone") ?? "").slice(0, 20);
  const phone = normalizeIndianMobile(raw);
  if (!phone) return { step: "phone", error: "invalidPhone", phoneInput: raw };
  if (fd.get("consent") !== "yes") return { step: "phone", error: "consentRequired", phoneInput: raw };
  try {
    const { ip } = await clientMeta();
    const res = await requestOtp(phone, ip, lang);
    if (!res.ok) {
      // A resend inside the cooldown keeps the user on the code step.
      if (fd.get("resend") === "1" && res.retryAfterSec < 3600) {
        return { step: "code", phone, masked: displayMaskedPhone(phone), resendAfterSec: res.retryAfterSec, sentAt: Date.now(), error: "rateLimited" };
      }
      return { step: "phone", error: "rateLimited", retryAfterSec: res.retryAfterSec, phoneInput: raw };
    }
    return { step: "code", phone, masked: displayMaskedPhone(phone), resendAfterSec: res.resendAfterSec, sentAt: Date.now() };
  } catch (err) {
    console.error("[login] send code failed:", err instanceof Error ? err.message : err);
    return { step: "phone", error: "generic", phoneInput: raw };
  }
}

export async function verifyCodeAction(prev: LoginState, fd: FormData): Promise<LoginState> {
  const lang = langOf(fd);
  if (prev.step !== "code") return { step: "phone" };
  // Action state round-trips through the browser, so treat the phone as untrusted:
  // re-normalise it, and the OTP check below binds the login to that exact number.
  const phone = normalizeIndianMobile(prev.phone);
  if (!phone) return { step: "phone", error: "invalidPhone" };
  const code = String(fd.get("code") ?? "").replace(/\D/g, "").slice(0, 6);
  let target: string;
  try {
    const res = await verifyOtp(phone, code);
    if (!res.ok) {
      const error: LoginError =
        res.error === "invalid_code" ? "invalidCode" : res.error === "too_many_attempts" ? "tooMany" : res.error;
      return { ...prev, error, attemptsLeft: res.error === "invalid_code" ? res.attemptsLeft : undefined };
    }
    const meta = await clientMeta();
    await createSession(res.userId, meta);
    // Consent ledger: record agreement to the current notice once.
    await query(
      `INSERT INTO consents (user_id, purpose, notice_version) VALUES ($1, 'core_service', $2)
       ON CONFLICT (user_id, purpose) WHERE withdrawn_at IS NULL DO NOTHING`,
      [res.userId, CONSENT_NOTICE_VERSION],
    );
    if (res.isNewUser) await query(`UPDATE users SET preferred_lang = $2 WHERE id = $1`, [res.userId, lang]);
    const next = safeNext(String(fd.get("next") ?? ""), lang);
    target = res.needsProfile ? `/${lang}/profile/details?next=${encodeURIComponent(next)}` : next;
  } catch (err) {
    console.error("[login] verify failed:", err instanceof Error ? err.message : err);
    return { ...prev, error: "generic" };
  }
  redirect(target);
}
