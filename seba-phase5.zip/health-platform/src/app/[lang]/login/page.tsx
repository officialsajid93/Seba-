import type { Metadata } from "next";
import { Suspense } from "react";
import { redirect } from "next/navigation";
import { getDictionary, getLocale } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { LoginForm } from "@/components/auth/LoginForm";
import { Card } from "@/components/ui/primitives";
import { ListSkeleton } from "@/components/ui/states";
import { getCurrentUser, safeNext } from "@/server/auth/session";
import { isDevMode } from "@/lib/dev-mode";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.login.title, robots: { index: false } };
}

async function LoginContent({ searchParams }: { searchParams: PageProps<"/[lang]/login">["searchParams"] }) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  const raw = (await searchParams).next;
  const next = safeNext(Array.isArray(raw) ? raw[0] : raw, lang);
  if (await getCurrentUser()) redirect(next);
  return <LoginForm lang={lang} next={next} t={t.screens.login} devMode={isDevMode()} />;
}

export default async function LoginPage({ searchParams }: PageProps<"/[lang]/login">) {
  const t = await getDictionary();
  return (
    <div className="space-y-4">
      <PageHeader title={t.screens.login.title} />
      <Card>
        <Suspense fallback={<ListSkeleton rows={1} label={t.states.loading} />}>
          <LoginContent searchParams={searchParams} />
        </Suspense>
      </Card>
    </div>
  );
}
