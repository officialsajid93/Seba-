import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import { CalendarClock, Info, MapPin, Navigation, Phone, Stethoscope, UserRound } from "lucide-react";
import { format } from "@/i18n/config";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { formatMoney, formatNumber, formatSitting } from "@/lib/format";
import { directionsUrl } from "@/lib/adapters/maps";
import { isDevMode } from "@/lib/dev-mode";
import { requireUser } from "@/server/auth/session";
import { getMyAppointment, rescheduleOptions } from "@/server/booking";
import { pick } from "@/server/directory";
import { StatusBadge, whenText } from "@/components/booking/parts";
import { CancelForm, RescheduleForm } from "@/components/booking/ActionForms";
import { buttonClass, Card } from "@/components/ui/primitives";
import { ListSkeleton, Notice, SuccessMessage } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).booking.details, robots: { index: false } };
}

type P = PageProps<"/[lang]/bookings/[id]">;

async function Detail({ params, searchParams, t, lang }: { params: P["params"]; searchParams: P["searchParams"]; t: Dictionary; lang: string }) {
  const { id } = await params;
  const sp = await searchParams;
  const user = await requireUser(lang, `/${lang}/bookings/${id}`);
  const a = await getMyAppointment(user.id, id);
  if (!a) notFound();
  const b = t.booking;
  const w = whenText(a, lang);
  const isNew = sp.new === "1" && a.status === "confirmed";
  const options = a.canChange ? await rescheduleOptions(user.id, a.id) : [];

  return (
    <div className="space-y-4">
      {isNew ? (
        <Card className="p-0">
          <SuccessMessage title={b.confirmedTitle} body={isDevMode() ? b.smsDev : b.smsSent} />
        </Card>
      ) : (
        <h1 className="text-2xl font-bold">{b.details}</h1>
      )}
      {sp.cancelled === "1" && <Notice tone="info">{b.cancelled}</Notice>}

      <Card className="space-y-4">
        <div className="grid grid-cols-2 gap-3 text-center">
          <div className="rounded-control bg-brand-50 p-3">
            <p className="text-sm text-brand-700">{a.slotStartsAt ? b.time : b.serialLabel}</p>
            <p className="text-3xl font-bold text-brand-700">{a.slotStartsAt ? w.time : formatNumber(a.serial, lang)}</p>
          </div>
          <div className="rounded-control bg-canvas p-3">
            <p className="text-sm text-muted">{b.bookingId}</p>
            <p className="font-mono text-xl font-bold tracking-wider" aria-label={a.code.split("").join(" ")}>{a.code}</p>
          </div>
        </div>
        <div className="flex justify-center"><StatusBadge status={a.status} t={b} /></div>
        {a.sessionStatus === "cancelled" && <Notice tone="bad">{b.sittingCancelled}{a.sessionNote ? `: ${a.sessionNote}` : ""}</Notice>}
        <dl className="space-y-2 text-sm">
          <div className="flex gap-2"><dt className="sr-only">{t.directory.doctorsTab}</dt><Stethoscope className="size-5 shrink-0 text-brand-600" aria-hidden />
            <dd><Link href={`/${lang}/doctors/${a.doctor.id}`} className="font-semibold text-brand-700 underline-offset-2 hover:underline">{pick(a.doctor.name, lang)}</Link></dd></div>
          <div className="flex gap-2"><dt className="sr-only">{b.time}</dt><CalendarClock className="size-5 shrink-0 text-brand-600" aria-hidden />
            <dd><span className="font-semibold">{w.day}</span> · {w.time}</dd></div>
          <div className="flex gap-2"><dt className="sr-only">{b.place}</dt><MapPin className="size-5 shrink-0 text-brand-600" aria-hidden />
            <dd>{pick(a.facility.name, lang)}, {a.facility.address}</dd></div>
          <div className="flex gap-2"><dt className="sr-only">{b.patient}</dt><UserRound className="size-5 shrink-0 text-brand-600" aria-hidden />
            <dd>{a.patientName}</dd></div>
        </dl>
        <p className="rounded-control bg-canvas px-3 py-2 text-sm">
          {b.fee}: <span className="font-semibold">{formatMoney(a.feePaise, lang)}</span> · {b.payAtClinic}
        </p>
        <div className="flex gap-2">
          {a.facility.phone && (
            <a href={`tel:${a.facility.phone}`} className={buttonClass("secondary", "sm", true)}>
              <Phone className="size-4" aria-hidden />{t.directory.call}
            </a>
          )}
          {a.facility.lat !== null && a.facility.lng !== null && (
            <a href={directionsUrl(a.facility.lat, a.facility.lng)} target="_blank" rel="noopener noreferrer" className={buttonClass("secondary", "sm", true)}>
              <Navigation className="size-4" aria-hidden />{t.directory.directions}
            </a>
          )}
        </div>
      </Card>

      {a.status === "confirmed" && (
        a.canChange ? (
          <Card className="space-y-4">
            <section className="space-y-2">
              <h2 className="font-semibold">{b.rescheduleTitle}</h2>
              {a.slotStartsAt ? (
                <p className="text-sm text-muted">{b.rescheduleSlotNote}</p>
              ) : options.length ? (
                <RescheduleForm
                  lang={lang}
                  appointmentId={a.id}
                  t={b}
                  options={options.map((o) => {
                    const s = formatSitting(o.starts_at, o.ends_at, lang);
                    return { id: o.id, label: `${s.day} · ${s.time}`, seats: format(b.seatsFree, { left: formatNumber(o.seats_left, lang) }) };
                  })}
                />
              ) : (
                <p className="text-sm text-muted">{b.rescheduleNone}</p>
              )}
            </section>
            <CancelForm lang={lang} appointmentId={a.id} t={b} />
          </Card>
        ) : (
          <Notice tone="info" icon={<Info className="size-5" />}>{b.cannotChange}</Notice>
        )
      )}

      <Card>
        <h2 className="mb-3 font-semibold">{b.history}</h2>
        <ol className="space-y-3 border-l-2 border-line pl-4">
          {a.events.map((e, i) => {
            const s = formatSitting(e.at, e.at, lang);
            return (
              <li key={i} className="relative">
                <span className="absolute -left-[1.4rem] top-1.5 size-3 rounded-full bg-brand-600" aria-hidden />
                <p className="text-sm font-semibold">{(b.statuses as Record<string, string>)[e.to_status] ?? e.to_status}</p>
                <p className="text-xs text-muted">{s.day} · {s.time.split(" – ")[0]}</p>
              </li>
            );
          })}
        </ol>
      </Card>
    </div>
  );
}

export default async function BookingPage({ params, searchParams }: P) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <Suspense fallback={<ListSkeleton rows={2} label={t.states.loading} />}>
      <Detail params={params} searchParams={searchParams} t={t} lang={lang} />
    </Suspense>
  );
}
