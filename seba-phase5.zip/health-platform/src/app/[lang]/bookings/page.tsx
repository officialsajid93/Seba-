import type { Metadata } from "next";
import { Suspense } from "react";
import { CalendarCheck, LogIn } from "lucide-react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { getCurrentUser } from "@/server/auth/session";
import { listMyAppointments } from "@/server/booking";
import { PageHeader } from "@/components/layout/PageHeader";
import { AppointmentCard } from "@/components/booking/parts";
import { ButtonLink, Card } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.bookings.title, robots: { index: false } };
}

async function Bookings({ t, lang }: { t: Dictionary; lang: string }) {
  const user = await getCurrentUser();
  const s = t.screens.bookings;
  if (!user) {
    return (
      <Card className="p-0">
        <EmptyState
          icon={<LogIn className="size-7" />}
          title={t.screens.profile.signedOutTitle}
          body={s.emptyBody}
          action={<ButtonLink href={`/${lang}/login?next=${encodeURIComponent(`/${lang}/bookings`)}`}>{t.screens.login.title}</ButtonLink>}
        />
      </Card>
    );
  }
  const { upcoming, past } = await listMyAppointments(user.id);
  if (!upcoming.length && !past.length) {
    return (
      <Card className="p-0">
        <EmptyState
          icon={<CalendarCheck className="size-7" />}
          title={s.emptyTitle}
          body={s.emptyBody}
          action={<ButtonLink href={`/${lang}/doctors`}>{s.findDoctor}</ButtonLink>}
        />
      </Card>
    );
  }
  return (
    <div className="space-y-6">
      <section className="space-y-3">
        <h2 className="text-lg font-semibold">{t.booking.upcoming}</h2>
        {upcoming.length ? (
          <ul className="space-y-3">{upcoming.map((a) => <li key={a.id}><AppointmentCard a={a} lang={lang} t={t} /></li>)}</ul>
        ) : (
          <p className="text-muted">{t.booking.noUpcoming}</p>
        )}
      </section>
      {past.length > 0 && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold">{t.booking.past}</h2>
          <ul className="space-y-3">{past.map((a) => <li key={a.id}><AppointmentCard a={a} lang={lang} t={t} /></li>)}</ul>
        </section>
      )}
    </div>
  );
}

export default async function BookingsPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.screens.bookings.title} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <Bookings t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
