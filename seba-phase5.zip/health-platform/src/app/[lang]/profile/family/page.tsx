import type { Metadata } from "next";
import { Suspense } from "react";
import { UserRound } from "lucide-react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { PersonForm } from "@/components/account/PersonForm";
import { Button, Card } from "@/components/ui/primitives";
import { ListSkeleton } from "@/components/ui/states";
import { requireUser } from "@/server/auth/session";
import { listPatients, MAX_FAMILY } from "@/server/patients";
import { addFamilyAction, removeFamilyAction } from "../actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).account.family.title, robots: { index: false } };
}

function age(dob: string | null): number | null {
  if (!dob) return null;
  const d = new Date(dob);
  const now = new Date();
  let a = now.getFullYear() - d.getFullYear();
  if (now < new Date(now.getFullYear(), d.getMonth(), d.getDate())) a--;
  return a;
}

async function Family({ t, lang }: { t: Dictionary; lang: string }) {
  const user = await requireUser(lang, `/${lang}/profile/family`);
  const people = await listPatients(user.id);
  const f = t.account.family;
  const members = people.filter((p) => p.relation !== "self");
  return (
    <div className="space-y-4">
      <Card className="p-0">
        <ul className="divide-y divide-line">
          {people.map((p) => {
            const years = age(p.dateOfBirth);
            return (
              <li key={p.id} className="flex min-h-16 items-center gap-3 px-4 py-2">
                <UserRound className="size-5 shrink-0 text-brand-600" aria-hidden />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{p.fullName}</p>
                  <p className="text-sm text-muted">
                    {p.relation === "self" ? f.you : f.relations[p.relation]}
                    {years !== null && ` · ${years}`}
                  </p>
                </div>
                {p.relation !== "self" && (
                  <form action={removeFamilyAction}>
                    <input type="hidden" name="lang" value={lang} />
                    <input type="hidden" name="patientId" value={p.id} />
                    <Button type="submit" variant="ghost" size="sm" aria-label={`${f.remove}: ${p.fullName}`}>
                      {f.remove}
                    </Button>
                  </form>
                )}
              </li>
            );
          })}
          {members.length === 0 && <li className="px-4 py-4 text-muted">{f.empty}</li>}
        </ul>
      </Card>
      <Card>
        <h2 className="mb-3 text-lg font-semibold">{f.add}</h2>
        {members.length >= MAX_FAMILY ? (
          <p className="text-muted">{f.maxReached}</p>
        ) : (
          <PersonForm action={addFamilyAction} t={t.account} lang={lang} mode="family" submitLabel={f.add} />
        )}
      </Card>
    </div>
  );
}

export default async function FamilyPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.account.family.title} subtitle={t.account.family.body} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <Family t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
