import type { Metadata } from "next";
import { Suspense } from "react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { PersonForm } from "@/components/account/PersonForm";
import { Card } from "@/components/ui/primitives";
import { ListSkeleton } from "@/components/ui/states";
import { requireUser, safeNext } from "@/server/auth/session";
import { listPatients } from "@/server/patients";
import { saveDetailsAction } from "../actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).account.detailsTitle, robots: { index: false } };
}

async function Details({ t, lang, searchParams }: { t: Dictionary; lang: string; searchParams: PageProps<"/[lang]/profile/details">["searchParams"] }) {
  const user = await requireUser(lang, `/${lang}/profile/details`);
  const raw = (await searchParams).next;
  const next = safeNext(Array.isArray(raw) ? raw[0] : raw, lang);
  const self = (await listPatients(user.id)).find((p) => p.relation === "self");
  return (
    <PersonForm
      action={saveDetailsAction}
      t={t.account}
      lang={lang}
      mode="self"
      next={next}
      initial={self ?? { fullName: user.displayName ?? "" }}
      submitLabel={t.account.save}
    />
  );
}

export default async function DetailsPage({ searchParams }: PageProps<"/[lang]/profile/details">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.account.detailsTitle} subtitle={t.account.detailsBody} />
      <Card>
        <Suspense fallback={<ListSkeleton rows={1} label={t.states.loading} />}>
          <Details t={t} lang={lang} searchParams={searchParams} />
        </Suspense>
      </Card>
    </div>
  );
}
