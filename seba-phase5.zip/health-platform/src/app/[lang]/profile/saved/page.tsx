import type { Metadata } from "next";
import { Suspense } from "react";
import { Heart } from "lucide-react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { doctorCardsByIds, savedDoctorIds } from "@/server/directory";
import { requireUser } from "@/server/auth/session";
import { PageHeader } from "@/components/layout/PageHeader";
import { DoctorCard } from "@/components/directory/cards";
import { ButtonLink, Card } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).account.savedDoctors.title, robots: { index: false } };
}

async function Saved({ t, lang }: { t: Dictionary; lang: string }) {
  const user = await requireUser(lang, `/${lang}/profile/saved`);
  const doctors = await doctorCardsByIds(await savedDoctorIds(user.id));
  const now = new Date();
  if (!doctors.length) {
    return (
      <Card className="p-0">
        <EmptyState
          icon={<Heart className="size-7" />}
          title={t.account.savedDoctors.title}
          body={t.account.savedDoctors.empty}
          action={<ButtonLink href={`/${lang}/doctors`}>{t.screens.bookings.findDoctor}</ButtonLink>}
        />
      </Card>
    );
  }
  return (
    <ul className="space-y-3">
      {doctors.map((d) => <li key={d.id}><DoctorCard d={d} lang={lang} t={t} now={now} /></li>)}
    </ul>
  );
}

export default async function SavedPage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.account.savedDoctors.title} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <Saved t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
