"use server";

import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { refresh } from "next/cache";
import { z } from "zod";
import { isActiveLocale, LOCALE_COOKIE } from "@/i18n/config";
import { query } from "@/lib/db";
import { addFamilyMember, parsePerson, removeFamilyMember, RELATIONS, saveSelf } from "@/server/patients";
import { destroySession, getCurrentUser, safeNext } from "@/server/auth/session";

// Every action re-checks the session itself: server actions are reachable by
// direct POST, not only through the UI.

export type FormState = { ok?: boolean; error?: "name" | "dob" | "limit" | "generic" };

const localeOr = (value: unknown) => {
  const l = String(value ?? "");
  return isActiveLocale(l) ? l : "bn";
};
const langOf = (fd: FormData) => localeOr(fd.get("lang"));

async function userOrLogin(lang: string, next: string) {
  const user = await getCurrentUser();
  if (!user) redirect(`/${lang}/login?next=${encodeURIComponent(next)}`);
  return user;
}

export async function saveDetailsAction(_prev: FormState, fd: FormData): Promise<FormState> {
  const lang = langOf(fd);
  const user = await userOrLogin(lang, `/${lang}/profile/details`);
  const parsed = parsePerson(fd);
  if (!parsed.success) {
    const field = parsed.error.issues[0]?.path[0];
    return { error: field === "dateOfBirth" ? "dob" : "name" };
  }
  const appLang = localeOr(fd.get("appLang") ?? lang);
  await saveSelf(user.id, parsed.data, appLang);
  (await cookies()).set(LOCALE_COOKIE, appLang, { path: "/", maxAge: 31_536_000, sameSite: "lax" });
  const next = safeNext(String(fd.get("next") ?? ""), appLang);
  // The language choice may change the URL prefix.
  redirect(next.replace(/^\/(bn|en)/, `/${appLang}`));
}

export async function addFamilyAction(_prev: FormState, fd: FormData): Promise<FormState> {
  const lang = langOf(fd);
  const user = await userOrLogin(lang, `/${lang}/profile/family`);
  const parsed = parsePerson(fd);
  if (!parsed.success) {
    const field = parsed.error.issues[0]?.path[0];
    return { error: field === "dateOfBirth" ? "dob" : "name" };
  }
  const relation = z.enum(RELATIONS).safeParse(fd.get("relation"));
  if (!relation.success) return { error: "generic" };
  const res = await addFamilyMember(user.id, parsed.data, relation.data);
  if (res === "limit") return { error: "limit" };
  refresh();
  return { ok: true };
}

export async function removeFamilyAction(fd: FormData): Promise<void> {
  const lang = langOf(fd);
  const user = await userOrLogin(lang, `/${lang}/profile/family`);
  await removeFamilyMember(user.id, String(fd.get("patientId") ?? ""));
  refresh();
}

export async function toggleSavedDoctorAction(fd: FormData): Promise<void> {
  const lang = langOf(fd);
  const doctorId = String(fd.get("doctorId") ?? "");
  if (!z.uuid().safeParse(doctorId).success) return;
  const user = await userOrLogin(lang, `/${lang}/doctors/${doctorId}`);
  const removed = await query(`DELETE FROM saved_doctors WHERE user_id = $1 AND doctor_id = $2 RETURNING doctor_id`, [user.id, doctorId]);
  if (removed.length === 0) {
    await query(
      `INSERT INTO saved_doctors (user_id, doctor_id)
       SELECT $1, id FROM doctors WHERE id = $2 AND verification_status = 'verified'
       ON CONFLICT DO NOTHING`,
      [user.id, doctorId],
    );
  }
  refresh();
}

export async function logoutAction(fd: FormData): Promise<void> {
  const lang = langOf(fd);
  await destroySession();
  redirect(`/${lang}`);
}
