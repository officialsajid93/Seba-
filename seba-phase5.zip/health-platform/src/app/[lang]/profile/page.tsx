import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { Bell, Building2, CalendarCheck, ChevronRight, CircleHelp, FileText, Heart, Languages, LogIn, LogOut, Pill, UserPen, Users } from "lucide-react";
import { format } from "@/i18n/config";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { Button, ButtonLink, Card } from "@/components/ui/primitives";
import { ListSkeleton } from "@/components/ui/states";
import { getCurrentUser } from "@/server/auth/session";
import { displayMaskedPhone } from "@/server/auth/phone";
import { logoutAction } from "./actions";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.profile.title };
}

type Row = { href: string; Icon: typeof Users; label: string };

function Menu({ rows }: { rows: Row[] }) {
  return (
    <Card className="p-0">
      <ul className="divide-y divide-line">
        {rows.map(({ href, Icon, label }) => (
          <li key={label}>
            <Link href={href} className="flex min-h-14 items-center gap-3 px-4 hover:bg-canvas">
              <Icon className="size-5 text-brand-600" aria-hidden />
              <span className="flex-1 font-medium">{label}</span>
              <ChevronRight className="size-5 text-subtle" aria-hidden />
            </Link>
          </li>
        ))}
      </ul>
    </Card>
  );
}

async function ProfileContent({ t, lang }: { t: Dictionary; lang: string }) {
  const user = await getCurrentUser();
  const s = t.screens.profile;
  const common: Row[] = [
    { href: `/${lang === "bn" ? "en" : "bn"}/profile`, Icon: Languages, label: `${s.language}: ${t.lang.name}` },
    { href: `/${lang}/help`, Icon: CircleHelp, label: s.help },
    { href: `/${lang}/legal/privacy`, Icon: FileText, label: s.policies },
  ];

  if (!user) {
    return (
      <div className="space-y-4">
        <Card className="space-y-3 text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-full bg-brand-50 text-brand-600" aria-hidden>
            <LogIn className="size-7" />
          </div>
          <h2 className="text-lg font-semibold">{s.signedOutTitle}</h2>
          <p className="text-muted">{s.signedOutBody}</p>
          <ButtonLink href={`/${lang}/login?next=${encodeURIComponent(`/${lang}/profile`)}`} full>
            {t.screens.login.title}
          </ButtonLink>
        </Card>
        <Menu rows={common} />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="flex items-center gap-3">
        <div className="grid size-14 shrink-0 place-items-center rounded-full bg-brand-600 text-xl font-bold text-white" aria-hidden>
          {(user.displayName ?? "?").trim().charAt(0).toUpperCase()}
        </div>
        <div className="min-w-0">
          <h2 className="truncate text-lg font-semibold">
            {user.displayName ? format(t.account.hello, { name: user.displayName }) : t.account.detailsTitle}
          </h2>
          <p className="text-sm text-muted">
            {t.account.loggedInAs} {displayMaskedPhone(user.phone)}
          </p>
        </div>
      </Card>
      <Menu
        rows={[
          { href: `/${lang}/bookings`, Icon: CalendarCheck, label: t.booking.viewBookings },
          { href: `/${lang}/notifications`, Icon: Bell, label: s.notifications },
          { href: `/${lang}/profile/details`, Icon: UserPen, label: t.account.detailsTitle },
          { href: `/${lang}/profile/family`, Icon: Users, label: s.family },
          { href: `/${lang}/profile/saved`, Icon: Heart, label: s.saved },
          { href: `/${lang}/medicines`, Icon: Pill, label: s.orders },
          { href: `/${lang}/provider`, Icon: Building2, label: s.forProviders },
        ]}
      />
      <Menu rows={common} />
      <form action={logoutAction}>
        <input type="hidden" name="lang" value={lang} />
        <Button type="submit" variant="secondary" full>
          <LogOut className="size-5" aria-hidden />
          {t.account.logout}
        </Button>
      </form>
    </div>
  );
}

export default async function ProfilePage() {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.screens.profile.title} />
      <Suspense fallback={<ListSkeleton rows={2} label={t.states.loading} />}>
        <ProfileContent t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
