import type { Metadata } from "next";
import { Pill } from "lucide-react";
import { getDictionary } from "@/i18n/dictionaries";
import { PageHeader } from "@/components/layout/PageHeader";
import { Card } from "@/components/ui/primitives";
import { EmptyState } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).screens.medicines.title };
}

// The pharmacy module stays switched off until legal review and the first
// licensed partner agreement (see the Phase 1 plan).
export default async function MedicinesPage() {
  const t = await getDictionary();
  return (
    <div className="space-y-4">
      <PageHeader title={t.screens.medicines.title} />
      <Card className="p-0">
        <EmptyState
          icon={<Pill className="size-7" />}
          title={t.screens.medicines.comingTitle}
          body={t.screens.medicines.comingBody}
        />
      </Card>
    </div>
  );
}
