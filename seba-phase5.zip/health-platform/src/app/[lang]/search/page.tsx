import type { Metadata } from "next";
import Link from "next/link";
import { Suspense } from "react";
import { Search } from "lucide-react";
import { format } from "@/i18n/config";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { listFacilities, listSpecialities, pick, searchDoctors } from "@/server/directory";
import { SearchBar } from "@/components/home/SearchBar";
import { PageHeader } from "@/components/layout/PageHeader";
import { DoctorCard, FacilityCard } from "@/components/directory/cards";
import { Card } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton } from "@/components/ui/states";

export async function generateMetadata(): Promise<Metadata> {
  return { title: (await getDictionary()).search.label, robots: { index: false } };
}

async function Results({ searchParams, t, lang }: { searchParams: PageProps<"/[lang]/search">["searchParams"]; t: Dictionary; lang: string }) {
  const raw = (await searchParams).q;
  const q = (Array.isArray(raw) ? raw[0] : raw)?.trim().slice(0, 80) ?? "";
  const bar = (
    <SearchBar lang={lang} defaultValue={q} placeholder={t.search.placeholder} label={t.search.label} buttonLabel={t.search.button} />
  );
  if (!q) {
    const specialities = await listSpecialities();
    return (
      <div className="space-y-4">
        {bar}
        <p className="text-muted">{t.search.noQuery}</p>
        <ul className="flex flex-wrap gap-2" aria-label={t.directory.speciality}>
          {specialities.map((s) => (
            <li key={s.slug}>
              <Link
                href={`/${lang}/doctors?speciality=${s.slug}`}
                className="inline-flex min-h-10 items-center rounded-full bg-white px-4 text-sm font-medium ring-1 ring-inset ring-line hover:ring-brand-200"
              >
                {pick(s.name, lang)}
              </Link>
            </li>
          ))}
        </ul>
      </div>
    );
  }
  const [doctors, places] = await Promise.all([searchDoctors({ q, available: false }, 20), listFacilities({ q, limit: 10 })]);
  const now = new Date();
  return (
    <div className="space-y-5">
      {bar}
      <h2 className="font-semibold text-muted" role="status">{format(t.search.resultsFor, { query: q })}</h2>
      {doctors.length === 0 && places.length === 0 ? (
        <Card className="p-0">
          <EmptyState icon={<Search className="size-7" />} title={t.directory.noResults} />
        </Card>
      ) : (
        <>
          {doctors.length > 0 && (
            <section className="space-y-3">
              <h3 className="text-lg font-semibold">{t.directory.doctorsTab}</h3>
              <ul className="space-y-3">
                {doctors.map((d) => <li key={d.id}><DoctorCard d={d} lang={lang} t={t} now={now} /></li>)}
              </ul>
            </section>
          )}
          {places.length > 0 && (
            <section className="space-y-3">
              <h3 className="text-lg font-semibold">{t.directory.placesTab}</h3>
              <ul className="space-y-3">
                {places.map((f) => <li key={f.id}><FacilityCard f={f} lang={lang} t={t} /></li>)}
              </ul>
            </section>
          )}
        </>
      )}
    </div>
  );
}

export default async function SearchPage({ searchParams }: PageProps<"/[lang]/search">) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.search.label} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <Results searchParams={searchParams} t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
