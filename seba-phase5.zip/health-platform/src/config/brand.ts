// Working brand. Change it here (or via env) — every screen, the PWA manifest
// and SMS templates read from this one place.
export const brand = {
  name: process.env.NEXT_PUBLIC_BRAND_NAME ?? "Seba",
  nameBn: process.env.NEXT_PUBLIC_BRAND_NAME_BN ?? "সেবা",
  supportPhone: process.env.NEXT_PUBLIC_SUPPORT_PHONE ?? "",
  themeColor: "#0B5CAD",
} as const;

// Towns the platform launches in. Shown in the location picker; more are added
// as providers are verified there.
export const launchTowns = [
  { slug: "dhuliyan", en: "Dhuliyan", bn: "ধুলিয়ান", district: "Murshidabad" },
  { slug: "farakka", en: "Farakka", bn: "ফারাক্কা", district: "Murshidabad" },
  { slug: "jangipur", en: "Jangipur", bn: "জঙ্গিপুর", district: "Murshidabad" },
  { slug: "malda", en: "Malda", bn: "মালদা", district: "Malda" },
] as const;

export type TownSlug = (typeof launchTowns)[number]["slug"];
