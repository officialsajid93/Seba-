import { lang } from "next/root-params";
import { notFound } from "next/navigation";
import en from "./dictionaries/en.json";
import { isActiveLocale, type ActiveLocale } from "./config";

export type Dictionary = typeof en;

const loaders: Record<ActiveLocale, () => Promise<Dictionary>> = {
  en: async () => en,
  bn: () => import("./dictionaries/bn.json").then((m) => m.default),
};

// Current request's locale, read from the root [lang] segment.
export async function getLocale(): Promise<ActiveLocale> {
  const value = await lang();
  if (!isActiveLocale(value)) notFound();
  return value;
}

export async function getDictionary(): Promise<Dictionary> {
  return loaders[await getLocale()]();
}
