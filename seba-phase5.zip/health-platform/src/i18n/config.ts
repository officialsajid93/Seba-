// Client-safe locale config. Hindi is wired in but not yet switched on:
// add "hi" to `activeLocales` once hi.json is fully translated.
export const allLocales = ["bn", "en", "hi"] as const;
export const activeLocales = ["bn", "en"] as const;
export const defaultLocale = "bn" satisfies ActiveLocale;

export type Locale = (typeof allLocales)[number];
export type ActiveLocale = (typeof activeLocales)[number];

export const isActiveLocale = (value: string | undefined | null): value is ActiveLocale =>
  !!value && (activeLocales as readonly string[]).includes(value);

export const LOCALE_COOKIE = "NEXT_LOCALE";

// Pick the best active locale from an Accept-Language header.
// Bengali is the default because most launch users read it first.
export function negotiateLocale(acceptLanguage: string | null | undefined): ActiveLocale {
  if (!acceptLanguage) return defaultLocale;
  const ranked = acceptLanguage
    .split(",")
    .map((part) => {
      const [tag, ...params] = part.trim().split(";");
      const q = params.find((p) => p.trim().startsWith("q="));
      return { base: tag.toLowerCase().split("-")[0], q: q ? Number(q.trim().slice(2)) || 0 : 1 };
    })
    .filter((x) => x.base)
    .sort((a, b) => b.q - a.q);
  for (const { base } of ranked) if (isActiveLocale(base)) return base;
  return defaultLocale;
}

// Replace or add the locale prefix of a path: ("/en/doctors", "bn") -> "/bn/doctors".
export function switchLocalePath(pathname: string, target: ActiveLocale): string {
  const parts = pathname.split("/");
  if (isActiveLocale(parts[1]) || (allLocales as readonly string[]).includes(parts[1])) {
    parts[1] = target;
    return parts.join("/") || `/${target}`;
  }
  return `/${target}${pathname === "/" ? "" : pathname}`;
}

// Fill "{name}" placeholders.
export function format(template: string, values: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (m, key: string) => (key in values ? String(values[key]) : m));
}
