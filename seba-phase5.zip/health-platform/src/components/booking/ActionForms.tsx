"use client";

import { useActionState } from "react";
import type { Dictionary } from "@/i18n/dictionaries";
import { cancelAction, rescheduleAction, type BookState } from "@/app/[lang]/book/actions";
import { Button } from "@/components/ui/primitives";

type T = Dictionary["booking"];
const err = (t: T, s: BookState) => (s.error ? (t.errors as Record<string, string>)[s.error] ?? t.errors.generic : undefined);

// Two-step cancel: the first tap opens a confirmation, so a stray tap never cancels.
export function CancelForm({ lang, appointmentId, t }: { lang: string; appointmentId: string; t: T }) {
  const [state, action, pending] = useActionState<BookState, FormData>(cancelAction, {});
  const e = err(t, state);
  return (
    <details className="group">
      <summary className="list-none [&::-webkit-details-marker]:hidden">
        <span className="inline-flex min-h-12 w-full cursor-pointer items-center justify-center rounded-control px-5 font-semibold text-bad-700 ring-1 ring-inset ring-bad-700/30 hover:bg-bad-50 group-open:hidden">
          {t.cancel}
        </span>
      </summary>
      <form action={action} className="space-y-3 rounded-control bg-bad-50 p-4">
        <input type="hidden" name="lang" value={lang} />
        <input type="hidden" name="appointmentId" value={appointmentId} />
        <p className="text-sm text-bad-700">{t.cancelAsk}</p>
        {e && <p role="alert" className="text-sm font-semibold text-bad-700">{e}</p>}
        <div className="flex gap-2">
          <Button type="submit" variant="danger" full disabled={pending}>{t.cancelConfirm}</Button>
        </div>
      </form>
    </details>
  );
}

export function RescheduleForm({
  lang,
  appointmentId,
  options,
  t,
}: {
  lang: string;
  appointmentId: string;
  options: { id: string; label: string; seats: string }[];
  t: T;
}) {
  const [state, action, pending] = useActionState<BookState, FormData>(rescheduleAction, {});
  const e = err(t, state);
  return (
    <div className="space-y-2">
      {e && <p role="alert" className="rounded-control bg-bad-50 px-4 py-3 text-sm text-bad-700">{e}</p>}
      <ul className="space-y-2">
        {options.map((o) => (
          <li key={o.id}>
            <form action={action} className="flex items-center justify-between gap-2 rounded-control bg-canvas px-3 py-2">
              <input type="hidden" name="lang" value={lang} />
              <input type="hidden" name="appointmentId" value={appointmentId} />
              <input type="hidden" name="sessionId" value={o.id} />
              <div className="min-w-0">
                <p className="text-sm font-semibold">{o.label}</p>
                <p className="text-xs text-muted">{o.seats}</p>
              </div>
              <Button type="submit" size="sm" variant="secondary" disabled={pending}>{t.move}</Button>
            </form>
          </li>
        ))}
      </ul>
    </div>
  );
}
