"use client";

import Link from "next/link";
import { useActionState } from "react";
import { UserPlus } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries";
import { bookAction, type BookState } from "@/app/[lang]/book/actions";
import { Button, cn } from "@/components/ui/primitives";

type T = Dictionary["booking"];
type Patient = { id: string; name: string; relationLabel: string; alreadyBooked: boolean };
type Slot = { value: string; label: string };

const choice =
  "flex min-h-12 cursor-pointer items-center gap-3 rounded-control bg-white px-4 ring-1 ring-inset ring-line " +
  "has-checked:bg-brand-50 has-checked:ring-2 has-checked:ring-brand-500 has-disabled:cursor-not-allowed has-disabled:opacity-60";

export function BookForm({
  lang,
  sessionId,
  t,
  patients,
  slots,
  summary,
}: {
  lang: string;
  sessionId: string;
  t: T;
  patients: Patient[];
  slots: Slot[] | null;
  summary: { fee: string; note: string };
}) {
  const [state, action, pending] = useActionState<BookState, FormData>(bookAction, {});
  const firstFree = patients.find((p) => !p.alreadyBooked)?.id;
  const error = state.error ? (t.errors as Record<string, string>)[state.error] ?? t.errors.generic : undefined;

  return (
    <form action={action} className="space-y-5">
      <input type="hidden" name="lang" value={lang} />
      <input type="hidden" name="sessionId" value={sessionId} />

      <fieldset className="space-y-2">
        <legend className="mb-2 text-lg font-semibold">{t.whoFor}</legend>
        {patients.map((p) => (
          <label key={p.id} className={choice}>
            <input
              type="radio"
              name="patientId"
              value={p.id}
              defaultChecked={p.id === firstFree}
              disabled={p.alreadyBooked}
              required
              className="size-5 accent-brand-600"
            />
            <span className="flex-1">
              <span className="block font-semibold">{p.name}</span>
              <span className="block text-sm text-muted">{p.alreadyBooked ? t.alreadyBooked : p.relationLabel}</span>
            </span>
          </label>
        ))}
        <Link href={`/${lang}/profile/family`} className="inline-flex min-h-11 items-center gap-2 text-sm font-semibold text-brand-700">
          <UserPlus className="size-4" aria-hidden />
          {t.addFamily}
        </Link>
      </fieldset>

      {slots && (
        <fieldset>
          <legend className="mb-2 text-lg font-semibold">{t.chooseTime}</legend>
          {slots.length === 0 ? (
            <p className="text-muted">{t.noSlots}</p>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              {slots.map((s, i) => (
                <label key={s.value} className={cn(choice, "justify-center whitespace-nowrap px-1! text-sm font-semibold")}>
                  <input type="radio" name="slot" value={s.value} defaultChecked={i === 0} required className="sr-only" />
                  {s.label}
                </label>
              ))}
            </div>
          )}
        </fieldset>
      )}

      <div className="space-y-1 rounded-control bg-canvas p-4 text-sm">
        <div className="flex justify-between"><span>{t.fee}</span><span className="font-semibold">{summary.fee}</span></div>
        <div className="flex justify-between"><span>{t.bookingFee}</span><span className="font-semibold text-ok-700">{t.free}</span></div>
        <p className="pt-1 text-muted">{t.payAtClinic}. {summary.note}</p>
      </div>

      {error && <p role="alert" className="rounded-control bg-bad-50 px-4 py-3 text-sm text-bad-700">{error}</p>}

      <Button type="submit" full disabled={pending || !firstFree || (slots !== null && slots.length === 0)}>
        {t.confirm}
      </Button>
    </form>
  );
}
