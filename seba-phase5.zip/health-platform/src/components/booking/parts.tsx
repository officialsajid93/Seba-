import Link from "next/link";
import { ChevronRight } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries";
import { formatNumber, formatSitting, formatTime } from "@/lib/format";
import type { MyAppointment } from "@/server/booking";
import { pick } from "@/server/directory";
import { Badge, Card, type Tone } from "@/components/ui/primitives";

const statusTone: Record<string, Tone> = {
  confirmed: "ok", checked_in: "info", completed: "neutral", pending_payment: "warn",
  cancelled_by_patient: "neutral", cancelled_by_provider: "bad", no_show: "bad", rescheduled: "neutral", expired: "neutral",
};

export function StatusBadge({ status, t }: { status: string; t: Dictionary["booking"] }) {
  return <Badge tone={statusTone[status] ?? "neutral"}>{(t.statuses as Record<string, string>)[status] ?? status}</Badge>;
}

export function whenText(a: Pick<MyAppointment, "slotStartsAt" | "startsAt" | "endsAt">, lang: string) {
  const s = formatSitting(a.startsAt, a.endsAt, lang);
  return { day: s.day, time: a.slotStartsAt ? formatTime(a.slotStartsAt, lang) : s.time };
}

export function AppointmentCard({ a, lang, t }: { a: MyAppointment; lang: string; t: Dictionary }) {
  const w = whenText(a, lang);
  return (
    <Card className="p-0">
      <Link href={`/${lang}/bookings/${a.id}`} className="flex items-center gap-3 p-4 hover:bg-canvas/60">
        <div className="grid w-16 shrink-0 place-items-center rounded-xl bg-brand-50 py-2 text-center text-brand-700" aria-hidden>
          <span className="text-xs font-semibold">{t.booking.serialShort}</span>
          <span className="text-2xl font-bold leading-none">{a.slotStartsAt ? "–" : formatNumber(a.serial, lang)}</span>
        </div>
        <div className="min-w-0 flex-1 space-y-0.5">
          <p className="truncate font-semibold">{pick(a.doctor.name, lang)}</p>
          <p className="text-sm">{w.day} · {w.time}</p>
          <p className="truncate text-sm text-muted">{pick(a.facility.name, lang)} · {a.patientName}</p>
          <StatusBadge status={a.status} t={t.booking} />
        </div>
        <ChevronRight className="size-5 shrink-0 text-subtle" aria-hidden />
      </Link>
    </Card>
  );
}
