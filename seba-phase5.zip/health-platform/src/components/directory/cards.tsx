import Link from "next/link";
import { BadgeCheck, BedDouble, ChevronRight, FlaskConical, Hospital, MapPin, Siren, Stethoscope, Store } from "lucide-react";
import { format } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";
import { formatMoney, formatNumber, formatSitting } from "@/lib/format";
import { pick, type DoctorCard as DoctorCardData, type FacilityCard as FacilityCardData, type FacilityType } from "@/server/directory";
import { AvailabilityBadge, ConfirmedAgo } from "@/components/ui/availability";
import { Badge, Card } from "@/components/ui/primitives";

export function DemoBadge({ label }: { label: string }) {
  return (
    <Badge tone="warn" className="text-xs">
      {label}
    </Badge>
  );
}

export const facilityIcon: Record<FacilityType, typeof Hospital> = {
  hospital: Hospital,
  nursing_home: BedDouble,
  clinic: Stethoscope,
  diagnostic_centre: FlaskConical,
  chamber: Store,
};

export function DoctorCard({ d, lang, t, now }: { d: DoctorCardData; lang: string; t: Dictionary; now: Date }) {
  const dir = t.directory;
  const sitting = d.next ? formatSitting(d.next.startsAt, d.next.endsAt, lang) : null;
  return (
    <Card className="p-0">
      <Link href={`/${lang}/doctors/${d.id}`} className="block space-y-3 p-4 hover:bg-canvas/60">
        <div className="flex gap-3">
          <div className="grid size-14 shrink-0 place-items-center rounded-full bg-brand-50 text-brand-600" aria-hidden>
            <Stethoscope className="size-7" />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="flex items-start gap-1.5 font-semibold leading-snug">
              <span>{pick(d.name, lang)}</span>
              <BadgeCheck className="mt-0.5 size-4 shrink-0 text-teal-700" aria-label={dir.verifiedDoctor} />
            </h3>
            <p className="text-sm text-muted">{d.specialities.map((s) => pick(s, lang)).join(", ")}</p>
            <p className="text-sm text-muted">
              {d.yearsExperience !== null && `${format(dir.years, { count: formatNumber(d.yearsExperience, lang) })} · `}
              {format(dir.fee, { amount: formatMoney(d.feeFromPaise, lang) })}
            </p>
            <p className="mt-0.5 flex items-center gap-1 text-sm text-muted">
              <MapPin className="size-4 shrink-0" aria-hidden />
              {d.towns.map((x) => pick(x, lang)).join(", ")}
            </p>
            {d.isDemo && <div className="mt-1.5"><DemoBadge label={dir.demo} /></div>}
          </div>
          <ChevronRight className="size-5 shrink-0 self-center text-subtle" aria-hidden />
        </div>
        {d.next && sitting ? (
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-control bg-canvas px-3 py-2">
            <div className="min-w-0">
              <p className="text-xs text-muted">{dir.nextSitting} · {pick(d.next.facility, lang)}</p>
              <p className="text-sm font-semibold">{sitting.day} · {sitting.time}</p>
            </div>
            <AvailabilityBadge
              t={t.availability}
              state={d.next.status === "running_late" ? { kind: "running_late" } : { kind: "open", seatsLeft: d.next.seatsLeft, capacity: d.next.capacity }}
            />
          </div>
        ) : (
          <p className="rounded-control bg-canvas px-3 py-2 text-sm text-muted">{dir.noUpcoming}</p>
        )}
        <ConfirmedAgo t={t.availability} confirmedAt={d.scheduleConfirmedAt} now={now} />
      </Link>
    </Card>
  );
}

export function FacilityCard({ f, lang, t }: { f: FacilityCardData; lang: string; t: Dictionary }) {
  const dir = t.directory;
  const Icon = facilityIcon[f.type];
  return (
    <Card className="p-0">
      <Link href={`/${lang}/facilities/${f.id}`} className="flex gap-3 p-4 hover:bg-canvas/60">
        <div className="grid size-14 shrink-0 place-items-center rounded-2xl bg-teal-50 text-teal-700" aria-hidden>
          <Icon className="size-7" />
        </div>
        <div className="min-w-0 flex-1 space-y-1">
          <h3 className="font-semibold leading-snug">{pick(f.name, lang)}</h3>
          <p className="text-sm text-muted">{dir.facilityTypes[f.type]} · {pick(f.town, lang)}</p>
          <p className="text-sm text-muted">{f.address}</p>
          <div className="flex flex-wrap gap-1.5 pt-0.5">
            {f.emergency && <Badge tone="bad" icon={<Siren className="size-3.5" aria-hidden />}>{dir.emergency}</Badge>}
            {f.open247 && <Badge tone="info">{dir.open247}</Badge>}
            {f.doctorCount > 0 && <Badge tone="brand">{`${formatNumber(f.doctorCount, lang)} ${dir.doctorsTab}`}</Badge>}
            {f.isDemo && <DemoBadge label={dir.demoFacility} />}
          </div>
        </div>
        <ChevronRight className="size-5 shrink-0 self-center text-subtle" aria-hidden />
      </Link>
    </Card>
  );
}
