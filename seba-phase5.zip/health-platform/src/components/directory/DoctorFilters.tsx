import Link from "next/link";
import { SlidersHorizontal } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries";
import { formatMoney } from "@/lib/format";
import { pick, type Named, type SearchInput } from "@/server/directory";
import { buttonClass } from "@/components/ui/primitives";

const selectClass =
  "block min-h-12 w-full rounded-control bg-white px-3 text-base text-ink ring-1 ring-inset ring-line focus:outline-none focus:ring-2 focus:ring-brand-500";
const FEES = [200, 300, 500, 1000];

// Plain GET form inside <details>: works without JavaScript and keeps the URL
// shareable ("send this search to my brother").
export function DoctorFilters({
  lang,
  t,
  input,
  specialities,
  towns,
  action,
}: {
  lang: string;
  t: Dictionary;
  input: SearchInput;
  specialities: { slug: string; name: Named }[];
  towns: { slug: string; name: Named }[];
  action: string;
}) {
  const d = t.directory;
  const active = [input.speciality, input.town, input.maxFee, input.available || undefined].filter(Boolean).length;
  return (
    <details className="group rounded-card bg-white shadow-card ring-1 ring-line" open={active > 0}>
      <summary className="flex min-h-12 cursor-pointer list-none items-center gap-2 px-4 font-semibold text-brand-700 [&::-webkit-details-marker]:hidden">
        <SlidersHorizontal className="size-5" aria-hidden />
        {d.filters}
        {active > 0 && <span className="rounded-full bg-brand-600 px-2 text-xs text-white">{active}</span>}
      </summary>
      <form action={action} method="get" className="space-y-3 border-t border-line p-4">
        {input.q && <input type="hidden" name="q" value={input.q} />}
        <label className="block space-y-1">
          <span className="text-sm font-semibold">{d.speciality}</span>
          <select name="speciality" defaultValue={input.speciality ?? ""} className={selectClass}>
            <option value="">{d.anySpeciality}</option>
            {specialities.map((s) => (
              <option key={s.slug} value={s.slug}>{pick(s.name, lang)}</option>
            ))}
          </select>
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="block space-y-1">
            <span className="text-sm font-semibold">{d.town}</span>
            <select name="town" defaultValue={input.town ?? ""} className={selectClass}>
              <option value="">{d.anyTown}</option>
              {towns.map((x) => (
                <option key={x.slug} value={x.slug}>{pick(x.name, lang)}</option>
              ))}
            </select>
          </label>
          <label className="block space-y-1">
            <span className="text-sm font-semibold">{d.maxFee}</span>
            <select name="maxFee" defaultValue={input.maxFee ? String(input.maxFee) : ""} className={selectClass}>
              <option value="">{d.anyFee}</option>
              {FEES.map((f) => (
                <option key={f} value={f}>{formatMoney(f * 100, lang)}</option>
              ))}
            </select>
          </label>
        </div>
        <label className="flex min-h-11 items-center gap-3 text-sm">
          <input type="checkbox" name="available" value="1" defaultChecked={input.available} className="size-5 accent-brand-600" />
          {d.availableOnly}
        </label>
        <div className="flex gap-2">
          <button type="submit" className={buttonClass("primary", "md", true)}>{d.apply}</button>
          <Link href={action} className={buttonClass("secondary", "md")}>{d.clear}</Link>
        </div>
      </form>
    </details>
  );
}
