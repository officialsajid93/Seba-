import Link from "next/link";
import { Heart } from "lucide-react";
import { query } from "@/lib/db";
import { getCurrentUser } from "@/server/auth/session";
import { toggleSavedDoctorAction } from "@/app/[lang]/profile/actions";
import { buttonClass, cn } from "@/components/ui/primitives";

// Reads the session, so it renders inside a <Suspense> boundary.
export async function SaveDoctorButton({ doctorId, lang, saveLabel, unsaveLabel }: { doctorId: string; lang: string; saveLabel: string; unsaveLabel: string }) {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <Link
        href={`/${lang}/login?next=${encodeURIComponent(`/${lang}/doctors/${doctorId}`)}`}
        className={buttonClass("secondary", "sm")}
        aria-label={saveLabel}
      >
        <Heart className="size-5" aria-hidden />
      </Link>
    );
  }
  const saved =
    (await query(`SELECT 1 FROM saved_doctors WHERE user_id = $1 AND doctor_id = $2`, [user.id, doctorId])).length > 0;
  return <SaveForm doctorId={doctorId} lang={lang} saved={saved} label={saved ? unsaveLabel : saveLabel} />;
}

export function SaveForm({ doctorId, lang, saved, label }: { doctorId: string; lang: string; saved: boolean; label: string }) {
  return (
    <form action={toggleSavedDoctorAction}>
      <input type="hidden" name="lang" value={lang} />
      <input type="hidden" name="doctorId" value={doctorId} />
      <button type="submit" className={buttonClass("secondary", "sm")} aria-label={label} aria-pressed={saved}>
        <Heart className={cn("size-5", saved && "fill-bad-700 text-bad-700")} aria-hidden />
      </button>
    </form>
  );
}
