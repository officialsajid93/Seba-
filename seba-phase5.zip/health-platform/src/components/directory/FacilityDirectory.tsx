import Link from "next/link";
import { Suspense, type ReactNode } from "react";
import { getDictionary, getLocale, type Dictionary } from "@/i18n/dictionaries";
import { listFacilities, listTowns, pick, type FacilityType } from "@/server/directory";
import { SearchBar } from "@/components/home/SearchBar";
import { PageHeader } from "@/components/layout/PageHeader";
import { FacilityCard } from "@/components/directory/cards";
import { Card, cn } from "@/components/ui/primitives";
import { EmptyState, ListSkeleton } from "@/components/ui/states";

type Section = "hospitals" | "nursingHomes" | "diagnostics";

type SP = Promise<Record<string, string | string[] | undefined>>;

async function List({ section, types, path, icon, t, lang, searchParams }: {
  section: Section; types: FacilityType[]; path: string; icon: ReactNode; t: Dictionary; lang: string; searchParams: SP;
}) {
  const sp = await searchParams;
  const one = (k: string) => (Array.isArray(sp[k]) ? sp[k]![0] : (sp[k] as string | undefined)) ?? "";
  const q = one("q").slice(0, 80);
  const townParam = one("town");
  const towns = await listTowns();
  const town = towns.some((x) => x.slug === townParam) ? townParam : undefined;
  const items = await listFacilities({ types, town, q });
  const s = t.screens[section];
  const href = (slug?: string) => `${path}${slug || q ? "?" : ""}${new URLSearchParams({ ...(q ? { q } : {}), ...(slug ? { town: slug } : {}) })}`;
  return (
    <div className="space-y-4">
      <SearchBar lang={lang} action={path} defaultValue={q} placeholder={t.search.placeholder} label={t.search.label} buttonLabel={t.search.button} />
      <nav aria-label={t.directory.town} className="-mx-4 overflow-x-auto px-4">
        <ul className="flex gap-2 pb-1">
          {[{ slug: undefined, label: t.directory.anyTown }, ...towns.map((x) => ({ slug: x.slug, label: pick(x.name, lang) }))].map((x) => {
            const current = x.slug === town;
            return (
              <li key={x.slug ?? "all"}>
                <Link
                  href={href(x.slug)}
                  aria-current={current ? "page" : undefined}
                  className={cn(
                    "inline-flex min-h-10 items-center whitespace-nowrap rounded-full px-4 text-sm font-semibold ring-1 ring-inset",
                    current ? "bg-brand-600 text-white ring-brand-600" : "bg-white text-ink ring-line hover:ring-brand-200",
                  )}
                >
                  {x.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      {items.length ? (
        <ul className="space-y-3">
          {items.map((f) => (
            <li key={f.id}><FacilityCard f={f} lang={lang} t={t} /></li>
          ))}
        </ul>
      ) : (
        <Card className="p-0">
          <EmptyState icon={icon} title={q || town ? t.directory.noResults : s.emptyTitle} body={q || town ? undefined : s.emptyBody} />
        </Card>
      )}
    </div>
  );
}

export async function FacilityDirectory(props: { section: Section; types: FacilityType[]; slug: string; icon: ReactNode; searchParams: SP }) {
  const [t, lang] = await Promise.all([getDictionary(), getLocale()]);
  return (
    <div>
      <PageHeader title={t.screens[props.section].title} />
      <Suspense fallback={<ListSkeleton label={t.states.loading} />}>
        <List {...props} path={`/${lang}/${props.slug}`} t={t} lang={lang} />
      </Suspense>
    </div>
  );
}
