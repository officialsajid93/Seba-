"use client";

import Link from "next/link";
import { useActionState, useEffect, useState } from "react";
import { Info } from "lucide-react";
import { format } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";
import { sendCodeAction, verifyCodeAction, type LoginState } from "@/app/[lang]/login/actions";
import { Button, Field, Input } from "@/components/ui/primitives";
import { Notice } from "@/components/ui/states";

type T = Dictionary["screens"]["login"];

function errorText(t: T, state: LoginState): string | undefined {
  if (!state.error) return undefined;
  const e = t.errors;
  switch (state.error) {
    case "rateLimited": {
      const sec = state.step === "phone" ? state.retryAfterSec ?? 60 : state.resendAfterSec;
      return format(e.rateLimited, { minutes: Math.max(1, Math.ceil(sec / 60)) });
    }
    case "invalidCode":
      return format(e.invalidCode, { left: state.step === "code" ? state.attemptsLeft ?? 0 : 0 });
    default:
      return e[state.error];
  }
}

function useCountdown(sentAt: number | undefined, seconds: number | undefined) {
  const [left, setLeft] = useState(seconds ?? 0);
  useEffect(() => {
    if (!sentAt || !seconds) return;
    const tick = () => setLeft(Math.max(0, Math.ceil(seconds - (Date.now() - sentAt) / 1000)));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [sentAt, seconds]);
  return left;
}

export function LoginForm({ lang, next, t, devMode }: { lang: string; next: string; t: T; devMode: boolean }) {
  const [sendState, sendAction, sending] = useActionState<LoginState, FormData>(sendCodeAction, { step: "phone" });
  // The verify step starts from whatever the send step produced.
  const [verifyState, verifyAction, verifying] = useActionState<LoginState, FormData>(
    (prev, fd) => verifyCodeAction(sendState.step === "code" && prev.step !== "code" ? sendState : prev, fd),
    { step: "phone" },
  );
  const [editingPhone, setEditingPhone] = useState(false);

  const codeState =
    sendState.step === "code" && !editingPhone
      ? verifyState.step === "code" && verifyState.phone === sendState.phone && verifyState.sentAt >= sendState.sentAt
        ? verifyState
        : sendState
      : null;
  const left = useCountdown(codeState?.sentAt, codeState?.resendAfterSec);

  if (!codeState) {
    const err = sendState.step === "phone" ? errorText(t, sendState) : undefined;
    return (
      <form action={(fd) => { setEditingPhone(false); return sendAction(fd); }} className="space-y-4" noValidate>
        <input type="hidden" name="lang" value={lang} />
        <Field id="phone" label={t.phoneLabel} hint={t.phoneHint} error={sendState.error === "invalidPhone" ? err : undefined}>
          <div className="flex gap-2">
            <span className="grid min-h-12 place-items-center rounded-control bg-canvas px-3 font-semibold text-muted ring-1 ring-inset ring-line" aria-hidden>
              +91
            </span>
            <Input
              id="phone"
              name="phone"
              type="tel"
              inputMode="numeric"
              autoComplete="tel-national"
              maxLength={14}
              placeholder="98XXXXXXXX"
              defaultValue={sendState.step === "phone" ? sendState.phoneInput : undefined}
              invalid={sendState.error === "invalidPhone"}
              aria-describedby={sendState.error === "invalidPhone" ? "phone-error" : "phone-hint"}
              required
            />
          </div>
        </Field>
        <label className="flex min-h-11 items-start gap-3 text-sm">
          <input type="checkbox" name="consent" value="yes" className="mt-1 size-5 shrink-0 accent-brand-600" required />
          <span>
            {t.consent}{" "}
            <Link href={`/${lang}/legal/terms`} className="font-semibold text-brand-700 underline underline-offset-2">
              ({t.readPolicies})
            </Link>
          </span>
        </label>
        {err && sendState.error !== "invalidPhone" && (
          <p role="alert" className="text-sm text-bad-700">{err}</p>
        )}
        <Button type="submit" full disabled={sending}>
          {t.sendCode}
        </Button>
        {devMode && (
          <Notice tone="warn" icon={<Info className="size-5" />}>{t.devHint}</Notice>
        )}
      </form>
    );
  }

  const err = errorText(t, codeState);
  return (
    <div className="space-y-4">
      <form action={verifyAction} className="space-y-4">
        <input type="hidden" name="lang" value={lang} />
        <input type="hidden" name="next" value={next} />
        <p className="text-muted">{format(t.codeSentTo, { phone: codeState.masked })}</p>
        <Field id="code" label={t.codeLabel} error={err}>
          <Input
            id="code"
            name="code"
            inputMode="numeric"
            autoComplete="one-time-code"
            pattern="\d{6}"
            maxLength={6}
            placeholder="••••••"
            className="text-center text-2xl tracking-[0.5em]"
            invalid={!!err}
            aria-describedby={err ? "code-error" : undefined}
            autoFocus
            required
          />
        </Field>
        <Button type="submit" full disabled={verifying}>
          {t.verify}
        </Button>
      </form>
      <div className="flex items-center justify-between gap-2">
        <Button variant="ghost" size="sm" type="button" onClick={() => setEditingPhone(true)}>
          {t.changeNumber}
        </Button>
        <form action={sendAction}>
          <input type="hidden" name="lang" value={lang} />
          <input type="hidden" name="phone" value={codeState.phone} />
          <input type="hidden" name="consent" value="yes" />
          <input type="hidden" name="resend" value="1" />
          <Button variant="ghost" size="sm" type="submit" disabled={left > 0 || sending}>
            {left > 0 ? format(t.resendIn, { seconds: new Intl.NumberFormat(lang === "bn" ? "bn-IN" : "en-IN").format(left) }) : t.resend}
          </Button>
        </form>
      </div>
      {devMode && <Notice tone="warn" icon={<Info className="size-5" />}>{t.devHint}</Notice>}
    </div>
  );
}
