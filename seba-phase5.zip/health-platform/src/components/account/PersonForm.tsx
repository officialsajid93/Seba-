"use client";

import { useActionState, useRef, useEffect } from "react";
import type { Dictionary } from "@/i18n/dictionaries";
import type { FormState } from "@/app/[lang]/profile/actions";
import { Button, Field, Input } from "@/components/ui/primitives";

type T = Dictionary["account"];
type Person = { fullName?: string; sex?: string | null; dateOfBirth?: string | null };

const selectClass =
  "block min-h-12 w-full rounded-control bg-white px-4 text-base text-ink ring-1 ring-inset ring-line focus:outline-none focus:ring-2 focus:ring-brand-500";

// One form for "your details" and "add a family member".
export function PersonForm({
  action,
  t,
  lang,
  mode,
  initial,
  next,
  submitLabel,
}: {
  action: (prev: FormState, fd: FormData) => Promise<FormState>;
  t: T;
  lang: string;
  mode: "self" | "family";
  initial?: Person;
  next?: string;
  submitLabel: string;
}) {
  const [state, formAction, pending] = useActionState<FormState, FormData>(action, {});
  const formRef = useRef<HTMLFormElement>(null);
  useEffect(() => {
    if (state.ok && mode === "family") formRef.current?.reset();
  }, [state, mode]);
  const id = (s: string) => `${mode}-${s}`;
  const maxDob = new Date().toISOString().slice(0, 10);

  return (
    <form ref={formRef} action={formAction} className="space-y-4" noValidate>
      <input type="hidden" name="lang" value={lang} />
      {next && <input type="hidden" name="next" value={next} />}

      <Field id={id("name")} label={mode === "self" ? t.nameLabel : t.family.nameLabel} error={state.error === "name" ? t.nameRequired : undefined}>
        <Input
          id={id("name")}
          name="fullName"
          autoComplete={mode === "self" ? "name" : "off"}
          defaultValue={initial?.fullName}
          maxLength={80}
          invalid={state.error === "name"}
          aria-describedby={state.error === "name" ? `${id("name")}-error` : undefined}
          required
        />
      </Field>

      {mode === "family" && (
        <Field id={id("relation")} label={t.family.relation}>
          <select id={id("relation")} name="relation" className={selectClass} defaultValue="child">
            {(["spouse", "child", "parent", "sibling", "other"] as const).map((r) => (
              <option key={r} value={r}>{t.family.relations[r]}</option>
            ))}
          </select>
        </Field>
      )}

      <fieldset className="space-y-1.5">
        <legend className="text-sm font-semibold">
          {t.sexLabel} <span className="font-normal text-muted">({t.optional})</span>
        </legend>
        <div className="grid grid-cols-3 gap-2">
          {(["female", "male", "other"] as const).map((s) => (
            <label key={s} className="flex min-h-12 cursor-pointer items-center justify-center gap-2 rounded-control bg-white px-2 text-sm font-medium ring-1 ring-inset ring-line has-checked:bg-brand-50 has-checked:ring-2 has-checked:ring-brand-500">
              <input type="radio" name="sex" value={s} defaultChecked={initial?.sex === s} className="accent-brand-600" />
              {s === "female" ? t.sexFemale : s === "male" ? t.sexMale : t.sexOther}
            </label>
          ))}
        </div>
      </fieldset>

      <Field id={id("dob")} label={`${t.dobLabel} (${t.optional})`} error={state.error === "dob" ? t.dobInvalid : undefined}>
        <Input
          id={id("dob")}
          name="dateOfBirth"
          type="date"
          min="1900-01-01"
          max={maxDob}
          defaultValue={initial?.dateOfBirth ?? undefined}
          invalid={state.error === "dob"}
        />
      </Field>

      {mode === "self" && (
        <Field id={id("lang")} label={t.langLabel}>
          <select id={id("lang")} name="appLang" className={selectClass} defaultValue={lang}>
            <option value="bn">বাংলা</option>
            <option value="en">English</option>
          </select>
        </Field>
      )}

      {state.error === "limit" && <p role="alert" className="text-sm text-bad-700">{t.family.maxReached}</p>}
      {state.ok && <p role="status" className="text-sm text-ok-700">{t.saved}</p>}

      <Button type="submit" full disabled={pending}>{submitLabel}</Button>
    </form>
  );
}
