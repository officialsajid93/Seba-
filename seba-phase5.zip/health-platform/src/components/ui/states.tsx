import type { ReactNode } from "react";
import { CircleCheck, Inbox, TriangleAlert } from "lucide-react";
import { Card, Skeleton, cn } from "./primitives";

// Shared loading / empty / error / success states. Every important screen uses
// these so the four states look and read the same everywhere.

export function EmptyState({
  title,
  body,
  icon,
  action,
}: {
  title: string;
  body?: string;
  icon?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center px-6 py-10 text-center">
      <div className="mb-4 grid size-14 place-items-center rounded-full bg-brand-50 text-brand-600" aria-hidden>
        {icon ?? <Inbox className="size-7" />}
      </div>
      <h2 className="text-lg font-semibold text-ink">{title}</h2>
      {body && <p className="mt-1.5 max-w-sm text-muted">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ErrorMessage({
  title,
  body,
  action,
  asPageTitle,
}: {
  title: string;
  body?: string;
  action?: ReactNode;
  /** Render the title as the page's <h1> (full-page error and 404 screens). */
  asPageTitle?: boolean;
}) {
  const Heading = asPageTitle ? "h1" : "h2";
  return (
    <div role="alert" className="flex flex-col items-center px-6 py-10 text-center">
      <div className="mb-4 grid size-14 place-items-center rounded-full bg-bad-50 text-bad-700" aria-hidden>
        <TriangleAlert className="size-7" />
      </div>
      <Heading className="text-lg font-semibold text-ink">{title}</Heading>
      {body && <p className="mt-1.5 max-w-sm text-muted">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function SuccessMessage({ title, body, action }: { title: string; body?: string; action?: ReactNode }) {
  return (
    <div role="status" className="flex flex-col items-center px-6 py-10 text-center">
      <div className="mb-4 grid size-14 place-items-center rounded-full bg-ok-50 text-ok-700" aria-hidden>
        <CircleCheck className="size-7" />
      </div>
      <h2 className="text-lg font-semibold text-ink">{title}</h2>
      {body && <p className="mt-1.5 max-w-sm text-muted">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function ListSkeleton({ rows = 3, label }: { rows?: number; label: string }) {
  return (
    <div role="status" aria-live="polite" className="space-y-3">
      <span className="sr-only">{label}</span>
      {Array.from({ length: rows }, (_, i) => (
        <Card key={i} className="flex gap-3">
          <Skeleton className="size-14 shrink-0 rounded-full" />
          <div className="flex-1 space-y-2 py-1">
            <Skeleton className="h-4 w-2/3" />
            <Skeleton className="h-3.5 w-1/2" />
            <Skeleton className="h-6 w-28 rounded-full" />
          </div>
        </Card>
      ))}
    </div>
  );
}

export function Notice({
  tone = "info",
  icon,
  children,
  className,
}: {
  tone?: "info" | "warn" | "bad" | "ok";
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  const styles = {
    info: "bg-info-50 text-info-700",
    warn: "bg-warn-50 text-warn-700",
    bad: "bg-bad-50 text-bad-700",
    ok: "bg-ok-50 text-ok-700",
  }[tone];
  return (
    <div className={cn("flex items-start gap-3 rounded-control px-4 py-3 text-sm", styles, className)}>
      {icon && <span className="mt-0.5 shrink-0" aria-hidden>{icon}</span>}
      <div className="min-w-0">{children}</div>
    </div>
  );
}
