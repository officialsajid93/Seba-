import Link from "next/link";
import clsx from "clsx";
import type { ComponentProps, ReactNode } from "react";

export const cn = clsx;

/* ---------------------------------------------------------------- Button */
type ButtonVariant = "primary" | "secondary" | "ghost" | "danger";
type ButtonSize = "md" | "sm";

const buttonBase =
  "inline-flex items-center justify-center gap-2 rounded-control font-semibold transition-colors " +
  "disabled:cursor-not-allowed disabled:opacity-50 select-none";
const buttonVariants: Record<ButtonVariant, string> = {
  primary: "bg-brand-600 text-white hover:bg-brand-700 active:bg-brand-800",
  secondary: "bg-white text-brand-700 ring-1 ring-inset ring-brand-200 hover:bg-brand-50",
  ghost: "text-brand-700 hover:bg-brand-50",
  danger: "bg-bad-700 text-white hover:brightness-95",
};
// 48px and 40px tall: both above the 44px/40px minimum tap targets for touch.
const buttonSizes: Record<ButtonSize, string> = {
  md: "min-h-12 px-5 text-base",
  sm: "min-h-10 px-4 text-sm",
};

export function buttonClass(variant: ButtonVariant = "primary", size: ButtonSize = "md", full = false) {
  return cn(buttonBase, buttonVariants[variant], buttonSizes[size], full && "w-full");
}

export function Button({
  variant = "primary",
  size = "md",
  full,
  className,
  ...props
}: ComponentProps<"button"> & { variant?: ButtonVariant; size?: ButtonSize; full?: boolean }) {
  return <button className={cn(buttonClass(variant, size, full), className)} {...props} />;
}

export function ButtonLink({
  variant = "primary",
  size = "md",
  full,
  className,
  ...props
}: ComponentProps<typeof Link> & { variant?: ButtonVariant; size?: ButtonSize; full?: boolean }) {
  return <Link className={cn(buttonClass(variant, size, full), className)} {...props} />;
}

/* ------------------------------------------------------------------ Card */
export function Card({ className, ...props }: ComponentProps<"div">) {
  return (
    <div
      className={cn("rounded-card bg-surface p-4 shadow-card ring-1 ring-line", className)}
      {...props}
    />
  );
}

/* ----------------------------------------------------------------- Badge */
export type Tone = "neutral" | "brand" | "ok" | "warn" | "bad" | "info";
const tones: Record<Tone, string> = {
  neutral: "bg-canvas text-muted ring-line",
  brand: "bg-brand-50 text-brand-700 ring-brand-100",
  ok: "bg-ok-50 text-ok-700 ring-ok-700/20",
  warn: "bg-warn-50 text-warn-700 ring-warn-700/20",
  bad: "bg-bad-50 text-bad-700 ring-bad-700/20",
  info: "bg-info-50 text-info-700 ring-info-700/20",
};

export function Badge({
  tone = "neutral",
  dashed,
  icon,
  children,
  className,
}: {
  tone?: Tone;
  dashed?: boolean;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full px-2.5 py-1 text-sm font-medium ring-1 ring-inset",
        tones[tone],
        dashed && "ring-0 outline-1 outline-dashed outline-subtle -outline-offset-1",
        className,
      )}
    >
      {icon}
      {children}
    </span>
  );
}

/* ----------------------------------------------------------------- Input */
export function Field({
  id,
  label,
  hint,
  error,
  children,
}: {
  id: string;
  label: string;
  hint?: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <div className="space-y-1.5">
      <label htmlFor={id} className="block text-sm font-semibold text-ink">
        {label}
      </label>
      {children}
      {error ? (
        <p id={`${id}-error`} role="alert" className="text-sm text-bad-700">
          {error}
        </p>
      ) : hint ? (
        <p id={`${id}-hint`} className="text-sm text-muted">
          {hint}
        </p>
      ) : null}
    </div>
  );
}

export function Input({ className, invalid, ...props }: ComponentProps<"input"> & { invalid?: boolean }) {
  return (
    <input
      aria-invalid={invalid || undefined}
      className={cn(
        "block min-h-12 w-full rounded-control bg-white px-4 text-base text-ink ring-1 ring-inset placeholder:text-subtle",
        invalid ? "ring-bad-700" : "ring-line focus:ring-brand-500",
        "focus:outline-none focus:ring-2",
        className,
      )}
      {...props}
    />
  );
}

/* ------------------------------------------------------------- Skeleton */
export function Skeleton({ className }: { className?: string }) {
  return <div aria-hidden className={cn("animate-pulse rounded-lg bg-line/70", className)} />;
}

/* ------------------------------------------------------- Visually hidden */
export function VisuallyHidden({ children }: { children: ReactNode }) {
  return <span className="sr-only">{children}</span>;
}
