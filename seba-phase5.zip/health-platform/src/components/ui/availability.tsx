import { CalendarX, CircleCheck, CircleSlash, Clock, ShieldCheck, ShieldQuestion, Users } from "lucide-react";
import { format } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";
import { Badge, type Tone } from "./primitives";

// One place decides how a sitting's availability is shown. The rule from the
// brief: never show "available" unless an authorised person confirmed the schedule.

export type SittingState =
  | { kind: "open"; seatsLeft: number; capacity: number }
  | { kind: "full" }
  | { kind: "on_leave" }
  | { kind: "cancelled" }
  | { kind: "running_late" }
  | { kind: "unverified" };

const FEW_SEATS = 5;

export function AvailabilityBadge({ state, t }: { state: SittingState; t: Dictionary["availability"] }) {
  const icon = "size-4";
  let tone: Tone;
  let label: string;
  let glyph;
  let dashed = false;
  switch (state.kind) {
    case "open":
      if (state.seatsLeft <= 0) {
        tone = "neutral";
        label = t.full;
        glyph = <CircleSlash className={icon} aria-hidden />;
      } else if (state.seatsLeft <= FEW_SEATS) {
        tone = "warn";
        label = format(t.fewLeft, { count: state.seatsLeft });
        glyph = <Users className={icon} aria-hidden />;
      } else {
        tone = "ok";
        label = t.available;
        glyph = <CircleCheck className={icon} aria-hidden />;
      }
      break;
    case "full":
      tone = "neutral";
      label = t.full;
      glyph = <CircleSlash className={icon} aria-hidden />;
      break;
    case "on_leave":
      tone = "bad";
      label = t.onLeave;
      glyph = <CalendarX className={icon} aria-hidden />;
      break;
    case "cancelled":
      tone = "bad";
      label = t.cancelled;
      glyph = <CalendarX className={icon} aria-hidden />;
      break;
    case "running_late":
      tone = "warn";
      label = t.runningLate;
      glyph = <Clock className={icon} aria-hidden />;
      break;
    case "unverified":
      tone = "neutral";
      label = t.unverified;
      glyph = <ShieldQuestion className={icon} aria-hidden />;
      dashed = true;
      break;
  }
  return (
    <Badge tone={tone} icon={glyph} dashed={dashed}>
      {label}
    </Badge>
  );
}

// "Schedule confirmed 2 days ago" — shown on every listing with a schedule.
export function ConfirmedAgo({
  confirmedAt,
  now,
  t,
}: {
  confirmedAt: Date | null;
  now: Date;
  t: Dictionary["availability"];
}) {
  if (!confirmedAt) {
    return (
      <p className="flex items-center gap-1.5 text-sm text-subtle">
        <ShieldQuestion className="size-4" aria-hidden />
        {t.unverified}
      </p>
    );
  }
  const days = Math.floor((startOfDay(now).getTime() - startOfDay(confirmedAt).getTime()) / 86_400_000);
  const when = days <= 0 ? t.today : days === 1 ? t.yesterday : format(t.daysAgo, { count: days });
  return (
    <p className="flex items-center gap-1.5 text-sm text-teal-700">
      <ShieldCheck className="size-4" aria-hidden />
      {format(t.confirmedAgo, { when })}
    </p>
  );
}

function startOfDay(d: Date) {
  // Calendar days in India time, regardless of the server's zone.
  const ist = new Date(d.getTime() + 330 * 60_000);
  return new Date(Date.UTC(ist.getUTCFullYear(), ist.getUTCMonth(), ist.getUTCDate()));
}
