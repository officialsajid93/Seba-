"use client";

import { useActionState, useState } from "react";
import { CalendarPlus, Check, Plus, Trash2 } from "lucide-react";
import { format } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";
import {
  addDoctorAction,
  addExceptionAction,
  cancelSittingAction,
  confirmScheduleAction,
  registerFacilityAction,
  runningLateAction,
  saveScheduleAction,
  staffBookAction,
  type ActionState,
} from "@/app/[lang]/provider/actions";
import { Button, Field, Input, cn } from "@/components/ui/primitives";

type P = Dictionary["provider"];

const selectClass =
  "block min-h-12 w-full rounded-control bg-white px-3 text-base text-ink ring-1 ring-inset ring-line focus:outline-none focus:ring-2 focus:ring-brand-500";

function Msg({ state, ok, errors }: { state: ActionState; ok?: string; errors: Record<string, string> }) {
  if (state.error) {
    const text = (errors[state.error] ?? errors.INVALID ?? state.error).replace("{field}", state.field ?? "");
    return <p role="alert" className="rounded-control bg-bad-50 px-4 py-3 text-sm text-bad-700">{text}</p>;
  }
  if (state.ok && ok) return <p role="status" className="rounded-control bg-ok-50 px-4 py-3 text-sm text-ok-700">{ok}</p>;
  return null;
}

const Hidden = ({ lang, ...rest }: { lang: string } & Record<string, string>) => (
  <>
    <input type="hidden" name="lang" value={lang} />
    {Object.entries(rest).map(([k, v]) => <input key={k} type="hidden" name={k} value={v} />)}
  </>
);

// One tap: the schedule shown is still correct.
export function ConfirmScheduleButton({ lang, practiceId, t }: { lang: string; practiceId: string; t: P }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(confirmScheduleAction, {});
  return (
    <form action={action} className="space-y-2">
      <Hidden lang={lang} practiceId={practiceId} />
      <Button type="submit" size="sm" full disabled={pending || state.ok}>
        <Check className="size-4" aria-hidden />
        {t.confirmNow}
      </Button>
      <Msg state={state} ok={t.confirmedMsg} errors={t.schedule.errors} />
    </form>
  );
}

type Row = { key: number; weekday: number; start: string; end: string; capacity: number; slotMinutes: number | null };

export function ScheduleEditor({
  lang, practiceId, t, mode, initial,
}: {
  lang: string; practiceId: string; t: P; mode: "serial_token" | "time_slot";
  initial: { weekday: number; start: string; end: string; capacity: number; slotMinutes: number | null }[];
}) {
  const [rows, setRows] = useState<Row[]>(initial.map((r, i) => ({ ...r, key: i })));
  const [state, action, pending] = useActionState<ActionState, FormData>(saveScheduleAction, {});
  const s = t.schedule;
  const add = () => {
    const last = rows.at(-1);
    setRows([...rows, { key: Date.now(), weekday: last ? (last.weekday + 1) % 7 : 1, start: last?.start ?? "17:00", end: last?.end ?? "20:00",
      capacity: last?.capacity ?? 30, slotMinutes: mode === "time_slot" ? last?.slotMinutes ?? 15 : null }]);
  };
  return (
    <form action={action} className="space-y-3">
      <Hidden lang={lang} practiceId={practiceId} />
      {rows.length === 0 && <p className="text-muted">{s.empty}</p>}
      <ul className="space-y-3">
        {rows.map((r, i) => (
          <li key={r.key} className="space-y-2 rounded-control bg-canvas p-3">
            <div className="flex items-end gap-2">
              <label className="flex-1 space-y-1">
                <span className="text-xs font-semibold text-muted">{s.day}</span>
                <select name="weekday" defaultValue={r.weekday} className={selectClass} aria-label={`${s.day} ${i + 1}`}>
                  {Object.entries(t.weekdays).map(([v, name]) => <option key={v} value={v}>{name}</option>)}
                </select>
              </label>
              <Button type="button" variant="ghost" size="sm" onClick={() => setRows(rows.filter((x) => x.key !== r.key))} aria-label={`${s.remove} ${i + 1}`}>
                <Trash2 className="size-5" aria-hidden />
              </Button>
            </div>
            {/* Two per row so native time pickers stay readable on a 360 px phone. */}
            <div className="grid grid-cols-2 gap-2">
              <label className="space-y-1">
                <span className="text-xs font-semibold text-muted">{s.from}</span>
                <Input name="start" type="time" defaultValue={r.start} required className="px-2!" />
              </label>
              <label className="space-y-1">
                <span className="text-xs font-semibold text-muted">{s.to}</span>
                <Input name="end" type="time" defaultValue={r.end} required className="px-2!" />
              </label>
              <label className="space-y-1">
                <span className="text-xs font-semibold text-muted">{s.seats}</span>
                <Input name="capacity" type="number" inputMode="numeric" min={1} max={500} defaultValue={r.capacity} required />
              </label>
              {mode === "time_slot" ? (
                <label className="space-y-1">
                  <span className="text-xs font-semibold text-muted">{s.slot}</span>
                  <Input name="slotMinutes" type="number" inputMode="numeric" min={5} max={120} defaultValue={r.slotMinutes ?? 15} required />
                </label>
              ) : (
                <input type="hidden" name="slotMinutes" value="" />
              )}
            </div>
          </li>
        ))}
      </ul>
      <Button type="button" variant="secondary" full onClick={add}>
        <Plus className="size-5" aria-hidden />
        {s.addRow}
      </Button>
      <p className="text-sm text-muted">{s.savingConfirms}</p>
      <Msg
        state={state}
        ok={state.values ? format(s.saved, { created: state.values.created }) + (state.values.kept ? ` ${format(s.keptNote, { n: state.values.kept })}` : "") : undefined}
        errors={s.errors}
      />
      <Button type="submit" full disabled={pending}>{s.save}</Button>
    </form>
  );
}

export function ExceptionForm({ lang, practiceId, t, isDoctor, today }: { lang: string; practiceId: string; t: P; isDoctor: boolean; today: string }) {
  const [kind, setKind] = useState<"leave" | "time_change" | "extra_session">("leave");
  const [state, action, pending] = useActionState<ActionState, FormData>(addExceptionAction, {});
  const c = t.changes;
  return (
    <form action={action} className="space-y-3">
      <Hidden lang={lang} practiceId={practiceId} kind={kind} />
      <div className="grid grid-cols-3 gap-1 rounded-control bg-canvas p-1" role="radiogroup" aria-label={c.title}>
        {(["leave", "time_change", "extra_session"] as const).map((k) => (
          <button
            key={k} type="button" role="radio" aria-checked={kind === k} onClick={() => setKind(k)}
            className={cn("min-h-11 rounded-lg px-1 text-sm font-semibold", kind === k ? "bg-white text-brand-700 shadow-card" : "text-muted")}
          >
            {c[k]}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Field id="ex-from" label={kind === "extra_session" ? c.date : c.from}>
          <Input id="ex-from" name="from" type="date" min={today} defaultValue={today} required />
        </Field>
        {kind !== "extra_session" && (
          <Field id="ex-to" label={c.to}>
            <Input id="ex-to" name="to" type="date" min={today} defaultValue={today} required />
          </Field>
        )}
      </div>
      {kind !== "leave" && (
        <div className="grid grid-cols-2 gap-2">
          <Field id="ex-start" label={c.newFrom}><Input id="ex-start" name="newStart" type="time" defaultValue="17:00" required /></Field>
          <Field id="ex-end" label={c.newTo}><Input id="ex-end" name="newEnd" type="time" defaultValue="20:00" required /></Field>
          {kind === "extra_session" && (
            <Field id="ex-cap" label={c.seats}><Input id="ex-cap" name="capacity" type="number" min={1} max={500} defaultValue={20} required /></Field>
          )}
        </div>
      )}
      <Field id="ex-reason" label={c.reason}><Input id="ex-reason" name="reason" maxLength={120} /></Field>
      {kind === "leave" && isDoctor && (
        <label className="flex min-h-11 items-center gap-3 text-sm">
          <input type="checkbox" name="allPractices" className="size-5 accent-brand-600" />
          {c.allPractices}
        </label>
      )}
      <Msg state={state} ok={state.values ? format(c.saved, { n: state.values.n }) : undefined} errors={c.errors} />
      <Button type="submit" full disabled={pending} variant={kind === "leave" ? "danger" : "primary"}>
        <CalendarPlus className="size-5" aria-hidden />
        {c.save}
      </Button>
    </form>
  );
}

export function StaffBookForm({ lang, sessionId, t }: { lang: string; sessionId: string; t: P }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(staffBookAction, {});
  const s = t.sitting;
  return (
    <form action={action} className="space-y-3" key={state.ok ? `ok-${state.values?.serial}` : "form"}>
      <Hidden lang={lang} sessionId={sessionId} />
      <Field id="sb-name" label={s.name}><Input id="sb-name" name="name" required maxLength={80} autoComplete="off" /></Field>
      <Field id="sb-phone" label={s.phone}>
        <Input id="sb-phone" name="phone" type="tel" inputMode="numeric" required maxLength={14} placeholder="98XXXXXXXX" autoComplete="off" />
      </Field>
      <Msg
        state={state}
        ok={state.values ? format(s.added, { serial: new Intl.NumberFormat(lang === "bn" ? "bn-IN" : "en-IN").format(state.values.serial) }) : undefined}
        errors={s.errors}
      />
      <Button type="submit" full disabled={pending}>{s.add}</Button>
    </form>
  );
}

export function LateForm({ lang, sessionId, t, late }: { lang: string; sessionId: string; t: P; late: boolean }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(runningLateAction, {});
  const s = t.sitting;
  return (
    <form action={action} className="space-y-2">
      <Hidden lang={lang} sessionId={sessionId} />
      {late ? (
        <Button type="submit" name="minutes" value="clear" variant="secondary" full disabled={pending}>{s.clearLate}</Button>
      ) : (
        <fieldset>
          <legend className="mb-2 text-sm font-semibold">{s.lateMinutes}</legend>
          <div className="grid grid-cols-4 gap-2">
            {[15, 30, 45, 60].map((m) => (
              <Button key={m} type="submit" name="minutes" value={String(m)} variant="secondary" size="sm" disabled={pending}>
                {format(s.minutes, { n: new Intl.NumberFormat(lang === "bn" ? "bn-IN" : "en-IN").format(m) })}
              </Button>
            ))}
          </div>
        </fieldset>
      )}
      <Msg state={state} ok={state.values?.late ? format(s.lateSet, { n: state.values.n }) : undefined} errors={s.errors} />
    </form>
  );
}

export function CancelSittingForm({ lang, sessionId, t }: { lang: string; sessionId: string; t: P }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(cancelSittingAction, {});
  const s = t.sitting;
  if (state.ok) return <Msg state={state} ok={format(s.cancelledMsg, { n: state.values?.n ?? 0 })} errors={s.errors} />;
  return (
    <details>
      <summary className="flex min-h-12 cursor-pointer list-none items-center justify-center rounded-control font-semibold text-bad-700 ring-1 ring-inset ring-bad-700/30 [&::-webkit-details-marker]:hidden">
        {s.cancelSitting}
      </summary>
      <form action={action} className="mt-3 space-y-3 rounded-control bg-bad-50 p-4">
        <Hidden lang={lang} sessionId={sessionId} />
        <Field id="cs-reason" label={s.cancelReason}><Input id="cs-reason" name="reason" maxLength={120} required /></Field>
        <Msg state={state} errors={s.errors} />
        <Button type="submit" variant="danger" full disabled={pending}>{s.cancelConfirm}</Button>
      </form>
    </details>
  );
}

export function RegisterFacilityForm({
  lang, t, types, towns,
}: { lang: string; t: P; types: Record<string, string>; towns: { slug: string; name: string }[] }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(registerFacilityAction, {});
  const f = t.registerForm;
  const labels: Record<string, string> = { type: f.type, name: f.name, nameBn: f.nameBn, address: f.address, town: f.town, pincode: f.pincode, phone: f.phone, licenceNo: f.licenceNo };
  return (
    <form action={action} className="space-y-4" encType="multipart/form-data">
      <Hidden lang={lang} />
      <Field id="rf-type" label={f.type}>
        <select id="rf-type" name="type" className={selectClass} defaultValue="chamber">
          {Object.entries(types).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </Field>
      <Field id="rf-name" label={f.name}><Input id="rf-name" name="name" required minLength={3} maxLength={120} /></Field>
      <Field id="rf-namebn" label={f.nameBn}><Input id="rf-namebn" name="nameBn" maxLength={120} lang="bn" /></Field>
      <Field id="rf-address" label={f.address}><Input id="rf-address" name="address" required minLength={5} maxLength={200} /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field id="rf-town" label={f.town}>
          <select id="rf-town" name="town" className={selectClass}>
            {towns.map((x) => <option key={x.slug} value={x.slug}>{x.name}</option>)}
          </select>
        </Field>
        <Field id="rf-pin" label={f.pincode}><Input id="rf-pin" name="pincode" inputMode="numeric" pattern="[1-9][0-9]{5}" maxLength={6} required /></Field>
      </div>
      <Field id="rf-phone" label={f.phone}><Input id="rf-phone" name="phone" type="tel" inputMode="numeric" maxLength={14} required /></Field>
      <Field id="rf-licno" label={f.licenceNo}><Input id="rf-licno" name="licenceNo" maxLength={60} /></Field>
      <Field id="rf-licence" label={f.licence} hint={f.fileHint}>
        <input id="rf-licence" name="licence" type="file" accept="application/pdf,image/jpeg,image/png,image/webp" capture="environment" required
          className="block w-full text-sm file:mr-3 file:min-h-11 file:rounded-control file:border-0 file:bg-brand-50 file:px-4 file:font-semibold file:text-brand-700" />
      </Field>
      <Msg state={{ ...state, field: state.field ? labels[state.field] ?? state.field : undefined }} errors={f.errors} />
      <Button type="submit" full disabled={pending}>{f.submit}</Button>
    </form>
  );
}

export function AddDoctorForm({
  lang, facilityId, t, specialities,
}: { lang: string; facilityId: string; t: P; specialities: { slug: string; name: string }[] }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(addDoctorAction, {});
  const f = t.doctorForm;
  const labels: Record<string, string> = { fullName: f.fullName, registrationNumber: f.reg, council: f.council, degrees: f.degrees, speciality: f.speciality, practisingSince: f.since, feeRupees: f.fee };
  return (
    <form action={action} className="space-y-4" encType="multipart/form-data">
      <Hidden lang={lang} facilityId={facilityId} />
      <Field id="ad-name" label={f.fullName}><Input id="ad-name" name="fullName" required maxLength={80} /></Field>
      <Field id="ad-namebn" label={f.fullNameBn}><Input id="ad-namebn" name="fullNameBn" maxLength={80} lang="bn" /></Field>
      <div className="grid grid-cols-2 gap-3">
        <Field id="ad-reg" label={f.reg}><Input id="ad-reg" name="registrationNumber" required maxLength={40} /></Field>
        <Field id="ad-since" label={f.since}><Input id="ad-since" name="practisingSince" type="number" inputMode="numeric" min={1950} max={new Date().getFullYear()} /></Field>
      </div>
      <Field id="ad-council" label={f.council}><Input id="ad-council" name="council" required maxLength={80} defaultValue="West Bengal Medical Council" /></Field>
      <Field id="ad-degrees" label={f.degrees}><Input id="ad-degrees" name="degrees" required maxLength={160} placeholder="MBBS, MD (Medicine)" /></Field>
      <Field id="ad-spec" label={f.speciality}>
        <select id="ad-spec" name="speciality" className={selectClass}>
          {specialities.map((s) => <option key={s.slug} value={s.slug}>{s.name}</option>)}
        </select>
      </Field>
      <div className="grid grid-cols-2 gap-3">
        <Field id="ad-fee" label={f.fee}><Input id="ad-fee" name="feeRupees" type="number" inputMode="numeric" min={0} max={10000} required defaultValue={300} /></Field>
        <Field id="ad-mode" label={f.mode}>
          <select id="ad-mode" name="mode" className={selectClass} defaultValue="serial_token">
            <option value="serial_token">{f.modeSerial}</option>
            <option value="time_slot">{f.modeSlot}</option>
          </select>
        </Field>
      </div>
      <Field id="ad-cert" label={f.certificate} hint={t.registerForm.fileHint}>
        <input id="ad-cert" name="certificate" type="file" accept="application/pdf,image/jpeg,image/png,image/webp"
          className="block w-full text-sm file:mr-3 file:min-h-11 file:rounded-control file:border-0 file:bg-brand-50 file:px-4 file:font-semibold file:text-brand-700" />
      </Field>
      <Msg state={{ ...state, field: state.field ? labels[state.field] ?? state.field : undefined }} errors={f.errors} />
      <Button type="submit" full disabled={pending}>{f.submit}</Button>
    </form>
  );
}
