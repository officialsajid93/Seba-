import Link from "next/link";
import { ChevronRight, Clock, TriangleAlert } from "lucide-react";
import { format } from "@/i18n/config";
import type { Dictionary } from "@/i18n/dictionaries";
import { formatNumber, formatSitting } from "@/lib/format";
import { pick } from "@/server/directory";
import type { ManagedPractice, SittingSummary } from "@/server/provider/service";
import { ConfirmedAgo } from "@/components/ui/availability";
import { Badge, Card } from "@/components/ui/primitives";
import { ConfirmScheduleButton } from "./forms";

export function SittingRow({ s, lang, t, showDoctor }: { s: SittingSummary; lang: string; t: Dictionary; showDoctor?: boolean }) {
  const when = formatSitting(s.startsAt, s.endsAt, lang);
  const pct = s.capacity ? Math.min(100, Math.round((s.booked / s.capacity) * 100)) : 0;
  return (
    <Link href={`/${lang}/provider/sitting/${s.id}`} className="flex items-center gap-3 rounded-control bg-canvas px-3 py-2.5 hover:bg-brand-50">
      <div className="min-w-0 flex-1 space-y-1">
        <p className="text-sm font-semibold">{when.day} · {when.time}</p>
        {showDoctor && <p className="truncate text-xs text-muted">{pick(s.doctor, lang)} · {pick(s.facility, lang)}</p>}
        <div className="flex items-center gap-2">
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-line" aria-hidden>
            <div className="h-full rounded-full bg-brand-600" style={{ width: `${pct}%` }} />
          </div>
          <span className="shrink-0 text-xs text-muted">
            {format(t.provider.booked, { booked: formatNumber(s.booked, lang), capacity: formatNumber(s.capacity, lang) })}
          </span>
        </div>
        {s.status === "cancelled" && <Badge tone="bad">{t.availability.cancelled}</Badge>}
        {s.status === "running_late" && <Badge tone="warn" icon={<Clock className="size-3.5" aria-hidden />}>{t.provider.sitting.lateNow}</Badge>}
      </div>
      <ChevronRight className="size-5 shrink-0 text-subtle" aria-hidden />
    </Link>
  );
}

export function PracticeCard({ p, lang, t, now, sittings }: { p: ManagedPractice; lang: string; t: Dictionary; now: Date; sittings: SittingSummary[] }) {
  return (
    <Card className="space-y-3">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-semibold">{pick(p.doctor, lang)}</p>
          <p className="text-sm text-muted">{pick(p.facility, lang)}</p>
        </div>
        <Link href={`/${lang}/provider/practice/${p.id}`} className="shrink-0 text-sm font-semibold text-brand-700 underline-offset-2 hover:underline">
          {t.provider.manageSchedule}
        </Link>
      </div>
      {!p.active || !p.doctor.verified ? (
        <Badge tone="warn">{t.provider.waitingVerification}</Badge>
      ) : p.stale ? (
        <div className="space-y-2 rounded-control bg-warn-50 p-3">
          <p className="flex items-start gap-2 text-sm text-warn-700">
            <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
            {t.provider.scheduleStale}
          </p>
          <ConfirmScheduleButton lang={lang} practiceId={p.id} t={t.provider} />
        </div>
      ) : (
        <ConfirmedAgo t={t.availability} confirmedAt={p.confirmedAt} now={now} />
      )}
      {sittings.length > 0 && (
        <ul className="space-y-2">
          {sittings.slice(0, 4).map((s) => <li key={s.id}><SittingRow s={s} lang={lang} t={t} /></li>)}
        </ul>
      )}
    </Card>
  );
}
