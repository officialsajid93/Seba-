"use client";

import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { CircleCheck, MapPin } from "lucide-react";
import { cn } from "@/components/ui/primitives";

type Town = { slug: string; name: string; district: string };

export function TownPicker({ lang, towns, current }: { lang: string; towns: Town[]; current?: string }) {
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <ul className="divide-y divide-line" aria-busy={pending}>
      {towns.map((town) => {
        const selected = town.slug === current;
        return (
          <li key={town.slug}>
            <button
              type="button"
              aria-pressed={selected}
              disabled={pending}
              onClick={() => {
                document.cookie = `town=${town.slug}; path=/; max-age=31536000; samesite=lax`;
                start(() => {
                  router.push(`/${lang}`);
                  router.refresh();
                });
              }}
              className={cn(
                "flex min-h-16 w-full items-center gap-3 px-4 text-left hover:bg-canvas disabled:opacity-60",
                selected && "bg-brand-50",
              )}
            >
              <MapPin className="size-5 text-teal-700" aria-hidden />
              <span className="flex-1">
                <span className="block font-semibold text-ink">{town.name}</span>
                <span className="block text-sm text-muted">{town.district}</span>
              </span>
              {selected && <CircleCheck className="size-5 text-brand-600" aria-hidden />}
            </button>
          </li>
        );
      })}
    </ul>
  );
}
