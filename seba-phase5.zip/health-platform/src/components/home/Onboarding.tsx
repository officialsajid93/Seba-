"use client";

import Link from "next/link";
import { useState } from "react";
import { BellRing, CalendarCheck, ShieldCheck } from "lucide-react";
import { Button, ButtonLink, cn } from "@/components/ui/primitives";

type Slide = { title: string; body: string };
const icons = [ShieldCheck, CalendarCheck, BellRing];

export function Onboarding({
  lang,
  slides,
  labels,
}: {
  lang: string;
  slides: Slide[];
  labels: { skip: string; next: string; start: string };
}) {
  const [i, setI] = useState(0);
  const last = i === slides.length - 1;
  const Icon = icons[i % icons.length];
  return (
    <div className="flex min-h-[70dvh] flex-col">
      <div className="flex justify-end">
        <Link href={`/${lang}`} className="min-h-10 rounded-lg px-3 py-2 text-sm font-semibold text-muted hover:text-ink">
          {labels.skip}
        </Link>
      </div>
      <div className="flex flex-1 flex-col items-center justify-center px-2 text-center" aria-live="polite">
        <div className="mb-6 grid size-24 place-items-center rounded-full bg-brand-50 text-brand-600" aria-hidden>
          <Icon className="size-12" />
        </div>
        <h1 className="text-2xl font-bold leading-snug">{slides[i].title}</h1>
        <p className="mt-3 max-w-xs text-muted">{slides[i].body}</p>
      </div>
      <div className="mb-6 flex justify-center gap-2" aria-hidden>
        {slides.map((_, k) => (
          <span key={k} className={cn("h-2 rounded-full transition-all", k === i ? "w-6 bg-brand-600" : "w-2 bg-line")} />
        ))}
      </div>
      {last ? (
        <ButtonLink href={`/${lang}`} full>
          {labels.start}
        </ButtonLink>
      ) : (
        <Button full onClick={() => setI(i + 1)}>
          {labels.next}
        </Button>
      )}
    </div>
  );
}
