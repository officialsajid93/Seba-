import Link from "next/link";
import { BedDouble, FlaskConical, Hospital, Pill, Stethoscope } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries";

const items = [
  { key: "doctors", href: "/doctors", Icon: Stethoscope, tint: "bg-brand-50 text-brand-700" },
  { key: "hospitals", href: "/hospitals", Icon: Hospital, tint: "bg-teal-50 text-teal-700" },
  { key: "nursingHomes", href: "/nursing-homes", Icon: BedDouble, tint: "bg-info-50 text-info-700" },
  { key: "diagnostics", href: "/diagnostics", Icon: FlaskConical, tint: "bg-teal-50 text-teal-700" },
  { key: "medicines", href: "/medicines", Icon: Pill, tint: "bg-brand-50 text-brand-700" },
] as const;

export function CategoryGrid({ lang, t }: { lang: string; t: Dictionary["categories"] }) {
  return (
    <section aria-labelledby="categories-title">
      <h2 id="categories-title" className="mb-3 text-lg font-semibold text-ink">
        {t.title}
      </h2>
      <ul className="grid grid-cols-3 gap-3 sm:grid-cols-5">
        {items.map(({ key, href, Icon, tint }) => (
          <li key={key}>
            <Link
              href={`/${lang}${href}`}
              className="flex h-full min-h-24 flex-col items-center justify-center gap-2 rounded-card bg-white p-3 text-center shadow-card ring-1 ring-line hover:ring-brand-200"
            >
              <span className={`grid size-11 place-items-center rounded-xl ${tint}`} aria-hidden>
                <Icon className="size-6" />
              </span>
              <span className="text-sm font-semibold leading-tight text-ink">{t[key]}</span>
            </Link>
          </li>
        ))}
      </ul>
    </section>
  );
}
