import Link from "next/link";
import { cookies } from "next/headers";
import { ChevronRight, MapPin } from "lucide-react";
import { launchTowns } from "@/config/brand";
import type { ActiveLocale } from "@/i18n/config";

export const TOWN_COOKIE = "town";

function Chip({ lang, label, value }: { lang: string; label: string; value: string }) {
  return (
    <Link
      href={`/${lang}/location`}
      className="inline-flex min-h-11 items-center gap-2 rounded-full bg-white py-1.5 pl-3 pr-2 shadow-card ring-1 ring-line hover:ring-brand-200"
    >
      <MapPin className="size-4 text-teal-700" aria-hidden />
      <span className="text-sm text-muted">{label}:</span>
      <span className="text-sm font-semibold text-ink">{value}</span>
      <ChevronRight className="size-4 text-subtle" aria-hidden />
    </Link>
  );
}

// Reads the saved town at request time; the static shell shows the fallback.
export async function TownChip({ lang, label, choose }: { lang: ActiveLocale; label: string; choose: string }) {
  const slug = (await cookies()).get(TOWN_COOKIE)?.value;
  const town = launchTowns.find((t) => t.slug === slug);
  return <Chip lang={lang} label={label} value={town ? town[lang] : choose} />;
}

export function TownChipFallback({ lang, label, choose }: { lang: string; label: string; choose: string }) {
  return <Chip lang={lang} label={label} value={choose} />;
}
