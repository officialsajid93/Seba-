import { cookies } from "next/headers";
import { Stethoscope } from "lucide-react";
import type { Dictionary } from "@/i18n/dictionaries";
import { searchDoctors } from "@/server/directory";
import { DoctorCard } from "@/components/directory/cards";
import { ButtonLink, Card } from "@/components/ui/primitives";
import { EmptyState } from "@/components/ui/states";
import { TOWN_COOKIE } from "./TownChip";

// Doctors with open seats soon, in the user's chosen town (or all launch towns).
export async function NearbyDoctors({ t, lang }: { t: Dictionary; lang: string }) {
  const townCookie = (await cookies()).get(TOWN_COOKIE)?.value;
  const town = townCookie && /^[a-z-]{2,40}$/.test(townCookie) ? townCookie : undefined;
  const doctors = await searchDoctors({ q: "", town, available: true }, 3);
  const now = new Date();
  if (!doctors.length) {
    return (
      <Card className="p-0">
        <EmptyState icon={<Stethoscope className="size-7" />} title={t.screens.doctors.emptyTitle} body={t.screens.doctors.emptyBody} />
      </Card>
    );
  }
  return (
    <div className="space-y-3">
      <ul className="space-y-3">
        {doctors.map((d) => <li key={d.id}><DoctorCard d={d} lang={lang} t={t} now={now} /></li>)}
      </ul>
      <ButtonLink href={`/${lang}/doctors${town ? `?town=${town}` : ""}`} variant="secondary" full>
        {t.screens.bookings.findDoctor}
      </ButtonLink>
    </div>
  );
}
