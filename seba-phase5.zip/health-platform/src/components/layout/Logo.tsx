// Placeholder mark until the brand is chosen: a rounded cross in brand blue
// with a teal heartbeat line. Also used for the PWA icon (public/icon.svg).
export function Logo({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden focusable="false">
      <rect width="64" height="64" rx="16" fill="#0B5CAD" />
      <path
        d="M26 14h12a2 2 0 0 1 2 2v10h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H40v10a2 2 0 0 1-2 2H26a2 2 0 0 1-2-2V42H14a2 2 0 0 1-2-2V28a2 2 0 0 1 2-2h10V16a2 2 0 0 1 2-2z"
        fill="#fff"
      />
      <path d="M17 34h9l3-6 5 11 3-5h10" fill="none" stroke="#0B7A6E" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
