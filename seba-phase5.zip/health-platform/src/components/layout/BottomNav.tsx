"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { CalendarCheck, House, Pill, Stethoscope, User } from "lucide-react";
import { cn } from "@/components/ui/primitives";

const tabs = [
  { key: "home", path: "", Icon: House },
  { key: "doctors", path: "/doctors", Icon: Stethoscope },
  { key: "medicines", path: "/medicines", Icon: Pill },
  { key: "bookings", path: "/bookings", Icon: CalendarCheck },
  { key: "profile", path: "/profile", Icon: User },
] as const;

export type BottomNavLabels = Record<(typeof tabs)[number]["key"] | "mainMenu", string>;

// Pure view: `rest` is the path after the locale ("/doctors"), or null when
// not known yet (prerendered shell — no tab highlighted until it streams in).
export function BottomNavView({ lang, labels, rest }: { lang: string; labels: BottomNavLabels; rest: string | null }) {
  return (
    <nav
      aria-label={labels.mainMenu}
      className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur"
    >
      <ul className="mx-auto grid max-w-lg grid-cols-5">
        {tabs.map(({ key, path, Icon }) => {
          const active =
            rest !== null && (path === "" ? rest === "" || rest === "/" : rest === path || rest.startsWith(`${path}/`));
          return (
            <li key={key}>
              <Link
                href={`/${lang}${path}`}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-medium",
                  active ? "text-brand-700" : "text-muted hover:text-ink",
                )}
              >
                <span className={cn("grid h-8 w-14 place-items-center rounded-full", active && "bg-brand-50")} aria-hidden>
                  <Icon className="size-5" strokeWidth={active ? 2.4 : 2} />
                </span>
                {labels[key]}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

export function BottomNav({ lang, labels }: { lang: string; labels: BottomNavLabels }) {
  const pathname = usePathname() ?? "";
  return <BottomNavView lang={lang} labels={labels} rest={pathname.slice(lang.length + 1)} />;
}
