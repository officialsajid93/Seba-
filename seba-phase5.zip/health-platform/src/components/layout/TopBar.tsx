import Link from "next/link";
import { Suspense } from "react";
import { brand } from "@/config/brand";
import type { ActiveLocale } from "@/i18n/config";
import { LanguageLink, LanguageSwitcher } from "./LanguageSwitcher";
import { Logo } from "./Logo";

export function TopBar({
  lang,
  switchTo,
  switchLabel,
}: {
  lang: ActiveLocale;
  switchTo: string;
  switchLabel: string;
}) {
  const name = lang === "bn" ? brand.nameBn : brand.name;
  return (
    <header className="sticky top-0 z-30 border-b border-line bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-lg items-center justify-between px-4">
        <Link href={`/${lang}`} className="flex items-center gap-2 rounded-lg" aria-label={name}>
          <Logo className="size-8" />
          <span className="text-lg font-bold tracking-tight text-brand-700">{name}</span>
        </Link>
        <Suspense fallback={<LanguageLink current={lang} label={switchTo} switchLabel={switchLabel} />}>
          <LanguageSwitcher current={lang} label={switchTo} switchLabel={switchLabel} />
        </Suspense>
      </div>
    </header>
  );
}
