"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Languages } from "lucide-react";
import { LOCALE_COOKIE, switchLocalePath, type ActiveLocale } from "@/i18n/config";

type Props = { current: ActiveLocale; label: string; switchLabel: string };

// Pure view. `href` is the same screen in the other language, or that
// language's home while the current path is not known yet (prerendered shell).
export function LanguageLink({ current, label, switchLabel, href }: Props & { href?: string }) {
  const target: ActiveLocale = current === "bn" ? "en" : "bn";
  return (
    <Link
      href={href ?? `/${target}`}
      hrefLang={target}
      lang={target}
      aria-label={switchLabel}
      onClick={() => {
        // Remember the choice for a year so "/" opens in this language next time.
        document.cookie = `${LOCALE_COOKIE}=${target}; path=/; max-age=31536000; samesite=lax`;
      }}
      className="inline-flex min-h-10 items-center gap-1.5 rounded-full px-3 text-sm font-semibold text-brand-700 ring-1 ring-inset ring-brand-200 hover:bg-brand-50"
    >
      <Languages className="size-4" aria-hidden />
      {label}
    </Link>
  );
}

export function LanguageSwitcher(props: Props) {
  const pathname = usePathname() ?? `/${props.current}`;
  const target: ActiveLocale = props.current === "bn" ? "en" : "bn";
  return <LanguageLink {...props} href={switchLocalePath(pathname, target)} />;
}
