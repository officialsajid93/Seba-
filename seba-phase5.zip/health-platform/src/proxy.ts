import { NextResponse, type NextRequest } from "next/server";
import { LOCALE_COOKIE, isActiveLocale, negotiateLocale } from "@/i18n/config";

// Every page lives under /bn/... or /en/... . A path without a language prefix
// is redirected to the user's saved choice, then their browser language, then Bengali.
export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const first = pathname.split("/")[1];
  if (isActiveLocale(first)) return;

  const saved = request.cookies.get(LOCALE_COOKIE)?.value;
  const locale = isActiveLocale(saved) ? saved : negotiateLocale(request.headers.get("accept-language"));
  const url = request.nextUrl.clone();
  url.pathname = `/${locale}${pathname === "/" ? "" : pathname}`;
  return NextResponse.redirect(url);
}

export const config = {
  // Skip API routes, Next internals, and any file with an extension (icons, manifest, fonts).
  matcher: ["/((?!api|_next|.*\\..*).*)"],
};
