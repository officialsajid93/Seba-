// Run a background job from the command line or a system cron:
//   npm run job -- generate-sessions
//   npm run job -- send-reminders
import { jobs, type JobName } from "@/server/jobs";
import { pool } from "@/lib/db";

async function main() {
  const name = process.argv[2] as JobName;
  if (!(name in jobs)) {
    console.error(`Unknown job "${name}". Jobs: ${Object.keys(jobs).join(", ")}`);
    process.exit(1);
  }
  const result = await jobs[name]();
  console.log(`${name}: ${JSON.stringify(result)}`);
  await pool().end();
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
