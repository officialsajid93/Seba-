// Loads clearly fictional demo providers for development and staging.
//   npm run db:seed:demo            load / refresh demo data
//   npm run db:seed:demo -- --remove   delete all demo rows
// Refuses to run when NODE_ENV=production unless ALLOW_DEMO_SEED=true.
import { readFile } from "node:fs/promises";
import path from "node:path";
import { Client } from "pg";

async function main() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not set");
  if (process.env.NODE_ENV === "production" && process.env.ALLOW_DEMO_SEED !== "true") {
    throw new Error("Refusing to load demo data in production. Set ALLOW_DEMO_SEED=true only for a staging database.");
  }
  const sql = await readFile(path.join(process.cwd(), "db", "seed", "demo.sql"), "utf8");
  const client = new Client({ connectionString: url, application_name: "seba-seed" });
  await client.connect();
  try {
    if (process.argv.includes("--remove")) {
      // Run only the delete part of the seed.
      const deletes = sql.slice(0, sql.indexOf("-- The demo verifier"));
      await client.query(`${deletes}\nCOMMIT;`);
      console.log("Demo data removed.");
      return;
    }
    await client.query(sql);
    const [{ doctors, facilities, sittings }] = (
      await client.query(`SELECT
        (SELECT count(*) FROM doctors WHERE is_demo)::int AS doctors,
        (SELECT count(*) FROM facilities WHERE is_demo)::int AS facilities,
        (SELECT count(*) FROM consultation_sessions s JOIN doctor_practices p ON p.id = s.practice_id
           JOIN doctors d ON d.id = p.doctor_id WHERE d.is_demo)::int AS sittings`)
    ).rows;
    console.log(`Demo data loaded: ${doctors} doctors, ${facilities} facilities, ${sittings} sittings (all marked "Demo").`);
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
