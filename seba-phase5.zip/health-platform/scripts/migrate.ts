// Applies db/migrations/*.sql in name order, each once, each in its own
// transaction, and records what ran in schema_migrations (with a checksum so an
// edited, already-applied migration is caught instead of silently skipped).
//
//   npm run db:migrate          apply pending migrations
//   npm run db:migrate -- --status   list applied / pending
import { createHash } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { Client } from "pg";

const dir = path.join(process.cwd(), "db", "migrations");

async function main() {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not set");
  const statusOnly = process.argv.includes("--status");

  const client = new Client({ connectionString: url, application_name: "seba-migrate" });
  await client.connect();
  try {
    await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
      name text PRIMARY KEY,
      checksum text NOT NULL,
      applied_at timestamptz NOT NULL DEFAULT now()
    )`);
    // One migrator at a time, even if two deploys start together.
    await client.query("SELECT pg_advisory_lock(727274)");

    const files = (await readdir(dir)).filter((f) => f.endsWith(".sql")).sort();
    const applied = new Map(
      (await client.query<{ name: string; checksum: string }>("SELECT name, checksum FROM schema_migrations")).rows.map(
        (r) => [r.name, r.checksum],
      ),
    );

    let ran = 0;
    for (const file of files) {
      const sql = await readFile(path.join(dir, file), "utf8");
      const checksum = createHash("sha256").update(sql).digest("hex");
      const prior = applied.get(file);
      if (prior) {
        if (prior !== checksum) {
          throw new Error(`${file} was changed after it was applied. Write a new migration instead of editing it.`);
        }
        if (statusOnly) console.log(`applied  ${file}`);
        continue;
      }
      if (statusOnly) {
        console.log(`pending  ${file}`);
        continue;
      }
      // Migration files manage their own BEGIN/COMMIT; strip them so the
      // runner can record the migration in the same transaction.
      const body = sql.replace(/^\s*BEGIN;\s*$/im, "").replace(/^\s*COMMIT;\s*$/im, "");
      await client.query("BEGIN");
      try {
        await client.query(body);
        await client.query("INSERT INTO schema_migrations (name, checksum) VALUES ($1, $2)", [file, checksum]);
        await client.query("COMMIT");
      } catch (err) {
        await client.query("ROLLBACK");
        throw new Error(`Migration ${file} failed: ${(err as Error).message}`);
      }
      console.log(`applied  ${file}`);
      ran++;
    }
    if (!statusOnly) console.log(ran ? `${ran} migration(s) applied.` : "Database is up to date.");
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
