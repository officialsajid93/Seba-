// Booking service against a real database. Creates its own doctor, clinic,
// schedules and users, and removes them afterwards.
//   TEST_DATABASE_URL=postgres://... npm run test:integration
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

const url = process.env.TEST_DATABASE_URL;
process.env.DATABASE_URL = url ?? "postgresql://unused";
process.env.SESSION_SECRET ??= "integration-test-secret-integration-test";

const PREFIX = "+91700000"; // test phone numbers +917000000000..+917000000099

describe.skipIf(!url)("Phase 4 booking service (database)", async () => {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const { query, pool } = await import("@/lib/db");
  const booking = await import("@/server/booking");
  const { sendRemindersJob, generateSessionsJob } = await import("@/server/jobs");

  const ids = { doctor: "", serialPractice: "", slotPractice: "", users: [] as string[], self: [] as string[] };

  async function cleanup() {
    await query(`DELETE FROM notifications WHERE user_id IN (SELECT id FROM users WHERE phone_e164 LIKE $1)`, [`${PREFIX}%`]);
    await query(`DELETE FROM waitlist_entries WHERE user_id IN (SELECT id FROM users WHERE phone_e164 LIKE $1)`, [`${PREFIX}%`]);
    await query(`DELETE FROM appointment_events WHERE appointment_id IN (SELECT a.id FROM appointments a JOIN users u ON u.id = a.booked_by_user_id WHERE u.phone_e164 LIKE $1)`, [`${PREFIX}%`]);
    await query(`DELETE FROM appointments WHERE booked_by_user_id IN (SELECT id FROM users WHERE phone_e164 LIKE $1)`, [`${PREFIX}%`]);
    await query(`DELETE FROM consultation_sessions WHERE practice_id IN (SELECT p.id FROM doctor_practices p JOIN doctors d ON d.id = p.doctor_id WHERE d.registration_number = 'IT-P4')`);
    await query(`DELETE FROM schedule_templates WHERE practice_id IN (SELECT p.id FROM doctor_practices p JOIN doctors d ON d.id = p.doctor_id WHERE d.registration_number = 'IT-P4')`);
    await query(`DELETE FROM doctor_practices WHERE doctor_id IN (SELECT id FROM doctors WHERE registration_number = 'IT-P4')`);
    await query(`DELETE FROM doctors WHERE registration_number = 'IT-P4'`);
    await query(`DELETE FROM facilities WHERE name LIKE 'IT-P4 %'`);
    await query(`DELETE FROM patients WHERE account_user_id IN (SELECT id FROM users WHERE phone_e164 LIKE $1)`, [`${PREFIX}%`]);
    await query(`DELETE FROM users WHERE phone_e164 LIKE $1`, [`${PREFIX}%`]);
  }

  beforeAll(async () => {
    await cleanup();
    const users = await query<{ id: string }>(
      `INSERT INTO users (phone_e164, display_name, preferred_lang)
       SELECT '${PREFIX}' || lpad(g::text, 4, '0'), 'IT user ' || g, CASE WHEN g % 2 = 0 THEN 'bn' ELSE 'en' END::app_language
         FROM generate_series(0, 39) g RETURNING id`,
    );
    ids.users = users.map((u) => u.id);
    const pats = await query<{ id: string }>(
      `INSERT INTO patients (account_user_id, relation, full_name) SELECT id, 'self', display_name FROM users WHERE id = ANY($1::uuid[])
       RETURNING id`,
      [ids.users],
    );
    // keep patient order aligned with users
    const map = await query<{ id: string; account_user_id: string }>(`SELECT id, account_user_id FROM patients WHERE id = ANY($1::uuid[])`, [pats.map((p) => p.id)]);
    ids.self = ids.users.map((u) => map.find((m) => m.account_user_id === u)!.id);

    const [{ id: town }] = await query<{ id: string }>(`SELECT id FROM localities WHERE slug = 'dhuliyan'`);
    const [doc] = await query<{ id: string }>(
      `INSERT INTO doctors (full_name, registration_number, registration_council, verification_status, verified_at, verified_by)
       VALUES ('IT-P4 Doctor', 'IT-P4', 'IT Council', 'verified', now(), $1) RETURNING id`,
      [ids.users[39]],
    );
    ids.doctor = doc.id;
    const facs = await query<{ id: string }>(
      `INSERT INTO facilities (type, name, address_line, locality_id, verification_status, is_published)
       VALUES ('chamber', 'IT-P4 Chamber', 'x', $1, 'verified', true), ('clinic', 'IT-P4 Clinic', 'x', $1, 'verified', true) RETURNING id`,
      [town],
    );
    const prs = await query<{ id: string }>(
      `INSERT INTO doctor_practices (doctor_id, facility_id, consultation_fee_paise, booking_mode, schedule_state, schedule_confirmed_at, schedule_confirmed_by)
       VALUES ($1, $2, 25000, 'serial_token', 'confirmed', now(), $4), ($1, $3, 35000, 'time_slot', 'confirmed', now(), $4) RETURNING id`,
      [ids.doctor, facs[0].id, facs[1].id, ids.users[39]],
    );
    ids.serialPractice = prs[0].id;
    ids.slotPractice = prs[1].id;
    await query(
      `INSERT INTO schedule_templates (practice_id, weekday, start_time, end_time, capacity, slot_minutes)
       SELECT $1::uuid, g, time '18:00', time '20:00', 20, NULL::smallint FROM generate_series(0, 6) g
       UNION ALL SELECT $2::uuid, g, time '10:00', time '11:00', 10, 15::smallint FROM generate_series(0, 6) g`,
      [ids.serialPractice, ids.slotPractice],
    );
    await generateSessionsJob();
  });

  afterAll(async () => {
    await cleanup();
    await pool().end();
  });

  const serialSessions = () =>
    query<{ id: string; seats_left: number }>(
      `SELECT id, seats_left FROM bookable_sessions WHERE practice_id = $1 ORDER BY starts_at`,
      [ids.serialPractice],
    );

  it("nightly job generated sittings for both practices, and is idempotent", async () => {
    expect((await serialSessions()).length).toBeGreaterThanOrEqual(12);
    expect((await generateSessionsJob()).created).toBe(0);
  });

  it("books a serial, records SMS + in-app notification, and enforces ownership", async () => {
    const [s] = await serialSessions();
    const res = await booking.bookForUser({ userId: ids.users[0], sessionId: s.id, patientId: ids.self[0] });
    expect(res.ok).toBe(true);
    if (!res.ok) return;
    const n = await query<{ channel: string; status: string; payload: { text?: string } }>(
      `SELECT channel, status, payload FROM notifications WHERE user_id = $1 AND template_key = 'booking_confirmed'`,
      [ids.users[0]],
    );
    expect(n.map((x) => x.channel).sort()).toEqual(["in_app", "sms"]);
    expect(n.find((x) => x.channel === "sms")!.status).toBe("dev_logged");
    expect(n.find((x) => x.channel === "in_app")!.payload.text).toMatch(/বুকিং নিশ্চিত/); // user 0 prefers Bengali

    expect(await booking.getMyAppointment(ids.users[1], res.appointmentId)).toBeNull();
    expect(await booking.cancelMine(ids.users[1], res.appointmentId)).toEqual({ ok: false, error: "NOT_FOUND" });
    expect(await booking.bookForUser({ userId: ids.users[1], sessionId: s.id, patientId: ids.self[0] })).toEqual({ ok: false, error: "PATIENT_NOT_OWNED" });
    expect(await booking.bookForUser({ userId: ids.users[0], sessionId: s.id, patientId: ids.self[0] })).toEqual({ ok: false, error: "ALREADY_BOOKED" });
  });

  it("time slots: taken slots disappear from the list and cannot be double-booked", async () => {
    const [s] = await query<{ id: string }>(`SELECT id FROM bookable_sessions WHERE practice_id = $1 ORDER BY starts_at LIMIT 1`, [ids.slotPractice]);
    const before = await booking.getBookingContext(s.id, ids.users[2]);
    expect(before!.freeSlots).toHaveLength(4); // 10:00-11:00 in 15-minute slots
    const slot = before!.freeSlots[1].toISOString();
    expect((await booking.bookForUser({ userId: ids.users[2], sessionId: s.id, patientId: ids.self[2], slot })).ok).toBe(true);
    expect(await booking.bookForUser({ userId: ids.users[3], sessionId: s.id, patientId: ids.self[3], slot })).toEqual({ ok: false, error: "ALREADY_BOOKED" });
    expect(await booking.bookForUser({ userId: ids.users[3], sessionId: s.id, patientId: ids.self[3], slot: "not-a-date" })).toEqual({ ok: false, error: "INVALID_SLOT" });
    const after = await booking.getBookingContext(s.id, ids.users[3]);
    expect(after!.freeSlots.map((d) => d.toISOString())).not.toContain(slot);
    expect(after!.freeSlots).toHaveLength(3);
  });

  it("reschedules within the same practice; the old booking disappears from the list", async () => {
    const { upcoming } = await booking.listMyAppointments(ids.users[0]);
    const appt = upcoming[0];
    const options = await booking.rescheduleOptions(ids.users[0], appt.id);
    expect(options.length).toBeGreaterThan(0);
    const res = await booking.rescheduleMine(ids.users[0], appt.id, options[0].id);
    expect(res.ok).toBe(true);
    const after = await booking.listMyAppointments(ids.users[0]);
    expect(after.upcoming).toHaveLength(1);
    expect(after.upcoming[0].sessionId).toBe(options[0].id);
    // A sitting of a different practice is refused.
    const [other] = await query<{ id: string }>(`SELECT id FROM bookable_sessions WHERE practice_id = $1 LIMIT 1`, [ids.slotPractice]);
    if (res.ok) expect(await booking.rescheduleMine(ids.users[0], res.appointmentId, other.id)).toEqual({ ok: false, error: "NOT_FOUND" });
  });

  it("waiting list: a cancellation offers the seat to the first person waiting, by SMS", async () => {
    const sessions = await serialSessions();
    const s = sessions[3];
    await query(`UPDATE consultation_sessions SET capacity = 2 WHERE id = $1`, [s.id]);
    const a = await booking.bookForUser({ userId: ids.users[4], sessionId: s.id, patientId: ids.self[4] });
    await booking.bookForUser({ userId: ids.users[5], sessionId: s.id, patientId: ids.self[5] });
    expect(await booking.bookForUser({ userId: ids.users[6], sessionId: s.id, patientId: ids.self[6] })).toEqual({ ok: false, error: "SESSION_FULL" });
    expect(await booking.joinWaitlist(ids.users[6], s.id, ids.self[6])).toBe(true);
    expect(await booking.joinWaitlist(ids.users[7], s.id, ids.self[6])).toBe(false); // someone else's patient
    if (!a.ok) throw new Error("setup failed");
    expect(await booking.cancelMine(ids.users[4], a.appointmentId)).toEqual({ ok: true });
    const offers = await query(`SELECT 1 FROM notifications WHERE user_id = $1 AND template_key = 'seat_offered' AND channel = 'sms'`, [ids.users[6]]);
    expect(offers).toHaveLength(1);
    expect((await booking.bookForUser({ userId: ids.users[6], sessionId: s.id, patientId: ids.self[6] })).ok).toBe(true);
  });

  it("race through the app layer: 30 people, 5 seats, exactly 5 bookings", async () => {
    const s = (await serialSessions())[5];
    await query(`UPDATE consultation_sessions SET capacity = 5 WHERE id = $1`, [s.id]);
    const results = await Promise.all(
      Array.from({ length: 30 }, (_, i) => booking.bookForUser({ userId: ids.users[8 + i], sessionId: s.id, patientId: ids.self[8 + i] })),
    );
    expect(results.filter((r) => r.ok)).toHaveLength(5);
    expect(results.filter((r) => !r.ok && r.error === "SESSION_FULL")).toHaveLength(25);
    const [row] = await query<{ active_count: number; tokens: number }>(
      `SELECT active_count, (SELECT count(DISTINCT token_number)::int FROM appointments WHERE session_id = $1 AND status = 'confirmed') AS tokens
         FROM consultation_sessions WHERE id = $1`,
      [s.id],
    );
    expect(row).toEqual({ active_count: 5, tokens: 5 });
  });

  it("reminders go out once for tomorrow's bookings", async () => {
    const [tomorrow] = await query<{ id: string }>(
      `SELECT id FROM bookable_sessions WHERE practice_id = $1 AND session_date = (now() AT TIME ZONE 'Asia/Kolkata')::date + 1`,
      [ids.serialPractice],
    );
    if (tomorrow) await booking.bookForUser({ userId: ids.users[38], sessionId: tomorrow.id, patientId: ids.self[38] });
    const first = await sendRemindersJob();
    const second = await sendRemindersJob();
    expect(first.sent).toBeGreaterThanOrEqual(tomorrow ? 1 : 0);
    expect(second.sent).toBe(0);
  });
});
