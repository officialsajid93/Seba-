// Provider dashboards against a real database: access control between
// clinics, staff bookings, leave with SMS, schedule edits, onboarding.
// Needs the demo seed (npm run db:seed:demo); re-seeds at the end.
//   TEST_DATABASE_URL=postgres://... npm run test:integration
import { readFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

const url = process.env.TEST_DATABASE_URL;
process.env.DATABASE_URL = url ?? "postgresql://unused";
process.env.SESSION_SECRET ??= "integration-test-secret-integration-test";
process.env.STORAGE_LOCAL_DIR = path.join(os.tmpdir(), "seba-it-files");

const STAFF_CHAMBER = "de000000-0000-4000-8000-000000000201"; // staff at Demo Chamber (f1)
const ADMIN_HOSPITAL = "de000000-0000-4000-8000-000000000202"; // admin at Demo General Hospital (f2)
const DOCTOR_ANWAR = "de000000-0000-4000-8000-000000000203"; // doctor account, practices a1 (f1) and a2 (f2)
const A1 = "de000000-0000-4000-8000-0000000000a1"; // Anwar @ chamber
const A3 = "de000000-0000-4000-8000-0000000000a3"; // Priya @ polyclinic
const A4 = "de000000-0000-4000-8000-0000000000a4"; // Rafiq @ hospital
const F1 = "de000000-0000-4000-8000-0000000000f1";
const F2 = "de000000-0000-4000-8000-0000000000f2";

describe.skipIf(!url)("Phase 5 provider dashboards (database)", async () => {
  vi.spyOn(console, "info").mockImplementation(() => {});
  const { query, pool } = await import("@/lib/db");
  const access = await import("@/server/provider/access");
  const svc = await import("@/server/provider/service");
  const onboarding = await import("@/server/provider/onboarding");
  const directory = await import("@/server/directory");
  const demoSql = await readFile(path.join(process.cwd(), "db", "seed", "demo.sql"), "utf8");

  const nextSitting = async (practiceId: string) =>
    (await query<{ id: string }>(
      `SELECT id FROM consultation_sessions WHERE practice_id = $1 AND status = 'scheduled' AND starts_at > now() ORDER BY starts_at LIMIT 1`, [practiceId]))[0].id;

  async function cleanup() {
    await query(`DELETE FROM verification_documents WHERE request_id IN (SELECT id FROM verification_requests WHERE submitted_by IN ($1, $2))`, [STAFF_CHAMBER, ADMIN_HOSPITAL]);
    await query(`DELETE FROM verification_requests WHERE submitted_by IN ($1, $2)`, [STAFF_CHAMBER, ADMIN_HOSPITAL]);
    await query(`DELETE FROM user_roles WHERE facility_id IN (SELECT id FROM facilities WHERE name LIKE 'IT5 %')`);
    await query(`DELETE FROM facilities WHERE name LIKE 'IT5 %'`);
    await query(`DELETE FROM doctor_practices WHERE doctor_id IN (SELECT id FROM doctors WHERE registration_number LIKE 'IT5-%')`);
    await query(`DELETE FROM doctor_specialities WHERE doctor_id IN (SELECT id FROM doctors WHERE registration_number LIKE 'IT5-%')`);
    await query(`DELETE FROM doctor_qualifications WHERE doctor_id IN (SELECT id FROM doctors WHERE registration_number LIKE 'IT5-%')`);
    await query(`DELETE FROM doctors WHERE registration_number LIKE 'IT5-%'`);
  }

  beforeAll(async () => {
    await query(demoSql);
    await cleanup();
  });
  afterAll(async () => {
    await cleanup();
    await query(`DELETE FROM notifications WHERE user_id IN (SELECT id FROM users WHERE phone_e164 LIKE '+91811111%')`);
    await query(demoSql); // restores demo sittings and removes test bookings on them
    await query(`DELETE FROM patients WHERE account_user_id IN (SELECT id FROM users WHERE phone_e164 LIKE '+91811111%')`);
    await query(`DELETE FROM users WHERE phone_e164 LIKE '+91811111%'`);
    await pool().end();
  });

  it("each account sees only its own clinics and doctors", async () => {
    const staff = await access.getProviderScope(STAFF_CHAMBER);
    expect(staff.facilities.map((f) => [f.id, f.role])).toEqual([[F1, "facility_staff"]]);
    const doc = await access.getProviderScope(DOCTOR_ANWAR);
    expect(doc.doctorIds).toHaveLength(1);
    expect(doc.facilities).toHaveLength(0);
    const practices = await svc.managedPractices(DOCTOR_ANWAR);
    expect(practices.map((p) => p.facility.id).sort()).toEqual([F1, F2].sort());
    expect(practices.every((p) => p.role === "doctor")).toBe(true);
  });

  it("roles are checked per practice: no reaching into another clinic or doctor", async () => {
    expect(await access.practiceRole(STAFF_CHAMBER, A1)).toBe("facility_staff");
    expect(await access.practiceRole(STAFF_CHAMBER, A4)).toBeNull();
    expect(await access.practiceRole(ADMIN_HOSPITAL, A4)).toBe("facility_admin");
    expect(await access.practiceRole(ADMIN_HOSPITAL, A1)).toBeNull();
    expect(await access.practiceRole(DOCTOR_ANWAR, A1)).toBe("doctor");
    expect(await access.practiceRole(DOCTOR_ANWAR, A3)).toBeNull();
    expect(await access.practiceRole(STAFF_CHAMBER, "not-a-uuid")).toBeNull();
    expect(await svc.sittingQueue(STAFF_CHAMBER, await nextSitting(A4))).toBeNull();
    expect(await svc.confirmSchedule(ADMIN_HOSPITAL, A1)).toEqual({ ok: false, error: "FORBIDDEN" });
    expect(await svc.cancelSitting(STAFF_CHAMBER, await nextSitting(A4), "x")).toEqual({ ok: false, error: "FORBIDDEN" });
    expect(await svc.staffBook(STAFF_CHAMBER, await nextSitting(A4), { name: "Test Person", phone: "8111110001" })).toEqual({ ok: false, error: "FORBIDDEN" });
    expect(await onboarding.addDoctorToFacility(STAFF_CHAMBER, F1, {}, [])).toEqual({ ok: false, error: "FORBIDDEN" }); // staff, not admin
  });

  it("staff books phone patients: creates their account, sends SMS, and is audit-logged", async () => {
    const s = await nextSitting(A1);
    const r1 = await svc.staffBook(STAFF_CHAMBER, s, { name: "রহিম শেখ", phone: "81111 10001" });
    expect(r1.ok).toBe(true);
    const [u] = await query<{ id: string; created_by_staff: string }>(`SELECT id, created_by_staff FROM users WHERE phone_e164 = '+918111110001'`);
    expect(u.created_by_staff).toBe(STAFF_CHAMBER);
    expect(await svc.staffBook(STAFF_CHAMBER, s, { name: "রহিম শেখ", phone: "8111110001" })).toEqual({ ok: false, error: "ALREADY_BOOKED" });
    expect((await svc.staffBook(STAFF_CHAMBER, s, { name: "আমিনা শেখ", phone: "8111110001" })).ok).toBe(true); // family member, same phone
    expect(await svc.staffBook(STAFF_CHAMBER, s, { name: "X", phone: "12345" })).toEqual({ ok: false, error: "INVALID" });
    const sms = await query(`SELECT 1 FROM notifications WHERE user_id = $1 AND template_key = 'booking_confirmed' AND channel = 'sms'`, [u.id]);
    expect(sms).toHaveLength(2);
    const logs = await query(`SELECT 1 FROM audit_logs WHERE actor_user_id = $1 AND action = 'booking.staff'`, [STAFF_CHAMBER]);
    expect(logs.length).toBeGreaterThanOrEqual(2);
    const q = await svc.sittingQueue(STAFF_CHAMBER, s);
    expect(q!.patients.filter((p) => p.by_clinic).map((p) => p.patient)).toEqual(expect.arrayContaining(["রহিম শেখ", "আমিনা শেখ"]));
  });

  it("visit status can only be set on the day", async () => {
    const s = await nextSitting(A1);
    const [{ id, starts_at }] = await query<{ id: string; starts_at: Date }>(
      `SELECT a.id, cs.starts_at FROM appointments a JOIN consultation_sessions cs ON cs.id = a.session_id WHERE a.session_id = $1 LIMIT 1`, [s]);
    const isToday = new Date(starts_at.getTime() + 330 * 60_000).toISOString().slice(0, 10) === new Date(Date.now() + 330 * 60_000).toISOString().slice(0, 10);
    const res = await svc.setVisitStatus(STAFF_CHAMBER, id, "checked_in");
    expect(res).toEqual(isToday ? { ok: true } : { ok: false, error: "TOO_EARLY" });
    expect(await svc.setVisitStatus(ADMIN_HOSPITAL, id, "checked_in")).toEqual({ ok: false, error: "FORBIDDEN" });
  });

  it("running late informs every booked patient by SMS", async () => {
    const s = await nextSitting(A1);
    const res = await svc.setRunningLate(STAFF_CHAMBER, s, 45);
    expect(res).toEqual({ ok: true, value: { notified: 2 } });
    const [row] = await query<{ status: string; public_note: string }>(`SELECT status::text, public_note FROM consultation_sessions WHERE id = $1`, [s]);
    expect(row).toEqual({ status: "running_late", public_note: "+45 min" });
    expect(await svc.setRunningLate(STAFF_CHAMBER, s, 3)).toEqual({ ok: false, error: "INVALID" });
    expect((await svc.setRunningLate(STAFF_CHAMBER, s, null)).ok).toBe(true);
  });

  it("leave cancels the sitting and texts every patient; patients see 'on leave'", async () => {
    const s = await nextSitting(A1);
    const [{ d }] = await query<{ d: string }>(`SELECT to_char(session_date, 'YYYY-MM-DD') AS d FROM consultation_sessions WHERE id = $1`, [s]);
    const res = await svc.addException(STAFF_CHAMBER, A1, { kind: "leave", from: d, to: d, reason: "Family emergency", allPractices: false });
    expect(res).toEqual({ ok: true, value: { affected: 2 } });
    const cancelledSms = await query(
      `SELECT 1 FROM notifications n JOIN users u ON u.id = n.user_id WHERE u.phone_e164 = '+918111110001' AND n.template_key = 'session_cancelled' AND n.channel = 'sms'`);
    expect(cancelledSms).toHaveLength(2);
    const doctor = await directory.getDoctor("de000000-0000-4000-8000-0000000000d1");
    const sitting = doctor!.practices.flatMap((p) => p.sittings).find((x) => x.id === s);
    expect(sitting?.state.kind).toBe("on_leave");
    expect(sitting?.bookable).toBe(false);
    // Past dates and staff-wide leave are refused.
    expect(await svc.addException(STAFF_CHAMBER, A1, { kind: "leave", from: "2020-01-01", to: "2020-01-02", reason: "", allPractices: false })).toEqual({ ok: false, error: "INVALID" });
  });

  it("schedule editor: validation, save rebuilds sittings and confirms the schedule", async () => {
    const fd = new FormData();
    for (const [d, a, b] of [["1", "17:00", "20:00"], ["1", "19:00", "21:00"]]) {
      fd.append("weekday", d); fd.append("start", a); fd.append("end", b); fd.append("capacity", "20"); fd.append("slotMinutes", "");
    }
    expect(svc.parseTemplates(fd)).toEqual({ ok: false, error: "OVERLAP" });
    const bad = new FormData();
    bad.append("weekday", "2"); bad.append("start", "20:00"); bad.append("end", "18:00"); bad.append("capacity", "20"); bad.append("slotMinutes", "");
    expect(svc.parseTemplates(bad)).toEqual({ ok: false, error: "END_BEFORE_START" });

    await query(`UPDATE doctor_practices SET schedule_confirmed_at = now() - interval '30 days' WHERE id = $1`, [A1]);
    const res = await svc.saveTemplates(STAFF_CHAMBER, A1, [
      { weekday: 1, start: "16:00", end: "19:00", capacity: 25, slotMinutes: null },
      { weekday: 5, start: "16:00", end: "19:00", capacity: 25, slotMinutes: null },
    ]);
    expect(res.ok).toBe(true);
    const [p] = await query<{ ok: boolean }>(`SELECT schedule_confirmed_at > now() - interval '1 minute' AS ok FROM doctor_practices WHERE id = $1`, [A1]);
    expect(p.ok).toBe(true);
    const fridays = await query(
      `SELECT 1 FROM consultation_sessions WHERE practice_id = $1 AND extract(dow FROM session_date) = 5 AND starts_at > now()`, [A1]);
    expect(fridays.length).toBeGreaterThan(0);
    expect(await svc.saveTemplates(ADMIN_HOSPITAL, A1, [])).toEqual({ ok: false, error: "FORBIDDEN" });
    const audit = await query(`SELECT before_data, after_data FROM audit_logs WHERE action = 'schedule.templates.save' AND entity_id = $1 ORDER BY id DESC LIMIT 1`, [A1]);
    expect(audit[0]).toBeTruthy();
  });

  it("clinic registration: needs a real licence file, stays hidden until verified", async () => {
    const pdf = new File([new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x37, 0x0a])], "licence.pdf");
    const exe = new File([new Uint8Array([0x4d, 0x5a, 0x90, 0x00])], "licence.pdf");
    const input = { type: "clinic", name: "IT5 Test Clinic", address: "Test Road, Ward 3", town: "farakka", pincode: "742212", phone: "9811111111" };
    expect(await onboarding.registerFacility(ADMIN_HOSPITAL, input, [{ docType: "establishment_licence", file: exe }])).toEqual({ ok: false, error: "FILE_TYPE" });
    expect(await onboarding.registerFacility(ADMIN_HOSPITAL, input, [])).toEqual({ ok: false, error: "LICENCE_REQUIRED" });
    expect((await onboarding.registerFacility(ADMIN_HOSPITAL, { ...input, pincode: "12" }, [])).ok).toBe(false);
    const ok = await onboarding.registerFacility(ADMIN_HOSPITAL, input, [{ docType: "establishment_licence", file: pdf }]);
    expect(ok.ok).toBe(true);
    const [f] = await query<{ id: string; is_published: boolean; verification_status: string }>(
      `SELECT id, is_published, verification_status::text FROM facilities WHERE name = 'IT5 Test Clinic'`);
    expect(f).toMatchObject({ is_published: false, verification_status: "submitted" });
    expect(await access.facilityRole(ADMIN_HOSPITAL, f.id)).toBe("facility_admin");
    const docs = await query<{ file_key: string; mime_type: string }>(
      `SELECT d.file_key, d.mime_type FROM verification_documents d JOIN verification_requests r ON r.id = d.request_id WHERE r.entity_id = $1`, [f.id]);
    expect(docs).toHaveLength(1);
    expect(docs[0].mime_type).toBe("application/pdf");
    expect(docs[0].file_key).toMatch(/^verification\/[0-9a-f-]{36}\/establishment_licence-[0-9a-f]{16}\.pdf$/);
    expect((await directory.listFacilities({ q: "IT5" })).length).toBe(0);
  });

  it("adding a doctor: new doctor and the link both wait for verification; no duplicates", async () => {
    const input = {
      fullName: "Dr IT Five", registrationNumber: "IT5-001", council: "West Bengal Medical Council", degrees: "MBBS, MD",
      speciality: "medicine", feeRupees: "400", mode: "serial_token",
    };
    const res = await onboarding.addDoctorToFacility(ADMIN_HOSPITAL, F2, input, []);
    expect(res.ok).toBe(true);
    const [d] = await query<{ verification_status: string; is_active: boolean }>(
      `SELECT d.verification_status::text, dp.is_active FROM doctors d JOIN doctor_practices dp ON dp.doctor_id = d.id WHERE d.registration_number = 'IT5-001'`);
    expect(d).toEqual({ verification_status: "submitted", is_active: false });
    const reqs = await query<{ entity_type: string }>(`SELECT entity_type FROM verification_requests WHERE submitted_by = $1 AND entity_type LIKE 'doctor%' ORDER BY entity_type`, [ADMIN_HOSPITAL]);
    expect(reqs.map((r) => r.entity_type)).toEqual(["doctor", "doctor_facility"]);
    expect(await onboarding.addDoctorToFacility(ADMIN_HOSPITAL, F2, input, [])).toEqual({ ok: false, error: "ALREADY_LINKED" });
    expect((await directory.searchDoctors({ q: "IT Five", available: false })).length).toBe(0);

    // A verified doctor added by another clinic is NOT listed there until the link is checked.
    const linked = await onboarding.addDoctorToFacility(ADMIN_HOSPITAL, F2, {
      ...input, fullName: "Dr. Demo Priya Sen", registrationNumber: "DEMO-0002", council: "Demo Council (not a real registration)",
    }, []);
    expect(linked.ok).toBe(true);
    const priya = await directory.getDoctor("de000000-0000-4000-8000-0000000000d2");
    expect(priya!.practices.map((p) => p.facility.id)).not.toContain(F2);
  });
});
