// Runs against a real, migrated PostgreSQL database with the demo seed loaded:
//   TEST_DATABASE_URL=postgres://... npm run test:integration
// Uses its own phone numbers and cleans up after itself.
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

const url = process.env.TEST_DATABASE_URL;
process.env.DATABASE_URL = url ?? "postgresql://unused";
process.env.SESSION_SECRET ??= "integration-test-secret-integration-test";

const PHONE = "+919000000001";
const PHONE2 = "+919000000002";

describe.skipIf(!url)("OTP login, patients and directory (database)", async () => {
  const { requestOtp, verifyOtp, hashOtp, MAX_ATTEMPTS } = await import("@/server/auth/otp");
  const { query, pool } = await import("@/lib/db");
  const patients = await import("@/server/patients");
  const directory = await import("@/server/directory");

  async function cleanup() {
    await query(`DELETE FROM otp_challenges WHERE phone_e164 IN ($1, $2)`, [PHONE, PHONE2]);
    await query(`DELETE FROM consents WHERE user_id IN (SELECT id FROM users WHERE phone_e164 IN ($1, $2))`, [PHONE, PHONE2]);
    await query(`DELETE FROM patients WHERE account_user_id IN (SELECT id FROM users WHERE phone_e164 IN ($1, $2))`, [PHONE, PHONE2]);
    await query(`DELETE FROM users WHERE phone_e164 IN ($1, $2)`, [PHONE, PHONE2]);
  }

  // Codes are random; capture the one the dev adapter logs.
  let lastCode = "";
  beforeAll(async () => {
    await cleanup();
    vi.spyOn(console, "info").mockImplementation((msg: string) => {
      const m = /code: (\d{6})/.exec(String(msg));
      if (m) lastCode = m[1];
    });
  });
  afterAll(async () => {
    await cleanup();
    await pool().end();
  });

  it("issues a code, stores only its hash, and enforces the one-minute cooldown", async () => {
    const r1 = await requestOtp(PHONE, "203.0.113.5", "bn");
    expect(r1.ok).toBe(true);
    expect(lastCode).toMatch(/^\d{6}$/);
    const [row] = await query<{ code_hash: string }>(`SELECT code_hash FROM otp_challenges WHERE phone_e164 = $1`, [PHONE]);
    expect(row.code_hash).toBe(hashOtp(process.env.SESSION_SECRET!, PHONE, lastCode));
    expect(row.code_hash).not.toContain(lastCode);
    const r2 = await requestOtp(PHONE, "203.0.113.5", "bn");
    expect(r2).toMatchObject({ ok: false, error: "rate_limited" });
  });

  it("counts wrong codes and locks the code after the limit", async () => {
    const wrong = lastCode === "000000" ? "111111" : "000000";
    const first = await verifyOtp(PHONE, wrong);
    expect(first).toEqual({ ok: false, error: "invalid_code", attemptsLeft: MAX_ATTEMPTS - 1 });
    for (let i = 2; i < MAX_ATTEMPTS; i++) await verifyOtp(PHONE, wrong);
    expect(await verifyOtp(PHONE, wrong)).toEqual({ ok: false, error: "too_many_attempts" });
    // Even the right code no longer works once locked.
    expect((await verifyOtp(PHONE, lastCode)).ok).toBe(false);
  });

  it("logs in with the right code, creates the user once, and the code cannot be reused", async () => {
    await query(`UPDATE otp_challenges SET created_at = now() - interval '2 minutes' WHERE phone_e164 = $1`, [PHONE]);
    expect((await requestOtp(PHONE, "203.0.113.5", "en")).ok).toBe(true);
    const ok = await verifyOtp(PHONE, lastCode);
    expect(ok).toMatchObject({ ok: true, isNewUser: true, needsProfile: true });
    expect((await verifyOtp(PHONE, lastCode)).ok).toBe(false);

    await query(`UPDATE otp_challenges SET created_at = now() - interval '2 minutes' WHERE phone_e164 = $1`, [PHONE]);
    await requestOtp(PHONE, "203.0.113.5", "en");
    const again = await verifyOtp(PHONE, lastCode);
    expect(again).toMatchObject({ ok: true, isNewUser: false });
    const users = await query(`SELECT id FROM users WHERE phone_e164 = $1`, [PHONE]);
    expect(users).toHaveLength(1);
  });

  it("expires codes after 10 minutes", async () => {
    await requestOtp(PHONE2, "203.0.113.6", "bn");
    await query(`UPDATE otp_challenges SET expires_at = now() - interval '1 second' WHERE phone_e164 = $1`, [PHONE2]);
    expect(await verifyOtp(PHONE2, lastCode)).toEqual({ ok: false, error: "expired" });
  });

  it("blocks suspended accounts", async () => {
    await query(`UPDATE otp_challenges SET created_at = now() - interval '2 minutes' WHERE phone_e164 = $1`, [PHONE2]);
    await query(`INSERT INTO users (phone_e164, status) VALUES ($1, 'suspended') ON CONFLICT (phone_e164) DO UPDATE SET status = 'suspended'`, [PHONE2]);
    await requestOtp(PHONE2, "203.0.113.6", "bn");
    expect(await verifyOtp(PHONE2, lastCode)).toEqual({ ok: false, error: "suspended" });
  });

  it("family members belong to one account only", async () => {
    const [{ id: a }] = await query<{ id: string }>(`SELECT id FROM users WHERE phone_e164 = $1`, [PHONE]);
    const [{ id: b }] = await query<{ id: string }>(`SELECT id FROM users WHERE phone_e164 = $1`, [PHONE2]);
    await patients.saveSelf(a, { fullName: "Test Self", sex: null, dateOfBirth: null }, "bn");
    await patients.saveSelf(a, { fullName: "Test Self Renamed", sex: "female", dateOfBirth: "1990-01-01" }, "bn");
    expect(await patients.addFamilyMember(a, { fullName: "Test Child", sex: "male", dateOfBirth: "2018-03-02" }, "child")).toBe("ok");
    const list = await patients.listPatients(a);
    expect(list.map((p) => [p.relation, p.fullName])).toEqual([["self", "Test Self Renamed"], ["child", "Test Child"]]);

    const child = list[1].id;
    expect(await patients.removeFamilyMember(b, child)).toBe(false); // someone else's
    expect(await patients.removeFamilyMember(a, list[0].id)).toBe(false); // cannot remove self
    expect(await patients.removeFamilyMember(a, "not-a-uuid")).toBe(false);
    expect(await patients.removeFamilyMember(a, child)).toBe(true);
    expect((await patients.listPatients(a)).map((p) => p.relation)).toEqual(["self"]);
  });

  it("caps family size at 10, even with parallel adds", async () => {
    const [{ id: a }] = await query<{ id: string }>(`SELECT id FROM users WHERE phone_e164 = $1`, [PHONE]);
    const results = await Promise.all(
      Array.from({ length: 14 }, (_, i) =>
        patients.addFamilyMember(a, { fullName: `Member ${String.fromCharCode(65 + i)}`, sex: null, dateOfBirth: null }, "other"),
      ),
    );
    expect(results.filter((r) => r === "ok")).toHaveLength(10);
    expect(results.filter((r) => r === "limit")).toHaveLength(4);
  });

  it("directory: only verified doctors, availability follows the schedule rules", async () => {
    const all = await directory.searchDoctors({ q: "", available: false }, 100);
    const demo = all.filter((d) => d.isDemo);
    expect(demo.length).toBe(6);
    const withSeats = await directory.searchDoctors({ q: "", available: true }, 100);
    const names = withSeats.map((d) => d.name.en);
    expect(names).not.toContain("Dr. Demo Sujoy Mondal"); // schedule never confirmed
    expect(names).not.toContain("Dr. Demo Nasrin Begum"); // confirmed 30 days ago: stale
    // A doctor hidden by verification never appears.
    await query(`UPDATE doctors SET verification_status = 'suspended' WHERE full_name = 'Dr. Demo Priya Sen'`);
    expect((await directory.searchDoctors({ q: "Priya", available: false })).length).toBe(0);
    await query(`UPDATE doctors SET verification_status = 'verified' WHERE full_name = 'Dr. Demo Priya Sen'`);
  });

  it("directory: search works in Bengali, by speciality, town and fee, and tolerates typos", async () => {
    expect((await directory.searchDoctors({ q: "শিশু", available: false })).map((d) => d.name.en)).toContain("Dr. Demo Priya Sen");
    expect((await directory.searchDoctors({ q: "child specialist", available: false })).map((d) => d.name.en)).toContain("Dr. Demo Priya Sen");
    expect((await directory.searchDoctors({ q: "Anwer Hosain", available: false })).map((d) => d.name.en)).toContain("Dr. Demo Anwar Hossain");
    const malda = await directory.searchDoctors({ q: "", town: "malda", available: false });
    expect(new Set(malda.map((d) => d.name.en))).toEqual(new Set(["Dr. Demo Priya Sen", "Dr. Demo Nasrin Begum"]));
    const cheap = await directory.searchDoctors({ q: "", maxFee: 300, available: false });
    expect(cheap.every((d) => d.feeFromPaise <= 30000)).toBe(true);
    // LIKE wildcards in user input are treated as text, not patterns.
    expect(await directory.searchDoctors({ q: "%", available: false })).toHaveLength(0);
  });

  it("doctor page: leave and cancelled sittings are shown as such, never as available", async () => {
    const [rafiq] = await directory.searchDoctors({ q: "Rafiq", available: false });
    const doc = await directory.getDoctor(rafiq.id);
    const states = doc!.practices.flatMap((p) => p.sittings.map((s) => s.state.kind));
    if (states.length) expect(states.filter((k) => k === "on_leave").length).toBeLessThanOrEqual(1);
    const [nasrin] = await directory.searchDoctors({ q: "Nasrin", available: false });
    const stale = await directory.getDoctor(nasrin.id);
    for (const s of stale!.practices.flatMap((p) => p.sittings)) {
      expect(s.state.kind).toBe("unverified");
      expect(s.bookable).toBe(false);
    }
    expect(await directory.getDoctor("not-a-uuid")).toBeNull();
  });
});
