// Shared helpers for browser tests.
import { readFile } from "node:fs/promises";
import { AxeBuilder } from "@axe-core/playwright";

export function makeChecker() {
  const state = { failures: 0 };
  const check = (ok, label) => {
    console.log(`${ok ? "ok  " : "FAIL"} ${label}`);
    if (!ok) state.failures++;
  };
  return { state, check };
}

export const seen = (locator, timeout = 8000) =>
  locator.filter({ visible: true }).first().waitFor({ state: "visible", timeout }).then(() => true, () => false);

export async function axe(page, label, check) {
  await page.waitForLoadState("networkidle");
  await page.waitForFunction(() => document.title.trim().length > 0, null, { timeout: 5000 }).catch(() => {});
  const r = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa"]).analyze();
  const bad = r.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
  check(bad.length === 0, `axe ${label}${bad.length ? `: ${bad.map((v) => `${v.id} (${v.nodes[0]?.target})`).join(", ")}` : ""}`);
}

async function latestOtp(log, after, last4) {
  for (let i = 0; i < 40; i++) {
    const text = (await readFile(log, "utf8")).slice(after);
    const m = [...text.matchAll(/\[DEV OTP — NOT SENT\] \+91\*{6}(\d{4}) code: (\d{6})/g)].filter((x) => x[1] === last4);
    if (m.length) return m.at(-1)[2];
    await new Promise((r) => setTimeout(r, 250));
  }
  throw new Error("OTP not found in server log");
}

// Logs a brand-new user in through the Bengali UI and fills their details.
export async function loginNewUser(page, { base, log, name }) {
  const phone = `9${String(Date.now()).slice(-9)}`;
  await page.goto(`${base}/bn/login`);
  await page.getByLabel("মোবাইল নম্বর").fill(phone);
  await page.getByRole("checkbox").check();
  const offset = (await readFile(log, "utf8")).length;
  await page.getByRole("button", { name: "কোড পাঠান" }).click();
  await page.getByLabel("৬ সংখ্যার কোড").waitFor();
  await page.getByLabel("৬ সংখ্যার কোড").fill(await latestOtp(log, offset, phone.slice(-4)));
  await page.getByRole("button", { name: "যাচাই করে লগ ইন করুন" }).click();
  await page.waitForURL(/\/bn\/profile\/details/);
  await page.getByLabel("আপনার পুরো নাম").fill(name);
  await page.getByRole("button", { name: "সেভ করুন" }).click();
  await page.waitForURL(/\/bn\/profile$/);
  return phone;
}

// Logs in with a given 10-digit number (e.g. a demo provider account). If the
// app asks for details first, fills in `name`.
export async function loginAs(page, { base, log, phone, name }) {
  await page.goto(`${base}/bn/login`);
  await page.getByLabel("মোবাইল নম্বর").fill(phone);
  await page.getByRole("checkbox").check();
  const offset = (await readFile(log, "utf8")).length;
  await page.getByRole("button", { name: "কোড পাঠান" }).click();
  await page.getByLabel("৬ সংখ্যার কোড").waitFor();
  await page.getByLabel("৬ সংখ্যার কোড").fill(await latestOtp(log, offset, phone.slice(-4)));
  await page.getByRole("button", { name: "যাচাই করে লগ ইন করুন" }).click();
  await page.waitForURL(/\/bn\/profile/);
  if (/\/details/.test(page.url())) {
    await page.getByLabel("আপনার পুরো নাম").fill(name);
    await page.getByRole("button", { name: "সেভ করুন" }).click();
    await page.waitForURL(/\/bn\/profile$/);
  }
}
