// End-to-end: a new user, in Bengali, on a phone-sized screen:
// logs in with OTP -> enters name -> adds a family member -> finds a child
// specialist -> opens the profile -> saves the doctor -> sees it in Saved.
// Also checks a wrong code is rejected with a message, and runs axe on each new screen.
//
//   BASE_URL=http://localhost:3000 SERVER_LOG=path/to/server.log node tests/e2e/phase3-flow.mjs
// SERVER_LOG must be the running server's output (dev mode prints the OTP there).
import { readFile, mkdir } from "node:fs/promises";
import { chromium } from "playwright";
import { AxeBuilder } from "@axe-core/playwright";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const LOG = process.env.SERVER_LOG;
const SHOTS = process.env.SCREENSHOTS;
if (!LOG) throw new Error("SERVER_LOG is required");
const phoneLocal = `9${String(Date.now()).slice(-9)}`; // fresh number each run

let failures = 0;
const check = (ok, label) => {
  console.log(`${ok ? "ok  " : "FAIL"} ${label}`);
  if (!ok) failures++;
};
async function axe(page, label) {
  // After in-app navigation the title and streamed content arrive a moment later.
  await page.waitForLoadState("networkidle");
  await page.waitForFunction(() => document.title.trim().length > 0, null, { timeout: 5000 }).catch(() => {});
  const r = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa"]).analyze();
  const bad = r.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
  check(bad.length === 0, `axe ${label}${bad.length ? `: ${bad.map((v) => v.id).join(", ")}` : ""}`);
}
async function latestOtp(after) {
  for (let i = 0; i < 40; i++) {
    const log = await readFile(LOG, "utf8");
    const matches = [...log.slice(after).matchAll(/\[DEV OTP — NOT SENT\] \+91\*{6}(\d{4}) code: (\d{6})/g)].filter(
      (m) => m[1] === phoneLocal.slice(-4),
    );
    if (matches.length) return matches.at(-1)[2];
    await new Promise((r) => setTimeout(r, 250));
  }
  throw new Error("OTP not found in server log");
}
// Waits for streamed content instead of checking the instant after navigation.
const seen = (locator, timeout = 8000) => locator.first().waitFor({ state: "visible", timeout }).then(() => true, () => false);
const shot = async (page, name) => SHOTS && page.screenshot({ path: `${SHOTS}/${name}.png` });

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 360, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: "bn-IN" });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
if (SHOTS) await mkdir(SHOTS, { recursive: true });
const started = Date.now();

// 1. Log in
await page.goto(`${BASE}/bn`);
await page.getByRole("link", { name: "প্রোফাইল" }).click();
await page.getByRole("link", { name: "লগ ইন" }).first().click();
await page.waitForURL(/\/bn\/login/);
await axe(page, "login (phone step)");
await page.getByLabel("মোবাইল নম্বর").fill(phoneLocal);
await page.getByRole("button", { name: "কোড পাঠান" }).click();
check(await seen(page.getByText("এগিয়ে যেতে শর্তাবলিতে রাজি হন")), "consent is required");
await page.getByRole("checkbox").check();
const logOffset = (await readFile(LOG, "utf8")).length;
await page.getByRole("button", { name: "কোড পাঠান" }).click();
await page.getByLabel("৬ সংখ্যার কোড").waitFor();
await shot(page, "flow-1-code");
await axe(page, "login (code step)");
const code = await latestOtp(logOffset);

const wrong = code === "000000" ? "111111" : "000000";
await page.getByLabel("৬ সংখ্যার কোড").fill(wrong);
await page.getByRole("button", { name: "যাচাই করে লগ ইন করুন" }).click();
await page.getByText(/কোড ভুল/).waitFor();
check(true, "wrong code shows an error with tries left");

await page.getByLabel("৬ সংখ্যার কোড").fill(code);
await page.getByRole("button", { name: "যাচাই করে লগ ইন করুন" }).click();
await page.waitForURL(/\/bn\/profile\/details/);
check(true, "new user is asked for their details");

// 2. Details
await axe(page, "details");
await page.getByLabel("আপনার পুরো নাম").fill("রহিমা খাতুন");
await page.getByText("মহিলা").click();
await shot(page, "flow-2-details");
await page.getByRole("button", { name: "সেভ করুন" }).click();
await page.waitForURL(/\/bn\/profile$/);
check(await seen(page.getByRole("heading", { name: /রহিমা খাতুন/ })), "profile greets the user by name");
await shot(page, "flow-3-profile");

// 3. Family member
await page.getByRole("link", { name: "পরিবারের সদস্য" }).click();
await page.waitForURL(/\/bn\/profile\/family/);
await page.getByLabel("পুরো নাম", { exact: true }).fill("আয়েশা খাতুন");
await page.getByLabel("সম্পর্ক").selectOption("child");
await page.getByRole("button", { name: "পরিবারের সদস্য যোগ করুন" }).click();
await page.getByText("আয়েশা খাতুন").first().waitFor();
check(true, "family member added");
await axe(page, "family");
await shot(page, "flow-4-family");

// 4. Find a child specialist
await page.getByRole("navigation", { name: "মূল মেনু" }).getByRole("link", { name: "ডাক্তার" }).click();
await page.waitForURL(/\/bn\/doctors/);
await page.getByText("ফিল্টার").click();
await page.getByLabel("বিভাগ").selectOption("paediatrics");
await page.getByRole("button", { name: "ফলাফল দেখুন" }).click();
await page.waitForURL(/speciality=paediatrics/);
await axe(page, "doctors (filtered)");
await shot(page, "flow-5-doctors");
const card = page.getByRole("link", { name: /ডা\. ডেমো প্রিয়া সেন/ });
check(await seen(card), "filter finds the child specialist");
await card.click();
await page.waitForURL(/\/bn\/doctors\/[0-9a-f-]{36}/);
check(await seen(page.getByRole("heading", { level: 1, name: /প্রিয়া সেন/ })), "doctor profile opens");
check(await seen(page.getByText("ডেমো তালিকা — আসল ডাক্তার নন")), "demo listing is labelled");
check(await seen(page.getByText(/সময়সূচি নিশ্চিত হয়েছে/)), "schedule confirmation time shown");
await axe(page, "doctor profile");
await shot(page, "flow-6-doctor");
const elapsed = (Date.now() - started) / 1000;

// 5. Save the doctor, see it in Saved
await page.getByRole("button", { name: "ডাক্তারকে সেভ করুন" }).click();
await page.getByRole("button", { name: "সেভ থেকে সরান" }).waitFor();
await page.goto(`${BASE}/bn/profile/saved`);
check(await seen(page.getByRole("link", { name: /প্রিয়া সেন/ })), "saved doctor appears in Saved");

// 6. Facility page
await page.goto(`${BASE}/bn/hospitals`);
await page.getByRole("link", { name: /ডেমো জেনারেল হাসপাতাল/ }).click();
await page.waitForURL(/\/bn\/facilities\//);
check(await seen(page.getByText("এখানকার ডাক্তার")), "hospital page lists its doctors");
await axe(page, "facility");
await shot(page, "flow-7-hospital");

// 7. Stale and unconfirmed schedules are never bookable
await page.goto(`${BASE}/en/doctors?q=Nasrin`);
await page.getByRole("link", { name: /Nasrin/ }).click();
await page.waitForURL(/\/en\/doctors\//);
check(await seen(page.getByText(/has not been confirmed recently/)), "stale schedule shows the warning");
check((await page.getByRole("button", { name: "Book" }).count()) === 0, "stale schedule has no Book button");

// 8. Log out — and prove the old session token is dead on the server, not just deleted in the browser.
const oldCookie = (await ctx.cookies()).find((c) => c.name === "seba_session");
await page.goto(`${BASE}/bn/profile`);
await page.getByRole("button", { name: "লগ আউট" }).click();
await page.waitForURL(`${BASE}/bn`);
await page.goto(`${BASE}/bn/profile/family`);
check(await page.waitForURL(/\/bn\/login/, { timeout: 8000 }).then(() => true, () => false), "after logout, private pages redirect to login");
const replay = await browser.newContext();
await replay.addCookies([{ ...oldCookie }]);
const rp = await replay.newPage();
await rp.goto(`${BASE}/bn/profile/family`);
check(await rp.waitForURL(/\/bn\/login/, { timeout: 8000 }).then(() => true, () => false), "replaying the old session cookie is refused");
await replay.close();

check(errors.length === 0, `no page errors${errors.length ? `: ${errors.join(" | ")}` : ""}`);
console.log(`\nNew user: login + details + family + find doctor took ${elapsed.toFixed(1)} s of automated time.`);
await browser.close();
console.log(failures ? `${failures} FAILURE(S)` : "PHASE 3 FLOW PASSED");
process.exit(failures ? 1 : 0);
