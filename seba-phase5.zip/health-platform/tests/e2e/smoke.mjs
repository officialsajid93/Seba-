// Browser smoke test on a phone-sized screen.
// For every screen in both languages: loads with HTTP 200, has no console
// errors, has one <h1>, and has no serious/critical accessibility violations (axe).
// Also checks the language redirect, the language switch, and /api/health.
//
//   BASE_URL=http://localhost:3000 SCREENSHOTS=screenshots node tests/e2e/smoke.mjs
import { mkdir } from "node:fs/promises";
import { chromium } from "playwright";
import { AxeBuilder } from "@axe-core/playwright";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const SHOTS = process.env.SCREENSHOTS;
const routes = [
  "", "/doctors", "/hospitals", "/nursing-homes", "/diagnostics", "/medicines", "/bookings",
  "/profile", "/login", "/search", "/search?q=child%20specialist", "/location", "/onboarding",
  "/help", "/legal/privacy", "/legal/cancellation", "/does-not-exist",
];
if (process.env.SHOW_DESIGN_SYSTEM === "true") routes.push("/design-system");

let failures = 0;
const fail = (msg) => {
  failures++;
  console.log(`  FAIL ${msg}`);
};

const browser = await chromium.launch();
const context = await browser.newContext({
  viewport: { width: 360, height: 780 }, // common small Android screen
  deviceScaleFactor: 2,
  isMobile: true,
  hasTouch: true,
  locale: "bn-IN",
});
if (SHOTS) await mkdir(SHOTS, { recursive: true });

for (const lang of ["bn", "en"]) {
  for (const route of routes) {
    const page = await context.newPage();
    const errors = [];
    page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
    page.on("pageerror", (e) => errors.push(e.message));
    const url = `${BASE}/${lang}${route}`;
    const res = await page.goto(url, { waitUntil: "networkidle" });
    const expectStatus = route === "/does-not-exist" ? 404 : 200;
    const status = res?.status();
    const h1 = await page.locator("h1").count();
    const htmlLang = await page.getAttribute("html", "lang");
    const axe = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa"]).analyze();
    const serious = axe.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
    const label = `${lang}${route || "/"}`;
    // On the 404 page the browser itself logs "Failed to load resource: 404"; that is expected.
    const consoleOk = expectStatus !== 200 || !errors.length;
    const pass = status === expectStatus && consoleOk && h1 >= 1 && htmlLang === lang && !serious.length;
    console.log(`${pass ? "ok  " : "FAIL"} ${label}  [${status}, h1=${h1}, axe=${serious.length}]`);
    if (status !== expectStatus) fail(`${label}: status ${status}, expected ${expectStatus}`);
    if (h1 < 1) fail(`${label}: no <h1>`);
    if (htmlLang !== lang) fail(`${label}: <html lang="${htmlLang}">`);
    if (errors.length && expectStatus === 200) fail(`${label}: console errors: ${errors.join(" | ")}`);
    for (const v of serious) fail(`${label}: axe ${v.id} (${v.impact}) — ${v.help} [${v.nodes.length} nodes]`);
    if (SHOTS) {
      const name = `${lang}${route.replace(/[/?=%]+/g, "_") || "_home"}`;
      await page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: true });
    }
    await page.close();
  }
}

// Language redirect: "/" with a Bengali browser goes to /bn, English browser to /en.
for (const [accept, want] of [["bn-IN,bn;q=0.9", "/bn"], ["en-US,en;q=0.9", "/en"]]) {
  const ctx = await browser.newContext({ extraHTTPHeaders: { "Accept-Language": accept } });
  const p = await ctx.newPage();
  await p.goto(`${BASE}/`);
  const path = new URL(p.url()).pathname;
  console.log(`${path === want ? "ok  " : "FAIL"} redirect / with ${accept} -> ${path}`);
  if (path !== want) fail(`redirect for ${accept} went to ${path}`);
  await ctx.close();
}

// Language switch keeps the current screen and is remembered for "/".
{
  const p = await context.newPage();
  await p.goto(`${BASE}/bn/doctors`);
  await p.getByRole("link", { name: "ভাষা ইংরেজিতে বদলান" }).click();
  await p.waitForURL("**/en/doctors");
  await p.goto(`${BASE}/`);
  const path = new URL(p.url()).pathname;
  console.log(`${path === "/en" ? "ok  " : "FAIL"} language switch remembered -> ${path}`);
  if (path !== "/en") fail(`language choice not remembered (went to ${path})`);
  await p.close();
}

// Town picker saves the town and the home chip shows it.
{
  const p = await context.newPage();
  await p.goto(`${BASE}/bn/location`);
  await p.getByRole("button", { name: /জঙ্গিপুর/ }).click();
  await p.waitForURL(`${BASE}/bn`);
  const chip = await p.getByRole("link", { name: /আপনার শহর/ }).innerText();
  const ok = chip.includes("জঙ্গিপুর");
  console.log(`${ok ? "ok  " : "FAIL"} town picker -> home chip shows "${chip.replace(/\s+/g, " ")}"`);
  if (!ok) fail("town not shown on home chip");
  if (SHOTS) await p.screenshot({ path: `${SHOTS}/bn_home_with_town.png`, fullPage: true });
  await p.close();
}

// Health endpoint reports the database.
{
  const res = await fetch(`${BASE}/api/health`);
  const body = await res.json();
  const ok = res.status === 200 && body.database === "up";
  console.log(`${ok ? "ok  " : "FAIL"} /api/health -> ${res.status} ${JSON.stringify(body)}`);
  if (!ok) fail("health check");
}

// Private files: an unsigned or tampered link is refused.
{
  const res = await fetch(`${BASE}/api/files/rx/u1/x.pdf?exp=9999999999&sig=${"0".repeat(64)}`);
  const ok = res.status === 403;
  console.log(`${ok ? "ok  " : "FAIL"} tampered file link refused -> ${res.status}`);
  if (!ok) fail("tampered file link not refused");
}

await browser.close();
console.log(failures ? `\n${failures} FAILURE(S)` : "\nSMOKE TEST PASSED");
process.exit(failures ? 1 : 0);
