// End-to-end from the clinic side, in Bengali, on a phone-sized screen.
// A patient books online; chamber staff then edit the weekly schedule (timed),
// mark the doctor on leave (patient gets an SMS), add a phone patient to the
// queue, mark the sitting running late; a hospital admin adds a doctor; a new
// clinic registers with a licence photo; a patient cannot open the dashboard.
//
//   BASE_URL=... SERVER_LOG=... DATABASE_URL=... node tests/e2e/phase5-flow.mjs
// Requires the demo seed. DATABASE_URL is used only to re-load it at the start.
import { mkdir, readFile, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import pg from "pg";
import { chromium } from "playwright";
import { axe, loginAs, loginNewUser, makeChecker, seen } from "./helpers.mjs";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const LOG = process.env.SERVER_LOG;
const SHOTS = process.env.SCREENSHOTS;
if (!LOG || !process.env.DATABASE_URL) throw new Error("SERVER_LOG and DATABASE_URL are required");
const { state, check } = makeChecker();
const shot = async (page, name) => SHOTS && page.screenshot({ path: `${SHOTS}/${name}.png` });
if (SHOTS) await mkdir(SHOTS, { recursive: true });

// Fresh demo data so the run is repeatable.
const db = new pg.Client({ connectionString: process.env.DATABASE_URL });
await db.connect();
await db.query(await readFile(path.join(process.cwd(), "db", "seed", "demo.sql"), "utf8"));
const { rows: [target] } = await db.query(
  `SELECT id, to_char(session_date, 'YYYY-MM-DD') AS day FROM bookable_sessions
    WHERE practice_id = 'de000000-0000-4000-8000-0000000000a1' ORDER BY starts_at LIMIT 1`);

const browser = await chromium.launch();
const device = { viewport: { width: 360, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: "bn-IN" };
const errors = [];
const newPage = async () => {
  const ctx = await browser.newContext(device);
  const p = await ctx.newPage();
  p.on("pageerror", (e) => errors.push(e.message));
  return p;
};

// 1. A patient books the chamber sitting online.
const patient = await newPage();
await loginNewUser(patient, { base: BASE, log: LOG, name: "নাজমা বিবি" });
await patient.goto(`${BASE}/bn/book/${target.id}`);
await patient.getByRole("button", { name: "বুকিং নিশ্চিত করুন" }).click();
await patient.waitForURL(/\?new=1/);
const patientBooking = patient.url().split("?")[0];
check(true, "patient booked online");

// 2. Chamber staff log in and open the dashboard from Profile.
const staff = await newPage();
await loginAs(staff, { base: BASE, log: LOG, phone: "6000000201", name: "চেম্বার স্টাফ" });
await staff.getByRole("link", { name: "ক্লিনিক ও ডাক্তারদের জন্য" }).click();
await staff.waitForURL(/\/bn\/provider$/);
check(await seen(staff.getByText("আপনার ক্লিনিক")), "staff dashboard lists their clinic");
check(await seen(staff.getByText(/আনোয়ার/)), "staff dashboard lists the chamber's doctor");
check(!(await staff.getByText(/রফিক/).filter({ visible: true }).count()), "staff do not see another clinic's doctor");
await axe(staff, "provider home", check);
await shot(staff, "p5-1-home");

// 3. Edit the week's schedule (timed): Monday 5-8 pm -> 4-7 pm, add a Friday sitting.
const t0 = Date.now();
await staff.getByRole("link", { name: "সময়সূচি ও চেম্বার" }).first().click();
await staff.waitForURL(/\/bn\/provider\/practice\//);
const rows = staff.locator("li:has(select[name=weekday])").filter({ visible: true });
const mondayRow = rows.filter({ has: staff.locator("select[name=weekday] option[value='1']:checked") }).first();
await mondayRow.locator("input[name=start]").fill("16:00");
await mondayRow.locator("input[name=end]").fill("19:00");
await staff.getByRole("button", { name: "চেম্বার যোগ করুন" }).click();
const newRow = rows.last();
await newRow.locator("select[name=weekday]").selectOption("5");
await newRow.locator("input[name=start]").fill("16:00");
await newRow.locator("input[name=end]").fill("19:00");
await shot(staff, "p5-2-schedule");
await staff.getByRole("button", { name: "সময়সূচি সেভ করুন" }).click();
check(await seen(staff.getByText(/সেভ হয়েছে।.*নতুন চেম্বার তৈরি হয়েছে/)), "schedule saved and sittings rebuilt");
const scheduleSeconds = (Date.now() - t0) / 1000;
check(scheduleSeconds < 120, `week's schedule updated in ${scheduleSeconds.toFixed(1)} s of automated time (target: under 2 minutes)`);
await axe(staff, "schedule editor", check);

// 4. Doctor on leave on the patient's booked day.
await staff.getByRole("radio", { name: "ডাক্তার ছুটিতে" }).click();
await staff.locator("#ex-from").fill(target.day);
await staff.locator("#ex-to").fill(target.day);
await staff.locator("#ex-reason").fill("পারিবারিক কারণে");
await staff.getByRole("button", { name: "সেভ করুন" }).last().click();
check(await seen(staff.getByText(/\d|[০-৯].*জন রোগীকে SMS-এ জানানো হয়েছে/)), "leave saved and patients informed");
check(await seen(staff.getByText("পারিবারিক কারণে")), "leave shows under upcoming changes");
await shot(staff, "p5-3-leave");

await patient.goto(patientBooking);
check(await seen(patient.getByText("ক্লিনিক বাতিল করেছে")), "patient's booking shows cancelled by the clinic");
await patient.goto(`${BASE}/bn/notifications`);
check(await seen(patient.getByText(/বসবেন না/)), "patient got the cancellation SMS / notification");

// 5. Queue: add a phone patient to the next open sitting, then mark running late.
await staff.goto(`${BASE}/bn/provider`);
await staff.getByRole("link", { name: "সময়সূচি ও চেম্বার" }).first().click();
await staff.waitForURL(/\/bn\/provider\/practice\//);
const sittingLinks = staff.locator('a[href*="/provider/sitting/"]').filter({ visible: true });
await sittingLinks.nth(1).click();
await staff.waitForURL(/\/bn\/provider\/sitting\//);
await staff.getByLabel("রোগীর নাম").fill("হাসান আলি");
await staff.getByLabel("মোবাইল নম্বর").fill("8222222222");
await staff.getByRole("button", { name: "লাইনে যোগ করুন" }).click();
check(await seen(staff.getByText(/সিরিয়াল .* দিয়ে যোগ হয়েছে/)), "phone patient added with a serial number");
check(await seen(staff.getByText("হাসান আলি")), "phone patient appears in the queue");
check(await seen(staff.getByText("ক্লিনিক থেকে")), "queue marks who was booked by the clinic");
await staff.getByRole("button", { name: /৩০ মিনিট/ }).click();
check(await seen(staff.getByText(/দেরি জানানো হয়েছে/)), "running late saved and patients informed");
await axe(staff, "sitting queue", check);
await shot(staff, "p5-4-queue");

// 6. Hospital admin adds a doctor (waits for verification).
const admin = await newPage();
await loginAs(admin, { base: BASE, log: LOG, phone: "6000000202", name: "হাসপাতাল অ্যাডমিন" });
await admin.goto(`${BASE}/bn/provider`);
await admin.getByRole("link", { name: /ডেমো জেনারেল হাসপাতাল/ }).click();
await admin.getByRole("link", { name: "ডাক্তার যোগ করুন" }).click();
await admin.waitForURL(/add-doctor/);
await admin.getByLabel("ডাক্তারের পুরো নাম").fill("Dr. Ete Test Doctor");
await admin.getByLabel("রেজিস্ট্রেশন নম্বর").fill(`E2E-${Date.now()}`);
await admin.getByLabel("ডিগ্রি (কমা দিয়ে আলাদা করুন)").fill("MBBS");
await axe(admin, "add doctor form", check);
await admin.getByRole("button", { name: "যাচাইয়ের জন্য জমা দিন" }).click();
await admin.waitForURL(/\/provider\/practice\/.*added=1/);
check(await seen(admin.getByText("যাচাইয়ের অপেক্ষায়")), "new doctor waits for verification");
await db.query(`DELETE FROM verification_requests WHERE entity_id IN (SELECT dp.id FROM doctor_practices dp JOIN doctors d ON d.id = dp.doctor_id WHERE d.full_name = 'Dr. Ete Test Doctor')
                   OR entity_id IN (SELECT id FROM doctors WHERE full_name = 'Dr. Ete Test Doctor')`);
await db.query(`DELETE FROM doctor_practices WHERE doctor_id IN (SELECT id FROM doctors WHERE full_name = 'Dr. Ete Test Doctor')`);
await db.query(`DELETE FROM doctor_qualifications WHERE doctor_id IN (SELECT id FROM doctors WHERE full_name = 'Dr. Ete Test Doctor')`);
await db.query(`DELETE FROM doctor_specialities WHERE doctor_id IN (SELECT id FROM doctors WHERE full_name = 'Dr. Ete Test Doctor')`);
await db.query(`DELETE FROM doctors WHERE full_name = 'Dr. Ete Test Doctor'`);

// 7. A new clinic registers with a licence photo.
const owner = await newPage();
await loginNewUser(owner, { base: BASE, log: LOG, name: "নতুন মালিক" });
await owner.goto(`${BASE}/bn/provider`);
check(await seen(owner.getByText("আপনার ক্লিনিক বা চেম্বার যুক্ত করুন")), "a patient account sees the 'list your clinic' page, not a dashboard");
await owner.goto(`${BASE}/bn/provider/sitting/${target.id}`);
check(await seen(owner.getByText("পাতাটি পাওয়া যায়নি")), "a patient cannot open a clinic's queue");
await owner.goto(`${BASE}/bn/provider/register`);
const licence = path.join(os.tmpdir(), "e2e-licence.png");
await writeFile(licence, Buffer.from("89504e470d0a1a0a0000000d4948445200000001000000010806000000", "hex"));
await owner.getByLabel("নাম", { exact: true }).fill("E2E Test Chamber");
await owner.getByLabel("ঠিকানা").fill("Station Road, Ward 5");
await owner.getByLabel("পিন কোড").fill("742202");
await owner.getByLabel("ক্লিনিকের ফোন").fill("9833333333");
await owner.getByLabel("লাইসেন্স বা রেজিস্ট্রেশন সার্টিফিকেট").setInputFiles(licence);
await axe(owner, "register clinic", check);
await shot(owner, "p5-5-register");
await owner.getByRole("button", { name: "যাচাইয়ের জন্য জমা দিন" }).click();
await owner.waitForURL(/\/bn\/provider\?registered=1/);
check(await seen(owner.getByText("জমা হয়েছে। আমরা আপনার কাগজপত্র যাচাই করব।")), "registration submitted");
check(await seen(owner.getByText("যাচাইয়ের অপেক্ষায়")), "registration shows as waiting for verification");
await shot(owner, "p5-6-submitted");
const publicSearch = await (await fetch(`${BASE}/bn/search?q=E2E%20Test%20Chamber`)).text();
check(!publicSearch.includes("E2E Test Chamber</h3>"), "unverified clinic is not visible to patients");
await db.query(`DELETE FROM verification_documents WHERE request_id IN (SELECT id FROM verification_requests WHERE entity_id IN (SELECT id FROM facilities WHERE name = 'E2E Test Chamber'))`);
await db.query(`DELETE FROM verification_requests WHERE entity_id IN (SELECT id FROM facilities WHERE name = 'E2E Test Chamber')`);
await db.query(`DELETE FROM user_roles WHERE facility_id IN (SELECT id FROM facilities WHERE name = 'E2E Test Chamber')`);
await db.query(`DELETE FROM facilities WHERE name = 'E2E Test Chamber'`);

await db.end();
check(errors.length === 0, `no page errors${errors.length ? `: ${errors.join(" | ")}` : ""}`);
await browser.close();
console.log(state.failures ? `\n${state.failures} FAILURE(S)` : "\nPHASE 5 FLOW PASSED");
process.exit(state.failures ? 1 : 0);
