// End-to-end booking, in Bengali, on a phone-sized screen:
// book a serial -> confirmation with serial + booking ID -> My bookings ->
// change date -> cancel; book by time slot; join the waiting list on a full
// sitting and get a seat-offered notification when someone cancels.
//
//   BASE_URL=... SERVER_LOG=... DATABASE_URL=... node tests/e2e/phase4-flow.mjs
// DATABASE_URL is used only to fill one demo sitting for the waiting-list check.
import { mkdir } from "node:fs/promises";
import pg from "pg";
import { chromium } from "playwright";
import { axe, loginNewUser, makeChecker, seen } from "./helpers.mjs";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const LOG = process.env.SERVER_LOG;
const SHOTS = process.env.SCREENSHOTS;
if (!LOG || !process.env.DATABASE_URL) throw new Error("SERVER_LOG and DATABASE_URL are required");
const { state, check } = makeChecker();
const shot = async (page, name) => SHOTS && page.screenshot({ path: `${SHOTS}/${name}.png` });
if (SHOTS) await mkdir(SHOTS, { recursive: true });

const browser = await chromium.launch();
const device = { viewport: { width: 360, height: 780 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true, locale: "bn-IN" };
const ctx = await browser.newContext(device);
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));

await loginNewUser(page, { base: BASE, log: LOG, name: "সালমা বিবি" });

// 1. Book a serial with Dr. Demo Anwar at the chamber
await page.goto(`${BASE}/bn/doctors?q=Anwar`);
await page.getByRole("link", { name: /আনোয়ার/ }).click();
await page.waitForURL(/\/bn\/doctors\//);
const bookLinks = page.getByRole("link", { name: "বুক করুন" });
check(await seen(bookLinks), "doctor page shows Book buttons on open sittings");
await bookLinks.first().click();
await page.waitForURL(/\/bn\/book\//);
check(await seen(page.getByText("কার জন্য দেখাবেন?")), "booking screen asks who the visit is for");
check(await seen(page.getByText(/সিরিয়াল অনুযায়ী/)), "serial booking explains how the queue works");
await axe(page, "book (serial)", check);
await shot(page, "p4-1-book");
await page.getByRole("button", { name: "বুকিং নিশ্চিত করুন" }).click();
await page.waitForURL(/\/bn\/bookings\/[0-9a-f-]{36}\?new=1/);
check(await seen(page.getByText("বুকিং নিশ্চিত হয়েছে")), "confirmation screen shown");
// Only visible elements: the previous screen can stay mounted (hidden) after navigation.
const visibleCode = () => page.getByText(/^B[A-Z2-9]{8}$/).filter({ visible: true }).first().innerText().then((x) => x.trim());
const code = await visibleCode();
check(/^B[A-Z2-9]{8}$/.test(code), `booking ID shown (${code})`);
check(await seen(page.getByText("সিরিয়াল নম্বর")), "serial number shown");
await axe(page, "booking confirmation", check);
await shot(page, "p4-2-confirmed");

// 2. My bookings
await page.getByRole("navigation", { name: "মূল মেনু" }).getByRole("link", { name: "বুকিং" }).click();
await page.waitForURL(/\/bn\/bookings$/);
check(await seen(page.getByRole("link", { name: /আনোয়ার/ })), "booking listed under upcoming");
await axe(page, "my bookings", check);

// 3. Change date (reschedule), then cancel
await page.getByRole("link", { name: /আনোয়ার/ }).first().click();
await page.waitForURL(/\/bn\/bookings\/[0-9a-f-]{36}$/);
const moveButtons = page.getByRole("button", { name: "এখানে সরান" }).filter({ visible: true });
if (await seen(moveButtons, 3000)) {
  await moveButtons.first().click();
  await page.waitForURL(/\?new=1/);
  await page.getByText("বুকিং নিশ্চিত হয়েছে").filter({ visible: true }).waitFor();
  const newCode = await visibleCode();
  check(newCode !== code, "reschedule creates a new booking ID");
} else {
  check(true, "no other sitting to move to (skipped)");
}
await page.getByText("বুকিং বাতিল করুন").filter({ visible: true }).click();
check(await seen(page.getByText(/আপনার সিট অন্য কেউ পেয়ে যাবেন/)), "cancel asks for confirmation first");
await page.getByRole("button", { name: "হ্যাঁ, বাতিল করুন" }).click();
await page.waitForURL(/cancelled=1/);
check(await seen(page.getByText("আপনি বাতিল করেছেন")), "status shows cancelled by you");
check(await seen(page.getByText("বুকিংয়ের ইতিহাস")), "booking history timeline shown");
await shot(page, "p4-3-cancelled");

// 4. Time-slot booking with Dr. Demo Priya
await page.goto(`${BASE}/bn/doctors?q=Priya`);
await page.getByRole("link", { name: /প্রিয়া/ }).click();
await page.getByRole("link", { name: "বুক করুন" }).first().click();
await page.waitForURL(/\/bn\/book\//);
check(await seen(page.getByText("সময় বেছে নিন")), "time-slot booking asks for a time");
const secondSlot = page.locator('label:has(input[name="slot"])').filter({ visible: true }).nth(1);
const slotText = (await secondSlot.innerText()).trim();
await secondSlot.click();
await axe(page, "book (time slot)", check);
await shot(page, "p4-4-slots");
await page.getByRole("button", { name: "বুকিং নিশ্চিত করুন" }).click();
await page.waitForURL(/\?new=1/);
check(await seen(page.getByText(slotText)), `confirmation shows the chosen time (${slotText})`);

// 5. Waiting list on a full sitting, then a seat opens
const db = new pg.Client({ connectionString: process.env.DATABASE_URL });
await db.connect();
const { rows: [full] } = await db.query(
  `SELECT b.id FROM bookable_sessions b JOIN doctors d ON d.id = b.doctor_id
    WHERE d.full_name = 'Dr. Demo Moumita Das' ORDER BY b.starts_at LIMIT 1`,
);
// Make room for exactly one more booking, which a second user takes.
await db.query(`UPDATE consultation_sessions SET capacity = active_count + 1 WHERE id = $1`, [full.id]);
const other = await browser.newContext(device);
const op = await other.newPage();
await loginNewUser(op, { base: BASE, log: LOG, name: "করিম শেখ" });
await op.goto(`${BASE}/bn/book/${full.id}`);
await op.getByRole("button", { name: "বুকিং নিশ্চিত করুন" }).click();
await op.waitForURL(/\?new=1/);
const otherBooking = op.url().split("?")[0];

await page.goto(`${BASE}/bn/book/${full.id}`);
check(await seen(page.getByText("এই চেম্বারে সিট ভর্তি")), "full sitting offers the waiting list");
await shot(page, "p4-5-waitlist");
await page.getByRole("button", { name: "অপেক্ষা তালিকায় নাম লেখান" }).click();
check(await seen(page.getByText(/আপনি অপেক্ষা তালিকায় আছেন/)), "joined the waiting list");

await op.goto(otherBooking);
await op.getByText("বুকিং বাতিল করুন").filter({ visible: true }).click();
await op.getByRole("button", { name: "হ্যাঁ, বাতিল করুন" }).click();
await op.waitForURL(/cancelled=1/);

await page.goto(`${BASE}/bn/notifications`);
check(await seen(page.getByText(/একটি সিট খালি হয়েছে/)), "waiting patient is notified that a seat opened");
check(await seen(page.getByText(/বুকিং নিশ্চিত/)), "booking confirmations appear in notifications");
await axe(page, "notifications", check);
await shot(page, "p4-6-notifications");
await page.goto(`${BASE}/bn/book/${full.id}`);
await page.getByRole("button", { name: "বুকিং নিশ্চিত করুন" }).click();
check(await page.waitForURL(/\?new=1/).then(() => true, () => false), "waiting patient books the freed seat");

await db.end();
await other.close();
check(errors.length === 0, `no page errors${errors.length ? `: ${errors.join(" | ")}` : ""}`);
await browser.close();
console.log(state.failures ? `\n${state.failures} FAILURE(S)` : "\nPHASE 4 FLOW PASSED");
process.exit(state.failures ? 1 : 0);
