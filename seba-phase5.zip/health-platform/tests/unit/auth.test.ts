import { describe, expect, it } from "vitest";
import { displayMaskedPhone, normalizeIndianMobile } from "@/server/auth/phone";
import { safeNext } from "@/server/auth/session";
import { hashOtp } from "@/server/auth/otp";
import { parsePerson } from "@/server/patients";
import { parseSearchParams } from "@/server/directory";

describe("phone numbers", () => {
  it("accepts the ways people type Indian mobiles", () => {
    for (const input of ["9812345678", "98123 45678", "098123-45678", "+91 98123 45678", "919812345678", "(981) 234-5678"]) {
      expect(normalizeIndianMobile(input), input).toBe("+919812345678");
    }
  });
  it("rejects landlines, short numbers and junk", () => {
    for (const input of ["5812345678", "981234567", "98123456789", "+1 9812345678", "abcdefghij", ""]) {
      expect(normalizeIndianMobile(input), input).toBeNull();
    }
  });
  it("masks for display", () => {
    expect(displayMaskedPhone("+919812345678")).toBe("+91 98•••••678");
  });
});

describe("post-login redirect", () => {
  it("only allows paths inside the app", () => {
    expect(safeNext("/bn/doctors", "bn")).toBe("/bn/doctors");
    expect(safeNext("/en/doctors?speciality=ent", "en")).toBe("/en/doctors?speciality=ent");
    for (const bad of ["https://evil.example", "//evil.example", "/\\evil", "javascript:alert(1)", "/xx/doctors", "", null]) {
      expect(safeNext(bad as string, "bn"), String(bad)).toBe("/bn/profile");
    }
  });
});

describe("OTP hashing", () => {
  it("binds the code to the number and the secret", () => {
    const a = hashOtp("s", "+919812345678", "123456");
    expect(a).toMatch(/^[0-9a-f]{64}$/);
    expect(hashOtp("s", "+919812345679", "123456")).not.toBe(a);
    expect(hashOtp("t", "+919812345678", "123456")).not.toBe(a);
    expect(hashOtp("s", "+919812345678", "123457")).not.toBe(a);
  });
});

describe("person form validation", () => {
  const fd = (o: Record<string, string>) => {
    const f = new FormData();
    for (const [k, v] of Object.entries(o)) f.set(k, v);
    return f;
  };
  it("accepts Bengali and English names, optional fields empty", () => {
    expect(parsePerson(fd({ fullName: "রহিমা খাতুন" })).success).toBe(true);
    expect(parsePerson(fd({ fullName: "Md. Rahim O'Neil-Sk", sex: "male", dateOfBirth: "1990-05-01" })).success).toBe(true);
  });
  it("rejects bad names and dates", () => {
    expect(parsePerson(fd({ fullName: "A" })).success).toBe(false);
    expect(parsePerson(fd({ fullName: "<script>" })).success).toBe(false);
    expect(parsePerson(fd({ fullName: "Rahim 123" })).success).toBe(false);
    expect(parsePerson(fd({ fullName: "Rahim", dateOfBirth: "2999-01-01" })).success).toBe(false);
    expect(parsePerson(fd({ fullName: "Rahim", dateOfBirth: "1850-01-01" })).success).toBe(false);
    expect(parsePerson(fd({ fullName: "Rahim", sex: "x" })).success).toBe(false);
  });
});

describe("search parameters", () => {
  it("keeps valid filters and drops bad ones", () => {
    expect(parseSearchParams({ q: " skin ", speciality: "dermatology", town: "malda", maxFee: "500", available: "1" })).toEqual({
      q: "skin", speciality: "dermatology", town: "malda", maxFee: 500, available: true,
    });
    expect(parseSearchParams({ speciality: "'; drop table--" })).toEqual({ q: "", available: false });
    expect(parseSearchParams({ maxFee: "-5" })).toEqual({ q: "", available: false });
  });
});
