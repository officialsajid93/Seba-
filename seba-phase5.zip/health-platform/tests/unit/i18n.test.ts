import { describe, expect, it } from "vitest";
import { format, isActiveLocale, negotiateLocale, switchLocalePath } from "@/i18n/config";
import en from "@/i18n/dictionaries/en.json";
import bn from "@/i18n/dictionaries/bn.json";

const keys = (o: object, p = ""): string[] =>
  Object.entries(o).flatMap(([k, v]) => (v && typeof v === "object" ? keys(v, `${p}${k}.`) : [`${p}${k}`]));
const get = (o: unknown, k: string) => k.split(".").reduce<unknown>((x, s) => (x as Record<string, unknown>)?.[s], o);

describe("dictionaries", () => {
  it("Bengali has exactly the same keys as English", () => {
    expect(keys(bn).sort()).toEqual(keys(en).sort());
  });

  it("no string is empty", () => {
    for (const k of keys(en)) {
      expect(String(get(en, k)).trim(), `en.${k}`).not.toBe("");
      expect(String(get(bn, k)).trim(), `bn.${k}`).not.toBe("");
    }
  });

  it("placeholders match between languages", () => {
    const ph = (s: string) => (s.match(/\{\w+\}/g) ?? []).sort();
    for (const k of keys(en)) expect(ph(String(get(bn, k))), k).toEqual(ph(String(get(en, k))));
  });

  it("Bengali strings are actually in Bengali script (brand words and SMS aside)", () => {
    const allowedLatin = new Set(["lang.switchTo"]);
    for (const k of keys(bn)) {
      if (allowedLatin.has(k)) continue;
      expect(/[ঀ-৿]/.test(String(get(bn, k))), `bn.${k} has no Bengali text`).toBe(true);
    }
  });
});

describe("locale helpers", () => {
  it("defaults to Bengali", () => {
    expect(negotiateLocale(undefined)).toBe("bn");
    expect(negotiateLocale("fr-FR,fr;q=0.9")).toBe("bn");
  });
  it("respects browser preference order and weights", () => {
    expect(negotiateLocale("en-IN,en;q=0.9,bn;q=0.8")).toBe("en");
    expect(negotiateLocale("hi-IN;q=0.9,bn-IN;q=0.8,en;q=0.5")).toBe("bn"); // hi not active yet
    expect(negotiateLocale("en;q=0.2,bn;q=0.9")).toBe("bn");
  });
  it("switches the locale prefix of a path", () => {
    expect(switchLocalePath("/en/doctors", "bn")).toBe("/bn/doctors");
    expect(switchLocalePath("/bn", "en")).toBe("/en");
    expect(switchLocalePath("/doctors", "en")).toBe("/en/doctors");
    expect(switchLocalePath("/hi/x", "bn")).toBe("/bn/x");
  });
  it("only accepts active locales", () => {
    expect(isActiveLocale("bn")).toBe(true);
    expect(isActiveLocale("hi")).toBe(false);
    expect(isActiveLocale("../etc")).toBe(false);
  });
  it("fills placeholders and leaves unknown ones", () => {
    expect(format("আর {count}টি সিট বাকি", { count: 3 })).toBe("আর 3টি সিট বাকি");
    expect(format("{a} {b}", { a: 1 })).toBe("1 {b}");
  });
});
