import { describe, expect, it } from "vitest";
import { parseEnv } from "@/lib/env-schema";

const base = {
  DATABASE_URL: "postgresql://localhost/health",
  SESSION_SECRET: "x".repeat(40),
};

describe("environment validation", () => {
  it("defaults every outside service to dev mode", () => {
    const e = parseEnv({ ...base });
    expect([e.SMS_PROVIDER, e.PAYMENT_PROVIDER, e.STORAGE_DRIVER]).toEqual(["dev", "dev", "dev-local"]);
  });

  it("rejects a short session secret", () => {
    expect(() => parseEnv({ ...base, SESSION_SECRET: "short" })).toThrow(/SESSION_SECRET/);
  });

  it("refuses dev adapters in production", () => {
    expect(() => parseEnv({ ...base, NODE_ENV: "production" })).toThrow(/dev adapter and is not allowed in production/);
  });

  it("allows dev adapters in production only with the explicit staging flag", () => {
    expect(() => parseEnv({ ...base, NODE_ENV: "production", ALLOW_DEV_ADAPTERS_IN_PRODUCTION: "true" })).not.toThrow();
  });

  it("requires keys when a real provider is chosen", () => {
    expect(() => parseEnv({ ...base, PAYMENT_PROVIDER: "razorpay" })).toThrow(/RAZORPAY_KEY_SECRET is required/);
    expect(() => parseEnv({ ...base, SMS_PROVIDER: "msg91" })).toThrow(/MSG91_AUTH_KEY is required/);
  });
});
