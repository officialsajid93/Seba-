import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

// Reads the real design tokens and checks every text/background pair the UI
// uses against WCAG AA (4.5:1 for normal text).
const css = readFileSync(path.resolve(__dirname, "../../src/app/globals.css"), "utf8");
const token = (name: string) => {
  const m = css.match(new RegExp(`--color-${name}:\\s*(#[0-9a-fA-F]{6})`));
  if (!m) throw new Error(`token ${name} not found`);
  return m[1];
};
const lum = (hex: string) => {
  const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((c) =>
    c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4,
  );
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
};
const ratio = (a: string, b: string) => {
  const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
};

const pairs: [fg: string, bg: string][] = [
  ["ink", "surface"], ["muted", "surface"], ["subtle", "surface"], ["muted", "canvas"], ["subtle", "canvas"],
  ["brand-600", "surface"], ["brand-700", "surface"], ["brand-700", "brand-50"], ["teal-700", "surface"], ["teal-700", "teal-50"],
  ["ok-700", "ok-50"], ["warn-700", "warn-50"], ["bad-700", "bad-50"], ["info-700", "info-50"],
  ["surface", "brand-600"], ["surface", "bad-700"],
];

describe("colour contrast (WCAG AA)", () => {
  for (const [fg, bg] of pairs) {
    it(`${fg} on ${bg}`, () => {
      expect(ratio(token(fg), token(bg))).toBeGreaterThanOrEqual(4.5);
    });
  }
});
