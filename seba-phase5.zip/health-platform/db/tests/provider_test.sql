-- Phase 5 database tests: staff bookings, visit queue, schedule confirmation,
-- running late, rebuilding sittings after a schedule edit. Rolls back.
BEGIN;

CREATE FUNCTION pg_temp.expect_error(stmt text, expected text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE stmt;
  RAISE EXCEPTION 'expected error "%" but statement succeeded: %', expected, stmt;
EXCEPTION WHEN OTHERS THEN
  IF SQLERRM NOT LIKE '%' || expected || '%' THEN RAISE EXCEPTION 'expected error "%" but got "%"', expected, SQLERRM; END IF;
END $$;
CREATE FUNCTION pg_temp.ok(cond boolean, label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF NOT coalesce(cond, false) THEN RAISE EXCEPTION 'FAILED: %', label; END IF; RAISE NOTICE 'ok - %', label; END $$;

INSERT INTO localities (id, slug, name_en, district) VALUES ('c1000000-0000-4000-8000-000000000001', 'pv-town', 'PV Town', 'PV District');
INSERT INTO users (id, phone_e164) VALUES ('c2000000-0000-4000-8000-000000000001', '+916200000001'),   -- patient family phone
                                          ('c2000000-0000-4000-8000-000000000009', '+916200000009');   -- staff
INSERT INTO patients (account_user_id, relation, full_name)
SELECT 'c2000000-0000-4000-8000-000000000001', CASE WHEN g = 1 THEN 'self' ELSE 'other' END, 'Family ' || g FROM generate_series(1, 7) g;
INSERT INTO doctors (id, full_name, registration_number, registration_council, verification_status, verified_at, verified_by)
VALUES ('c4000000-0000-4000-8000-000000000001', 'Dr PV', 'PV-1', 'PV Council', 'verified', now(), 'c2000000-0000-4000-8000-000000000009');
INSERT INTO facilities (id, type, name, address_line, locality_id, verification_status, is_published)
VALUES ('c5000000-0000-4000-8000-000000000001', 'chamber', 'PV Chamber', 'x', 'c1000000-0000-4000-8000-000000000001', 'verified', true);
INSERT INTO doctor_practices (id, doctor_id, facility_id, consultation_fee_paise, schedule_state)
VALUES ('c6000000-0000-4000-8000-000000000001', 'c4000000-0000-4000-8000-000000000001', 'c5000000-0000-4000-8000-000000000001', 20000, 'unverified');
INSERT INTO schedule_templates (id, practice_id, weekday, start_time, end_time, capacity)
SELECT ('c7000000-0000-4000-8000-00000000000' || g)::uuid, 'c6000000-0000-4000-8000-000000000001', g, '17:00', '20:00', 30 FROM generate_series(0, 6) g;
SELECT generate_sessions((now() AT TIME ZONE 'Asia/Kolkata')::date + 1, 14, 'c6000000-0000-4000-8000-000000000001') \gset

DO $$
DECLARE s uuid; s2 uuid; p uuid[]; a appointments; i int;
BEGIN
  SELECT array_agg(id ORDER BY full_name) INTO p FROM patients WHERE account_user_id = 'c2000000-0000-4000-8000-000000000001';
  SELECT id INTO s FROM consultation_sessions WHERE practice_id = 'c6000000-0000-4000-8000-000000000001' ORDER BY starts_at LIMIT 1;
  SELECT id INTO s2 FROM consultation_sessions WHERE practice_id = 'c6000000-0000-4000-8000-000000000001' ORDER BY starts_at OFFSET 1 LIMIT 1;

  -- Patients cannot book an unconfirmed schedule online, but the chamber itself can take phone bookings.
  PERFORM pg_temp.expect_error(format($q$ SELECT book_appointment(%L, %L, 'c2000000-0000-4000-8000-000000000001') $q$, s, p[1]), 'SESSION_NOT_BOOKABLE');
  FOR i IN 1..7 LOOP
    PERFORM book_by_staff(s, p[i], 'c2000000-0000-4000-8000-000000000001', 'c2000000-0000-4000-8000-000000000009');
  END LOOP;
  PERFORM pg_temp.ok((SELECT active_count FROM consultation_sessions WHERE id = s) = 7, 'staff can book a whole family from one phone (no 5-booking cap)');
  PERFORM pg_temp.ok((SELECT count(*) FROM appointment_events e JOIN appointments ap ON ap.id = e.appointment_id
                       WHERE ap.session_id = s AND e.note = 'booked by clinic' AND e.actor_user_id = 'c2000000-0000-4000-8000-000000000009') = 7,
                     'each staff booking records which staff member made it');

  -- After online booking closes, staff can still add a walk-in.
  UPDATE consultation_sessions SET booking_closes_at = now() - interval '5 minutes' WHERE id = s2;
  a := book_by_staff(s2, p[1], 'c2000000-0000-4000-8000-000000000001', 'c2000000-0000-4000-8000-000000000009');
  PERFORM pg_temp.ok(a.token_number = 1, 'walk-in added after online booking closed');
  UPDATE consultation_sessions SET capacity = 1 WHERE id = s2;
  PERFORM pg_temp.expect_error(format($q$ SELECT book_by_staff(%L, %L, 'c2000000-0000-4000-8000-000000000001', 'c2000000-0000-4000-8000-000000000009') $q$, s2, p[2]),
                               'SESSION_FULL');
  PERFORM pg_temp.ok(true, 'staff cannot overbook either');

  -- Visit queue
  SELECT * INTO a FROM appointments WHERE session_id = s AND token_number = 1;
  PERFORM pg_temp.expect_error(format($q$ SELECT set_visit_status(%L, 'checked_in', 'c2000000-0000-4000-8000-000000000009') $q$, a.id), 'TOO_EARLY');
  UPDATE consultation_sessions SET session_date = (now() AT TIME ZONE 'Asia/Kolkata')::date WHERE id = s;   -- pretend it is today
  PERFORM set_visit_status(a.id, 'checked_in', 'c2000000-0000-4000-8000-000000000009');
  PERFORM set_visit_status(a.id, 'completed', 'c2000000-0000-4000-8000-000000000009');
  PERFORM pg_temp.expect_error(format($q$ SELECT set_visit_status(%L, 'checked_in', 'c2000000-0000-4000-8000-000000000009') $q$, a.id), 'INVALID_TRANSITION');
  SELECT * INTO a FROM appointments WHERE session_id = s AND token_number = 2;
  PERFORM set_visit_status(a.id, 'no_show', 'c2000000-0000-4000-8000-000000000009');
  PERFORM set_visit_status(a.id, 'checked_in', 'c2000000-0000-4000-8000-000000000009');
  PERFORM pg_temp.ok((SELECT status FROM appointments WHERE id = a.id) = 'checked_in', 'a patient marked absent can still be checked in if they arrive late');
  PERFORM pg_temp.expect_error(format($q$ SELECT set_visit_status(%L, 'cancelled_by_patient', 'c2000000-0000-4000-8000-000000000009') $q$, a.id), 'INVALID_TRANSITION');
  PERFORM pg_temp.ok(true, 'queue only allows check-in, done and absent moves');

  -- One-tap schedule confirmation makes the doctor bookable online.
  PERFORM confirm_schedule('c6000000-0000-4000-8000-000000000001', 'c2000000-0000-4000-8000-000000000009');
  PERFORM pg_temp.ok(EXISTS (SELECT 1 FROM bookable_sessions WHERE practice_id = 'c6000000-0000-4000-8000-000000000001'),
                     'confirming the schedule opens online booking');

  -- Running late
  PERFORM set_running_late(s, true, '45 minutes late', 'c2000000-0000-4000-8000-000000000009');
  PERFORM pg_temp.ok((SELECT status = 'running_late' AND public_note = '45 minutes late' FROM consultation_sessions WHERE id = s), 'sitting marked running late with a note');
  PERFORM set_running_late(s, false, NULL, 'c2000000-0000-4000-8000-000000000009');
  PERFORM pg_temp.ok((SELECT status = 'scheduled' AND public_note IS NULL FROM consultation_sessions WHERE id = s), 'running late cleared');
END $$;

-- Rebuild after a schedule edit: unbooked sittings move to the new time; booked ones stay and are counted.
DO $$
DECLARE r record; booked_day date; total_before int;
BEGIN
  SELECT count(*) INTO total_before FROM consultation_sessions WHERE practice_id = 'c6000000-0000-4000-8000-000000000001' AND starts_at > now();
  SELECT session_date INTO booked_day FROM consultation_sessions
   WHERE practice_id = 'c6000000-0000-4000-8000-000000000001' AND active_count > 0 AND starts_at > now() ORDER BY starts_at LIMIT 1;
  UPDATE schedule_templates SET start_time = '18:00', end_time = '21:00' WHERE practice_id = 'c6000000-0000-4000-8000-000000000001';
  SELECT * INTO r FROM rebuild_future_sessions('c6000000-0000-4000-8000-000000000001');
  PERFORM pg_temp.ok(r.removed > 0 AND r.created > 0, format('unbooked sittings replaced (%s removed, %s created)', r.removed, r.created));
  PERFORM pg_temp.ok(r.kept_with_bookings >= 1, format('%s booked sitting(s) kept and flagged for the clinic', r.kept_with_bookings));
  PERFORM pg_temp.ok(NOT EXISTS (SELECT 1 FROM consultation_sessions
                                  WHERE practice_id = 'c6000000-0000-4000-8000-000000000001' AND starts_at > now() AND active_count = 0
                                    AND to_char(starts_at AT TIME ZONE 'Asia/Kolkata', 'HH24:MI') = '17:00'),
                     'no unbooked sitting is left at the old time');
  PERFORM pg_temp.ok(EXISTS (SELECT 1 FROM consultation_sessions
                              WHERE practice_id = 'c6000000-0000-4000-8000-000000000001' AND session_date = booked_day
                                AND to_char(starts_at AT TIME ZONE 'Asia/Kolkata', 'HH24:MI') = '17:00' AND active_count > 0),
                     'the booked sitting keeps its time and patients');
  -- Deleting a template keeps past sittings' history.
  DELETE FROM schedule_templates WHERE practice_id = 'c6000000-0000-4000-8000-000000000001' AND weekday = 0;
  PERFORM pg_temp.ok(true, 'a template can be deleted without breaking existing sittings');
END $$;

DO $$ BEGIN RAISE NOTICE 'ALL PROVIDER TESTS PASSED'; END $$;
ROLLBACK;
