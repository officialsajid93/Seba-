#!/usr/bin/env bash
# Race test: N patients on separate connections book a session with C seats at the same instant.
# Expect exactly C successes, C distinct tokens, active_count = C, and no overbooking.
# Usage: DATABASE_URL=postgres://... bash db/tests/concurrency_test.sh [N] [C]
set -euo pipefail
N=${1:-40}; C=${2:-10}
PSQL="psql ${DATABASE_URL:?set DATABASE_URL} -v ON_ERROR_STOP=1 -qAt"

$PSQL <<SQL
BEGIN;
DELETE FROM appointment_events; DELETE FROM appointments; DELETE FROM consultation_sessions;
DELETE FROM doctor_practices; DELETE FROM patients; DELETE FROM user_roles; DELETE FROM doctors;
DELETE FROM facilities; DELETE FROM users; DELETE FROM localities;
INSERT INTO localities (id, name_en, district) VALUES ('10000000-0000-0000-0000-000000000001','Jangipur','Murshidabad');
INSERT INTO users (id, phone_e164) VALUES ('20000000-0000-0000-0000-000000000099','+919800000099');
INSERT INTO doctors (id, full_name, registration_number, registration_council, verification_status, verified_at, verified_by)
VALUES ('40000000-0000-0000-0000-000000000001','Dr Race','R-1','WBMC','verified',now(),'20000000-0000-0000-0000-000000000099');
INSERT INTO facilities (id, type, name, address_line, locality_id, verification_status, is_published)
VALUES ('50000000-0000-0000-0000-000000000001','clinic','Race Clinic','x','10000000-0000-0000-0000-000000000001','verified',true);
INSERT INTO doctor_practices (id, doctor_id, facility_id, consultation_fee_paise, schedule_state, schedule_confirmed_at, schedule_confirmed_by)
VALUES ('60000000-0000-0000-0000-000000000001','40000000-0000-0000-0000-000000000001','50000000-0000-0000-0000-000000000001',
        20000,'confirmed',now(),'20000000-0000-0000-0000-000000000099');
INSERT INTO consultation_sessions (id, practice_id, session_date, starts_at, ends_at, booking_mode, capacity)
VALUES ('70000000-0000-0000-0000-000000000001','60000000-0000-0000-0000-000000000001', current_date+1,
        (current_date+1)+time '17:00', (current_date+1)+time '20:00','serial_token', $C);
INSERT INTO users (id, phone_e164)
SELECT ('21000000-0000-0000-0000-' || lpad(g::text,12,'0'))::uuid, '+9197000' || lpad(g::text,5,'0') FROM generate_series(1,$N) g;
INSERT INTO patients (id, account_user_id, full_name)
SELECT ('31000000-0000-0000-0000-' || lpad(g::text,12,'0'))::uuid, ('21000000-0000-0000-0000-' || lpad(g::text,12,'0'))::uuid, 'P'||g
FROM generate_series(1,$N) g;
COMMIT;
SQL

OUT=$(mktemp -d)
for i in $(seq 1 "$N"); do
  id=$(printf '%012d' "$i")
  ( psql "$DATABASE_URL" -qAt -c "SELECT token_number FROM book_appointment('70000000-0000-0000-0000-000000000001','31000000-0000-0000-0000-$id','21000000-0000-0000-0000-$id')" \
      >"$OUT/$i.out" 2>"$OUT/$i.err" || true ) &
done
wait

ok=$(cat "$OUT"/*.out | grep -c . || true)
full=$(cat "$OUT"/*.err | grep -c SESSION_FULL || true)
other=$(cat "$OUT"/*.err | grep -v SESSION_FULL | grep -c ERROR || true)
distinct=$(cat "$OUT"/*.out | sort -u | grep -c . || true)
active=$($PSQL -c "SELECT active_count FROM consultation_sessions WHERE id='70000000-0000-0000-0000-000000000001'")
rows=$($PSQL -c "SELECT count(*) FROM appointments WHERE status='confirmed'")

echo "attempts=$N capacity=$C booked=$ok rejected_full=$full other_errors=$other distinct_tokens=$distinct active_count=$active appointment_rows=$rows"
[[ $ok -eq $C && $distinct -eq $C && $active -eq $C && $rows -eq $C && $full -eq $((N-C)) && $other -eq 0 ]] \
  && echo "CONCURRENCY TEST PASSED" || { echo "CONCURRENCY TEST FAILED"; exit 1; }
