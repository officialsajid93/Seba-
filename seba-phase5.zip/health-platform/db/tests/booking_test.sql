-- Phase 4 database tests: sitting generation, exceptions, booking cap,
-- cancellation window, ownership, waiting list. Runs in a transaction and
-- rolls back.   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/tests/booking_test.sql
BEGIN;

CREATE FUNCTION pg_temp.expect_error(stmt text, expected text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE stmt;
  RAISE EXCEPTION 'expected error "%" but statement succeeded: %', expected, stmt;
EXCEPTION WHEN OTHERS THEN
  IF SQLERRM NOT LIKE '%' || expected || '%' THEN RAISE EXCEPTION 'expected error "%" but got "%"', expected, SQLERRM; END IF;
END $$;
CREATE FUNCTION pg_temp.ok(cond boolean, label text) RETURNS void LANGUAGE plpgsql AS $$
BEGIN IF NOT coalesce(cond, false) THEN RAISE EXCEPTION 'FAILED: %', label; END IF; RAISE NOTICE 'ok - %', label; END $$;

-- ---------- seed ----------
INSERT INTO localities (id, slug, name_en, district) VALUES ('b1000000-0000-4000-8000-000000000001', 'bk-town', 'BK Town', 'BK District');
INSERT INTO users (id, phone_e164) VALUES
  ('b2000000-0000-4000-8000-000000000001', '+916100000001'),
  ('b2000000-0000-4000-8000-000000000002', '+916100000002'),
  ('b2000000-0000-4000-8000-000000000009', '+916100000009');
INSERT INTO patients (id, account_user_id, relation, full_name) VALUES
  ('b3000000-0000-4000-8000-000000000001', 'b2000000-0000-4000-8000-000000000001', 'self', 'Booker One'),
  ('b3000000-0000-4000-8000-000000000002', 'b2000000-0000-4000-8000-000000000002', 'self', 'Booker Two');
INSERT INTO patients (account_user_id, relation, full_name)
SELECT 'b2000000-0000-4000-8000-000000000001', 'child', 'Kid ' || g FROM generate_series(1, 6) g;

INSERT INTO doctors (id, full_name, registration_number, registration_council, verification_status, verified_at, verified_by)
VALUES ('b4000000-0000-4000-8000-000000000001', 'Dr BK', 'BK-1', 'BK Council', 'verified', now(), 'b2000000-0000-4000-8000-000000000009');
INSERT INTO facilities (id, type, name, address_line, locality_id, verification_status, is_published) VALUES
  ('b5000000-0000-4000-8000-000000000001', 'chamber', 'BK Chamber', 'x', 'b1000000-0000-4000-8000-000000000001', 'verified', true),
  ('b5000000-0000-4000-8000-000000000002', 'clinic',  'BK Clinic',  'x', 'b1000000-0000-4000-8000-000000000001', 'verified', true),
  ('b5000000-0000-4000-8000-000000000003', 'clinic',  'BK Annexe',  'x', 'b1000000-0000-4000-8000-000000000001', 'verified', true);
INSERT INTO doctor_practices (id, doctor_id, facility_id, consultation_fee_paise, booking_mode, schedule_state, schedule_confirmed_at, schedule_confirmed_by) VALUES
  ('b6000000-0000-4000-8000-000000000001', 'b4000000-0000-4000-8000-000000000001', 'b5000000-0000-4000-8000-000000000001', 20000, 'serial_token', 'confirmed', now(), 'b2000000-0000-4000-8000-000000000009'),
  ('b6000000-0000-4000-8000-000000000002', 'b4000000-0000-4000-8000-000000000001', 'b5000000-0000-4000-8000-000000000002', 30000, 'time_slot',    'confirmed', now(), 'b2000000-0000-4000-8000-000000000009');

-- Templates: chamber every Mon + Thu 17-20 (30 seats); clinic every day 10-12 in 15-min slots (asks for 50 seats).
INSERT INTO schedule_templates (id, practice_id, weekday, start_time, end_time, capacity, slot_minutes) VALUES
  ('b7000000-0000-4000-8000-000000000001', 'b6000000-0000-4000-8000-000000000001', 1, '17:00', '20:00', 30, NULL),
  ('b7000000-0000-4000-8000-000000000002', 'b6000000-0000-4000-8000-000000000001', 4, '17:00', '20:00', 30, NULL);
INSERT INTO schedule_templates (practice_id, weekday, start_time, end_time, capacity, slot_minutes)
SELECT 'b6000000-0000-4000-8000-000000000002', g, '10:00', '12:00', 50, 15 FROM generate_series(0, 6) g;

-- ---------- generation ----------
DO $$
DECLARE made int; expect_chamber int; d0 date := (now() AT TIME ZONE 'Asia/Kolkata')::date + 1;
BEGIN
  made := generate_sessions(d0, 14, 'b6000000-0000-4000-8000-000000000001') + generate_sessions(d0, 14, 'b6000000-0000-4000-8000-000000000002');
  SELECT count(*) INTO expect_chamber FROM generate_series(d0, d0 + 13, interval '1 day') d WHERE extract(dow FROM d) IN (1, 4);
  PERFORM pg_temp.ok((SELECT count(*) FROM consultation_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000001') = expect_chamber,
                     'chamber gets exactly one sitting per Monday and Thursday');
  PERFORM pg_temp.ok((SELECT count(*) FROM consultation_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000002') = 14,
                     'clinic gets one sitting per day');
  PERFORM pg_temp.ok(made = expect_chamber + 14, 'generator reports how many it created');
  PERFORM pg_temp.ok(generate_sessions(d0, 14, 'b6000000-0000-4000-8000-000000000001') = 0
                     AND generate_sessions(d0, 14, 'b6000000-0000-4000-8000-000000000002') = 0, 'running the generator again creates nothing (idempotent)');
  PERFORM pg_temp.ok((SELECT bool_and(capacity = 8) FROM consultation_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000002'),
                     'time-slot capacity is capped at the number of slots (2 h / 15 min = 8)');
  PERFORM pg_temp.ok((SELECT bool_and(to_char(starts_at AT TIME ZONE 'Asia/Kolkata', 'HH24:MI') = '17:00'
                                     AND booking_closes_at = starts_at - interval '30 minutes')
                        FROM consultation_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000001'),
                     'sittings start at 5 pm India time and booking closes 30 minutes before');
END $$;

-- week_of_month and effective_to
DO $$
-- Window = first 10 days of next month, so weeks 1 and 2 are both inside it.
DECLARE d0 date := (date_trunc('month', now() AT TIME ZONE 'Asia/Kolkata') + interval '1 month')::date; n int; expect int;
BEGIN
  INSERT INTO doctor_practices (id, doctor_id, facility_id, consultation_fee_paise, schedule_state, schedule_confirmed_at, schedule_confirmed_by)
  VALUES ('b6000000-0000-4000-8000-000000000003', 'b4000000-0000-4000-8000-000000000001',
          'b5000000-0000-4000-8000-000000000003', 10000, 'confirmed', now(), 'b2000000-0000-4000-8000-000000000009');
  -- every day, but only in the 1st and 3rd week of the month, and only for 10 days
  INSERT INTO schedule_templates (practice_id, weekday, start_time, end_time, capacity, week_of_month, effective_from, effective_to)
  SELECT 'b6000000-0000-4000-8000-000000000003', g, '08:00', '09:00', 10, ARRAY[1, 3]::smallint[], d0, d0 + 9 FROM generate_series(0, 6) g;
  PERFORM generate_sessions(d0, 30, 'b6000000-0000-4000-8000-000000000003');
  SELECT count(*) INTO n FROM consultation_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000003';
  SELECT count(*) INTO expect FROM generate_series(d0, d0 + 9, interval '1 day') d WHERE ((extract(day FROM d)::int - 1) / 7 + 1) IN (1, 3);
  PERFORM pg_temp.ok(expect = 7 AND n = 7, format('1st/3rd-week rule and end date respected (%s of 10 days, all in week 1)', n));
END $$;

-- ---------- exceptions: leave suppresses, time change moves, extra adds ----------
DO $$
DECLARE d0 date := (now() AT TIME ZONE 'Asia/Kolkata')::date + 20; mon date; thu date; sat date;
BEGIN
  SELECT d INTO sat FROM generate_series(d0, d0 + 6, interval '1 day') d WHERE extract(dow FROM d) = 6;
  SELECT d INTO mon FROM generate_series(d0, d0 + 6, interval '1 day') d WHERE extract(dow FROM d) = 1;
  SELECT d INTO thu FROM generate_series(d0, d0 + 6, interval '1 day') d WHERE extract(dow FROM d) = 4;
  INSERT INTO schedule_exceptions (doctor_id, practice_id, kind, starts_on, ends_on, created_by)
  VALUES ('b4000000-0000-4000-8000-000000000001', NULL, 'leave', mon, mon, 'b2000000-0000-4000-8000-000000000009');
  INSERT INTO schedule_exceptions (doctor_id, practice_id, kind, starts_on, ends_on, new_start_time, new_end_time, created_by)
  VALUES ('b4000000-0000-4000-8000-000000000001', 'b6000000-0000-4000-8000-000000000001', 'time_change', thu, thu, '18:30', '21:00',
          'b2000000-0000-4000-8000-000000000009');
  INSERT INTO schedule_exceptions (doctor_id, practice_id, kind, starts_on, ends_on, new_start_time, new_end_time, capacity, created_by)
  VALUES ('b4000000-0000-4000-8000-000000000001', 'b6000000-0000-4000-8000-000000000001', 'extra_session', sat, sat, '09:00', '11:00', 15,
          'b2000000-0000-4000-8000-000000000009');
  PERFORM generate_sessions(d0, 7);
  PERFORM pg_temp.ok(NOT EXISTS (SELECT 1 FROM consultation_sessions cs JOIN doctor_practices dp ON dp.id = cs.practice_id
                                  WHERE dp.doctor_id = 'b4000000-0000-4000-8000-000000000001' AND cs.session_date = mon),
                     'doctor leave (all practices) suppresses every sitting that day');
  PERFORM pg_temp.ok((SELECT to_char(starts_at AT TIME ZONE 'Asia/Kolkata', 'HH24:MI') FROM consultation_sessions
                       WHERE practice_id = 'b6000000-0000-4000-8000-000000000001' AND session_date = thu) = '18:30',
                     'time change moves that day''s sitting');
  PERFORM pg_temp.ok((SELECT capacity FROM consultation_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000001'
                       AND session_date = sat AND to_char(starts_at AT TIME ZONE 'Asia/Kolkata', 'HH24:MI') = '09:00') = 15,
                     'extra sitting is created with its own size');
END $$;

-- ---------- applying leave to sittings that already have bookings ----------
DO $$
DECLARE s uuid; ex uuid; affected uuid[]; a1 appointments; a2 appointments;
BEGIN
  SELECT id INTO s FROM consultation_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000001' ORDER BY starts_at LIMIT 1;
  a1 := book_appointment(s, 'b3000000-0000-4000-8000-000000000001', 'b2000000-0000-4000-8000-000000000001');
  a2 := book_appointment(s, 'b3000000-0000-4000-8000-000000000002', 'b2000000-0000-4000-8000-000000000002');
  INSERT INTO schedule_exceptions (doctor_id, kind, starts_on, ends_on, reason_public, created_by)
  SELECT 'b4000000-0000-4000-8000-000000000001', 'leave', session_date, session_date, 'Emergency', 'b2000000-0000-4000-8000-000000000009'
    FROM consultation_sessions WHERE id = s RETURNING id INTO ex;
  SELECT array_agg(x) INTO affected FROM apply_schedule_exception(ex, 'b2000000-0000-4000-8000-000000000009') x;
  PERFORM pg_temp.ok(affected @> ARRAY[a1.id, a2.id] AND cardinality(affected) >= 2, 'leave returns every booked patient for SMS');
  PERFORM pg_temp.ok((SELECT status FROM consultation_sessions WHERE id = s) = 'cancelled', 'the sitting is cancelled');
  PERFORM pg_temp.ok((SELECT bool_and(status = 'cancelled_by_provider') FROM appointments WHERE id IN (a1.id, a2.id)), 'both bookings cancelled by provider');
  -- clean up so the booking cap test starts from zero
  DELETE FROM appointment_events WHERE appointment_id IN (a1.id, a2.id);
  DELETE FROM appointments WHERE id IN (a1.id, a2.id);
END $$;

-- ---------- time change on a time-slot sitting with bookings ----------
DO $$
DECLARE s consultation_sessions; ex uuid; a1 appointments; a2 appointments; affected uuid[];
BEGIN
  SELECT * INTO s FROM consultation_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000002' AND status = 'scheduled'
   ORDER BY starts_at LIMIT 1;
  a1 := book_appointment(s.id, 'b3000000-0000-4000-8000-000000000001', 'b2000000-0000-4000-8000-000000000001', s.starts_at);                       -- 10:00
  a2 := book_appointment(s.id, 'b3000000-0000-4000-8000-000000000002', 'b2000000-0000-4000-8000-000000000002', s.starts_at + interval '105 minutes'); -- 11:45
  -- Sitting moves to 10:30-12:00: everyone shifts 30 min; the 11:45 slot would end at 12:30, so it is cancelled.
  INSERT INTO schedule_exceptions (doctor_id, practice_id, kind, starts_on, ends_on, new_start_time, new_end_time, created_by)
  VALUES ('b4000000-0000-4000-8000-000000000001', s.practice_id, 'time_change', s.session_date, s.session_date, '10:30', '12:00',
          'b2000000-0000-4000-8000-000000000009') RETURNING id INTO ex;
  SELECT array_agg(x) INTO affected FROM apply_schedule_exception(ex, 'b2000000-0000-4000-8000-000000000009') x;
  PERFORM pg_temp.ok(affected @> ARRAY[a1.id, a2.id], 'time change reports both patients');
  PERFORM pg_temp.ok((SELECT slot_starts_at FROM appointments WHERE id = a1.id) = s.starts_at + interval '30 minutes', 'first booking moved by 30 minutes');
  PERFORM pg_temp.ok((SELECT status FROM appointments WHERE id = a2.id) = 'cancelled_by_provider', 'booking that no longer fits is cancelled');
  PERFORM pg_temp.ok((SELECT active_count FROM consultation_sessions WHERE id = s.id) = 1, 'seat count stays correct');
  DELETE FROM appointment_events WHERE appointment_id IN (a1.id, a2.id);
  DELETE FROM appointments WHERE id IN (a1.id, a2.id);
  UPDATE consultation_sessions SET active_count = 0 WHERE id = s.id;
END $$;

-- ---------- booking cap, ownership, cancel window, waiting list ----------
DO $$
DECLARE sessions uuid[]; p uuid[]; i int; a appointments; w waitlist_entries;
BEGIN
  SELECT array_agg(id ORDER BY starts_at) INTO sessions FROM bookable_sessions WHERE practice_id = 'b6000000-0000-4000-8000-000000000001';
  PERFORM pg_temp.ok(cardinality(sessions) >= 2, 'at least two open chamber sittings to test with');
  SELECT array_agg(id ORDER BY created_at, id) INTO p FROM patients WHERE account_user_id = 'b2000000-0000-4000-8000-000000000001';
  FOR i IN 1..5 LOOP
    PERFORM book_appointment(sessions[1], p[i], 'b2000000-0000-4000-8000-000000000001');
  END LOOP;
  PERFORM pg_temp.expect_error(format($q$ SELECT book_appointment(%L, %L, 'b2000000-0000-4000-8000-000000000001') $q$, sessions[1], p[6]),
                               'TOO_MANY_ACTIVE');
  PERFORM pg_temp.ok(true, 'one account cannot hold more than 5 upcoming bookings');

  SELECT * INTO a FROM appointments WHERE session_id = sessions[1] AND patient_id = p[1];
  PERFORM pg_temp.expect_error(format($q$ SELECT cancel_appointment(%L, 'b2000000-0000-4000-8000-000000000002', false, 'x') $q$, a.id), 'NOT_FOUND');
  PERFORM pg_temp.ok(true, 'another account cannot cancel my booking');

  -- Fill the sitting, put Booker Two on the waiting list, then free a seat.
  UPDATE consultation_sessions SET capacity = 5 WHERE id = sessions[1];
  PERFORM pg_temp.expect_error(format($q$ SELECT book_appointment(%L, 'b3000000-0000-4000-8000-000000000002', 'b2000000-0000-4000-8000-000000000002') $q$, sessions[1]),
                               'SESSION_FULL');
  INSERT INTO waitlist_entries (session_id, patient_id, user_id) VALUES (sessions[1], 'b3000000-0000-4000-8000-000000000002', 'b2000000-0000-4000-8000-000000000002');
  PERFORM pg_temp.ok(offer_next_waitlist(sessions[1]) IS NULL, 'no offer while the sitting is full');
  PERFORM cancel_appointment(a.id, 'b2000000-0000-4000-8000-000000000001', false, 'cannot come');
  w := offer_next_waitlist(sessions[1]);
  PERFORM pg_temp.ok(w.patient_id = 'b3000000-0000-4000-8000-000000000002' AND w.status = 'offered', 'freed seat is offered to the first person waiting');
  PERFORM book_appointment(sessions[1], 'b3000000-0000-4000-8000-000000000002', 'b2000000-0000-4000-8000-000000000002');
  PERFORM pg_temp.ok((SELECT status FROM waitlist_entries WHERE id = w.id) = 'booked', 'waiting-list entry marked booked');

  -- Cancel window: once booking closes, patients cannot cancel; providers still can.
  SELECT * INTO a FROM appointments WHERE session_id = sessions[1] AND patient_id = p[2];
  UPDATE consultation_sessions SET booking_closes_at = now() - interval '1 minute' WHERE id = sessions[1];
  PERFORM pg_temp.expect_error(format($q$ SELECT cancel_appointment(%L, 'b2000000-0000-4000-8000-000000000001', false, 'late') $q$, a.id),
                               'CANCEL_WINDOW_CLOSED');
  PERFORM pg_temp.expect_error(format($q$ SELECT reschedule_appointment(%L, %L, 'b2000000-0000-4000-8000-000000000001') $q$, a.id, sessions[2]),
                               'CANCEL_WINDOW_CLOSED');
  PERFORM cancel_appointment(a.id, 'b2000000-0000-4000-8000-000000000009', true, 'doctor called away');
  PERFORM pg_temp.ok((SELECT status FROM appointments WHERE id = a.id) = 'cancelled_by_provider', 'provider can still cancel after the window');
END $$;

DO $$ BEGIN RAISE NOTICE 'ALL BOOKING TESTS PASSED'; END $$;
ROLLBACK;
