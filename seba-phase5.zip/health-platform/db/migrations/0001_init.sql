-- =====================================================================
-- Healthcare Booking & Pharmacy Platform — initial schema
-- Target: PostgreSQL 15+
-- Conventions:
--   * UUID primary keys (gen_random_uuid), timestamptz everywhere.
--   * Money is stored as integer paise (bigint) — never floats.
--   * Local times are Asia/Kolkata; absolute instants stored as timestamptz.
--   * Soft-delete via deleted_at where records must be kept for audit/legal.
--   * Sensitive files (prescriptions, licences) are stored in private object
--     storage; the DB holds only the object key + hash, never the bytes.
-- =====================================================================

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid, digest
CREATE EXTENSION IF NOT EXISTS pg_trgm;    -- fuzzy search on names

-- ---------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------
CREATE TYPE account_status      AS ENUM ('active','suspended','deleted');
CREATE TYPE app_language        AS ENUM ('en','bn','hi');
CREATE TYPE role_name           AS ENUM (
  'patient',
  'doctor',
  'facility_admin','facility_staff',
  'pharmacy_admin','pharmacist',
  'platform_admin','verifier','support_agent','finance');
CREATE TYPE verification_status AS ENUM ('draft','submitted','under_review','verified','rejected','suspended');
CREATE TYPE facility_type       AS ENUM ('hospital','nursing_home','clinic','diagnostic_centre','chamber');
CREATE TYPE booking_mode        AS ENUM ('time_slot','serial_token');
CREATE TYPE session_status      AS ENUM ('scheduled','running_late','cancelled','completed');
CREATE TYPE schedule_state      AS ENUM ('unverified','confirmed','stale');
CREATE TYPE exception_kind      AS ENUM ('leave','holiday','cancelled','time_change','extra_session');
CREATE TYPE appointment_status  AS ENUM (
  'pending_payment','confirmed','checked_in','completed',
  'cancelled_by_patient','cancelled_by_provider','no_show','rescheduled','expired');
CREATE TYPE waitlist_status     AS ENUM ('waiting','offered','booked','expired','cancelled');
CREATE TYPE drug_schedule       AS ENUM ('otc','G','H','H1','X','narcotic_psychotropic');
CREATE TYPE prescription_status AS ENUM ('uploaded','approved','rejected','expired');
CREATE TYPE review_decision     AS ENUM ('approved','rejected','needs_clarification');
CREATE TYPE order_status        AS ENUM (
  'placed','awaiting_rx_review','accepted','rejected','packed',
  'dispatched','delivered','cancelled','returned');
CREATE TYPE payment_status      AS ENUM ('created','authorized','captured','failed','refunded','partially_refunded');
CREATE TYPE payment_purpose     AS ENUM ('appointment','medicine_order','test_booking','subscription');
CREATE TYPE refund_status       AS ENUM ('requested','processing','succeeded','failed');
CREATE TYPE notif_channel       AS ENUM ('sms','whatsapp','push','email','in_app');
CREATE TYPE notif_status        AS ENUM ('queued','sent','delivered','failed','dev_logged');
CREATE TYPE complaint_status    AS ENUM ('open','investigating','resolved','closed');
CREATE TYPE moderation_status   AS ENUM ('pending','published','hidden');

-- ---------------------------------------------------------------------
-- Generic updated_at trigger
-- ---------------------------------------------------------------------
CREATE FUNCTION set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at := now(); RETURN NEW; END $$;

-- ---------------------------------------------------------------------
-- Geography
-- ---------------------------------------------------------------------
CREATE TABLE localities (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_en     text NOT NULL,
  name_bn     text,
  district    text NOT NULL,
  state       text NOT NULL DEFAULT 'West Bengal',
  pincode     text CHECK (pincode ~ '^[1-9][0-9]{5}$'),
  is_launched boolean NOT NULL DEFAULT false,
  UNIQUE (name_en, district, state)
);

-- ---------------------------------------------------------------------
-- Identity, auth, roles, consent
-- ---------------------------------------------------------------------
CREATE TABLE users (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_e164     text NOT NULL UNIQUE CHECK (phone_e164 ~ '^\+91[6-9][0-9]{9}$'),
  display_name   text,
  email          text,
  preferred_lang app_language NOT NULL DEFAULT 'bn',
  status         account_status NOT NULL DEFAULT 'active',
  locality_id    uuid REFERENCES localities(id),
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  last_login_at  timestamptz,
  deleted_at     timestamptz
);
CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- OTP challenges: only a hash of the code is stored. In dev mode the code is
-- written to the server log, never returned by the API.
CREATE TABLE otp_challenges (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone_e164   text NOT NULL,
  code_hash    text NOT NULL,
  purpose      text NOT NULL DEFAULT 'login',
  attempts     int  NOT NULL DEFAULT 0 CHECK (attempts BETWEEN 0 AND 5),
  expires_at   timestamptz NOT NULL,
  consumed_at  timestamptz,
  request_ip   inet,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_otp_phone_recent ON otp_challenges (phone_e164, created_at DESC);

CREATE TABLE auth_sessions (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash   text NOT NULL UNIQUE,           -- sha256 of opaque cookie token
  user_agent   text,
  ip           inet,
  created_at   timestamptz NOT NULL DEFAULT now(),
  expires_at   timestamptz NOT NULL,
  revoked_at   timestamptz
);
CREATE INDEX idx_auth_sessions_user ON auth_sessions (user_id) WHERE revoked_at IS NULL;

-- Consent ledger (DPDP): one row per grant; withdrawal is a timestamp, never a delete.
CREATE TABLE consents (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  purpose        text NOT NULL,   -- e.g. 'core_service','whatsapp_updates','marketing'
  notice_version text NOT NULL,
  granted_at     timestamptz NOT NULL DEFAULT now(),
  withdrawn_at   timestamptz
);
CREATE UNIQUE INDEX uq_consent_active ON consents (user_id, purpose) WHERE withdrawn_at IS NULL;

-- Patients: the account holder plus family members they manage.
CREATE TABLE patients (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_user_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  relation         text NOT NULL DEFAULT 'self'
                   CHECK (relation IN ('self','spouse','child','parent','sibling','other')),
  full_name        text NOT NULL,
  date_of_birth    date,
  sex              text CHECK (sex IN ('female','male','other')),
  phone_e164       text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  deleted_at       timestamptz
);
CREATE UNIQUE INDEX uq_patient_self ON patients (account_user_id) WHERE relation = 'self' AND deleted_at IS NULL;
CREATE INDEX idx_patients_account ON patients (account_user_id);
CREATE TRIGGER trg_patients_updated BEFORE UPDATE ON patients FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE addresses (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  label       text,
  line1       text NOT NULL,
  line2       text,
  landmark    text,
  locality_id uuid REFERENCES localities(id),
  pincode     text NOT NULL CHECK (pincode ~ '^[1-9][0-9]{5}$'),
  lat         numeric(9,6),
  lng         numeric(9,6),
  is_default  boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX uq_address_default ON addresses (user_id) WHERE is_default;

-- ---------------------------------------------------------------------
-- Providers: doctors, facilities, pharmacies
-- ---------------------------------------------------------------------
CREATE TABLE specialities (
  id       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug     text NOT NULL UNIQUE,
  name_en  text NOT NULL,
  name_bn  text,
  name_hi  text
);

CREATE TABLE doctors (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               uuid UNIQUE REFERENCES users(id),   -- null until doctor claims profile
  full_name             text NOT NULL,
  full_name_bn          text,
  sex                   text CHECK (sex IN ('female','male','other')),
  registration_number   text NOT NULL,
  registration_council  text NOT NULL,                     -- e.g. 'West Bengal Medical Council'
  nmr_id                text UNIQUE,                       -- National Medical Register ID when available
  practising_since      smallint CHECK (practising_since BETWEEN 1950 AND 2100),
  bio_en                text,
  bio_bn                text,
  photo_key             text,
  languages             text[] NOT NULL DEFAULT '{}',
  verification_status   verification_status NOT NULL DEFAULT 'draft',
  verified_at           timestamptz,
  verified_by           uuid REFERENCES users(id),
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  UNIQUE (registration_council, registration_number),
  CHECK (verification_status <> 'verified' OR (verified_at IS NOT NULL AND verified_by IS NOT NULL))
);
CREATE INDEX idx_doctors_name_trgm ON doctors USING gin (full_name gin_trgm_ops);
CREATE TRIGGER trg_doctors_updated BEFORE UPDATE ON doctors FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE doctor_qualifications (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id    uuid NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  degree       text NOT NULL,          -- MBBS, MD (Medicine), DGO ...
  institution  text,
  year         smallint,
  is_verified  boolean NOT NULL DEFAULT false
);
CREATE INDEX idx_dq_doctor ON doctor_qualifications (doctor_id);

CREATE TABLE doctor_specialities (
  doctor_id     uuid NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  speciality_id uuid NOT NULL REFERENCES specialities(id),
  is_primary    boolean NOT NULL DEFAULT false,
  PRIMARY KEY (doctor_id, speciality_id)
);
CREATE INDEX idx_ds_speciality ON doctor_specialities (speciality_id);

CREATE TABLE facilities (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type                  facility_type NOT NULL,
  name                  text NOT NULL,
  name_bn               text,
  address_line          text NOT NULL,
  locality_id           uuid NOT NULL REFERENCES localities(id),
  pincode               text CHECK (pincode ~ '^[1-9][0-9]{5}$'),
  lat                   numeric(9,6),
  lng                   numeric(9,6),
  phone_e164            text,
  establishment_reg_no  text,          -- Clinical Establishment / state licence no.
  open_24x7             boolean NOT NULL DEFAULT false,
  emergency_available   boolean NOT NULL DEFAULT false,
  verification_status   verification_status NOT NULL DEFAULT 'draft',
  verified_at           timestamptz,
  is_published          boolean NOT NULL DEFAULT false,
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT is_published OR verification_status = 'verified')
);
CREATE INDEX idx_facilities_locality ON facilities (locality_id, type) WHERE is_published;
CREATE INDEX idx_facilities_name_trgm ON facilities USING gin (name gin_trgm_ops);
CREATE TRIGGER trg_facilities_updated BEFORE UPDATE ON facilities FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE departments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  facility_id uuid NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  name        text NOT NULL,
  name_bn     text,
  UNIQUE (facility_id, name)
);

CREATE TABLE facility_services (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  facility_id uuid NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  category    text NOT NULL,        -- 'ICU','X-Ray','Ambulance','Pathology' ...
  name        text NOT NULL,
  UNIQUE (facility_id, name)
);

-- Role grants, optionally scoped to one facility or pharmacy (least privilege).
CREATE TABLE pharmacies (
  id                        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  legal_name                text NOT NULL,
  display_name              text NOT NULL,
  address_line              text NOT NULL,
  locality_id               uuid NOT NULL REFERENCES localities(id),
  pincode                   text NOT NULL CHECK (pincode ~ '^[1-9][0-9]{5}$'),
  lat                       numeric(9,6),
  lng                       numeric(9,6),
  phone_e164                text,
  retail_licence_no         text NOT NULL,       -- drug sale licence (retail)
  licence_valid_until       date NOT NULL,
  gstin                     text,
  pharmacist_name           text NOT NULL,
  pharmacist_reg_no         text NOT NULL,        -- State Pharmacy Council registration
  delivery_radius_km        numeric(4,1) NOT NULL DEFAULT 5 CHECK (delivery_radius_km > 0),
  accepts_online_orders     boolean NOT NULL DEFAULT false,
  verification_status       verification_status NOT NULL DEFAULT 'draft',
  verified_at               timestamptz,
  created_at                timestamptz NOT NULL DEFAULT now(),
  updated_at                timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT accepts_online_orders OR verification_status = 'verified')
);
CREATE TRIGGER trg_pharmacies_updated BEFORE UPDATE ON pharmacies FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE user_roles (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id      uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role         role_name NOT NULL,
  facility_id  uuid REFERENCES facilities(id) ON DELETE CASCADE,
  pharmacy_id  uuid REFERENCES pharmacies(id) ON DELETE CASCADE,
  granted_by   uuid REFERENCES users(id),
  granted_at   timestamptz NOT NULL DEFAULT now(),
  revoked_at   timestamptz,
  CHECK (
    (role IN ('facility_admin','facility_staff') AND facility_id IS NOT NULL AND pharmacy_id IS NULL) OR
    (role IN ('pharmacy_admin','pharmacist')     AND pharmacy_id IS NOT NULL AND facility_id IS NULL) OR
    (role IN ('patient','doctor','platform_admin','verifier','support_agent','finance')
                                                 AND facility_id IS NULL AND pharmacy_id IS NULL)
  )
);
CREATE UNIQUE INDEX uq_user_role_active ON user_roles
  (user_id, role, coalesce(facility_id, '00000000-0000-0000-0000-000000000000'::uuid),
                  coalesce(pharmacy_id, '00000000-0000-0000-0000-000000000000'::uuid))
  WHERE revoked_at IS NULL;

-- Onboarding / verification workflow for doctors, facilities and pharmacies.
CREATE TABLE verification_requests (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type   text NOT NULL CHECK (entity_type IN ('doctor','facility','pharmacy','doctor_facility')),
  entity_id     uuid NOT NULL,
  status        verification_status NOT NULL DEFAULT 'submitted',
  submitted_by  uuid NOT NULL REFERENCES users(id),
  reviewer_id   uuid REFERENCES users(id),
  decision_note text,
  submitted_at  timestamptz NOT NULL DEFAULT now(),
  decided_at    timestamptz
);
CREATE INDEX idx_vr_queue ON verification_requests (status, submitted_at);

CREATE TABLE verification_documents (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  request_id   uuid NOT NULL REFERENCES verification_requests(id) ON DELETE CASCADE,
  doc_type     text NOT NULL,   -- 'medical_registration','degree','drug_licence','establishment_licence','id_proof'
  file_key     text NOT NULL,   -- private object-storage key
  sha256       text NOT NULL,
  mime_type    text NOT NULL CHECK (mime_type IN ('application/pdf','image/jpeg','image/png','image/webp')),
  size_bytes   int  NOT NULL CHECK (size_bytes BETWEEN 1 AND 10485760),
  uploaded_at  timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- Doctor ↔ facility practice, schedules, sessions
-- ---------------------------------------------------------------------
CREATE TABLE doctor_practices (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id             uuid NOT NULL REFERENCES doctors(id),
  facility_id           uuid NOT NULL REFERENCES facilities(id),
  department_id         uuid REFERENCES departments(id),
  consultation_fee_paise bigint NOT NULL CHECK (consultation_fee_paise >= 0),
  booking_mode          booking_mode NOT NULL DEFAULT 'serial_token',
  is_active             boolean NOT NULL DEFAULT true,
  schedule_state        schedule_state NOT NULL DEFAULT 'unverified',
  schedule_confirmed_at timestamptz,
  schedule_confirmed_by uuid REFERENCES users(id),
  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now(),
  UNIQUE (doctor_id, facility_id),
  CHECK (schedule_state <> 'confirmed' OR (schedule_confirmed_at IS NOT NULL AND schedule_confirmed_by IS NOT NULL))
);
CREATE INDEX idx_dp_facility ON doctor_practices (facility_id) WHERE is_active;
CREATE TRIGGER trg_dp_updated BEFORE UPDATE ON doctor_practices FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Recurring weekly template ("Dr X sits at Y chamber every Mon & Thu 5-8 pm, 30 patients").
CREATE TABLE schedule_templates (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id     uuid NOT NULL REFERENCES doctor_practices(id) ON DELETE CASCADE,
  weekday         smallint NOT NULL CHECK (weekday BETWEEN 0 AND 6),   -- 0 = Sunday
  shift_label     text NOT NULL DEFAULT 'morning' CHECK (shift_label IN ('morning','afternoon','evening','night')),
  start_time      time NOT NULL,
  end_time        time NOT NULL,
  slot_minutes    smallint CHECK (slot_minutes BETWEEN 5 AND 120),     -- required for time_slot mode
  capacity        smallint NOT NULL CHECK (capacity BETWEEN 1 AND 500),
  week_of_month   smallint[] ,                                         -- e.g. {1,3} = 1st & 3rd week only
  effective_from  date NOT NULL DEFAULT current_date,
  effective_to    date,
  CHECK (end_time > start_time),
  CHECK (effective_to IS NULL OR effective_to >= effective_from)
);
CREATE INDEX idx_st_practice ON schedule_templates (practice_id, weekday);

-- One-off changes: leave, holiday, cancelled sitting, changed time, extra sitting.
CREATE TABLE schedule_exceptions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id       uuid NOT NULL REFERENCES doctors(id),
  practice_id     uuid REFERENCES doctor_practices(id),   -- null = applies to all practices (doctor leave)
  kind            exception_kind NOT NULL,
  starts_on       date NOT NULL,
  ends_on         date NOT NULL,
  new_start_time  time,
  new_end_time    time,
  reason_public   text,
  created_by      uuid NOT NULL REFERENCES users(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  CHECK (ends_on >= starts_on),
  CHECK (kind NOT IN ('time_change','extra_session') OR (new_start_time IS NOT NULL AND new_end_time IS NOT NULL AND new_end_time > new_start_time))
);
CREATE INDEX idx_se_doctor_dates ON schedule_exceptions (doctor_id, starts_on, ends_on);

-- Concrete bookable sittings, materialised from templates + exceptions for the next N days.
-- active_count = live bookings (capacity check); next_token only ever increases so
-- serial numbers are never reused after a cancellation.
CREATE TABLE consultation_sessions (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  practice_id       uuid NOT NULL REFERENCES doctor_practices(id),
  template_id       uuid REFERENCES schedule_templates(id) ON DELETE SET NULL,
  session_date      date NOT NULL,
  starts_at         timestamptz NOT NULL,
  ends_at           timestamptz NOT NULL,
  booking_mode      booking_mode NOT NULL,
  slot_minutes      smallint,
  capacity          smallint NOT NULL CHECK (capacity >= 1),
  active_count      smallint NOT NULL DEFAULT 0,
  next_token        smallint NOT NULL DEFAULT 1,
  status            session_status NOT NULL DEFAULT 'scheduled',
  booking_closes_at timestamptz,                    -- default: starts_at - 30 min (set by app)
  public_note       text,                           -- "Doctor running 45 min late"
  updated_by        uuid REFERENCES users(id),
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  UNIQUE (practice_id, starts_at),
  CHECK (ends_at > starts_at),
  CHECK (active_count BETWEEN 0 AND capacity),
  CHECK (next_token >= 1),
  CHECK (booking_mode <> 'time_slot' OR slot_minutes IS NOT NULL)
);
CREATE INDEX idx_cs_upcoming ON consultation_sessions (session_date, status);
CREATE INDEX idx_cs_practice_date ON consultation_sessions (practice_id, session_date);
CREATE TRIGGER trg_cs_updated BEFORE UPDATE ON consultation_sessions FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------
-- Appointments
-- ---------------------------------------------------------------------
CREATE TABLE appointments (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_code         text NOT NULL UNIQUE,     -- short human code e.g. 'DH7K3P9Q'
  session_id           uuid NOT NULL REFERENCES consultation_sessions(id),
  patient_id           uuid NOT NULL REFERENCES patients(id),
  booked_by_user_id    uuid NOT NULL REFERENCES users(id),
  token_number         smallint NOT NULL,
  slot_starts_at       timestamptz,              -- only for time_slot mode
  status               appointment_status NOT NULL DEFAULT 'confirmed',
  consultation_fee_paise bigint NOT NULL CHECK (consultation_fee_paise >= 0),  -- snapshot
  platform_fee_paise   bigint NOT NULL DEFAULT 0 CHECK (platform_fee_paise >= 0),
  pay_at_clinic        boolean NOT NULL DEFAULT true,
  rescheduled_from_id  uuid REFERENCES appointments(id),
  cancel_reason        text,
  cancelled_at         timestamptz,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);
-- "Active" = still holds a seat.
CREATE UNIQUE INDEX uq_appt_token_active   ON appointments (session_id, token_number)
  WHERE status IN ('pending_payment','confirmed','checked_in','completed');
CREATE UNIQUE INDEX uq_appt_slot_active    ON appointments (session_id, slot_starts_at)
  WHERE slot_starts_at IS NOT NULL AND status IN ('pending_payment','confirmed','checked_in','completed');
CREATE UNIQUE INDEX uq_appt_patient_session ON appointments (session_id, patient_id)
  WHERE status IN ('pending_payment','confirmed','checked_in','completed');
CREATE INDEX idx_appt_patient ON appointments (patient_id, created_at DESC);
CREATE INDEX idx_appt_booker  ON appointments (booked_by_user_id, created_at DESC);
CREATE TRIGGER trg_appt_updated BEFORE UPDATE ON appointments FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE appointment_events (
  id             bigserial PRIMARY KEY,
  appointment_id uuid NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
  from_status    appointment_status,
  to_status      appointment_status NOT NULL,
  actor_user_id  uuid REFERENCES users(id),
  note           text,
  at             timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_appt_events ON appointment_events (appointment_id, at);

CREATE TABLE waitlist_entries (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id  uuid NOT NULL REFERENCES consultation_sessions(id) ON DELETE CASCADE,
  patient_id  uuid NOT NULL REFERENCES patients(id),
  user_id     uuid NOT NULL REFERENCES users(id),
  status      waitlist_status NOT NULL DEFAULT 'waiting',
  offered_until timestamptz,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (session_id, patient_id)
);
CREATE INDEX idx_waitlist_fifo ON waitlist_entries (session_id, created_at) WHERE status = 'waiting';

CREATE TABLE saved_doctors (
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doctor_id  uuid NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, doctor_id)
);

-- ---------------------------------------------------------------------
-- Diagnostics (schema ready; UI in a later phase)
-- ---------------------------------------------------------------------
CREATE TABLE lab_tests (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  facility_id       uuid NOT NULL REFERENCES facilities(id) ON DELETE CASCADE,
  name              text NOT NULL,
  name_bn           text,
  sample_type       text,
  preparation_note  text,
  price_paise       bigint NOT NULL CHECK (price_paise >= 0),
  home_collection   boolean NOT NULL DEFAULT false,
  is_active         boolean NOT NULL DEFAULT true,
  UNIQUE (facility_id, name)
);

CREATE TABLE test_bookings (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_code   text NOT NULL UNIQUE,
  facility_id    uuid NOT NULL REFERENCES facilities(id),
  patient_id     uuid NOT NULL REFERENCES patients(id),
  user_id        uuid NOT NULL REFERENCES users(id),
  scheduled_for  timestamptz NOT NULL,
  home_collection boolean NOT NULL DEFAULT false,
  status         text NOT NULL DEFAULT 'booked' CHECK (status IN ('booked','sample_collected','report_ready','cancelled')),
  total_paise    bigint NOT NULL CHECK (total_paise >= 0),
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE test_booking_items (
  test_booking_id uuid NOT NULL REFERENCES test_bookings(id) ON DELETE CASCADE,
  lab_test_id     uuid NOT NULL REFERENCES lab_tests(id),
  price_paise     bigint NOT NULL CHECK (price_paise >= 0),
  PRIMARY KEY (test_booking_id, lab_test_id)
);

-- ---------------------------------------------------------------------
-- Pharmacy: catalogue, inventory, prescriptions, orders
-- ---------------------------------------------------------------------
CREATE TABLE medicines (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_name         text NOT NULL,
  generic_name       text NOT NULL,              -- composition, e.g. 'Paracetamol 500 mg'
  manufacturer       text,
  strength           text,
  dosage_form        text NOT NULL,              -- tablet, syrup, injection ...
  pack_size          text NOT NULL,              -- '15 tablets', '100 ml'
  schedule           drug_schedule NOT NULL,
  requires_prescription boolean GENERATED ALWAYS AS (schedule IN ('H','H1','X','narcotic_psychotropic')) STORED,
  -- Platform policy: Schedule X and narcotic/psychotropic drugs are never sold online.
  online_sale_allowed boolean GENERATED ALWAYS AS (schedule NOT IN ('X','narcotic_psychotropic')) STORED,
  cold_chain         boolean NOT NULL DEFAULT false,
  mrp_paise          bigint NOT NULL CHECK (mrp_paise > 0),
  hsn_code           text,
  is_active          boolean NOT NULL DEFAULT true,
  created_at         timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_name, strength, dosage_form, pack_size, manufacturer)
);
CREATE INDEX idx_med_brand_trgm   ON medicines USING gin (brand_name gin_trgm_ops);
CREATE INDEX idx_med_generic_trgm ON medicines USING gin (generic_name gin_trgm_ops);

CREATE TABLE pharmacy_inventory (
  pharmacy_id   uuid NOT NULL REFERENCES pharmacies(id) ON DELETE CASCADE,
  medicine_id   uuid NOT NULL REFERENCES medicines(id),
  selling_price_paise bigint NOT NULL CHECK (selling_price_paise > 0),
  stock_qty     int NOT NULL DEFAULT 0 CHECK (stock_qty >= 0),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (pharmacy_id, medicine_id)
);
CREATE INDEX idx_inv_medicine ON pharmacy_inventory (medicine_id) WHERE stock_qty > 0;

-- Selling price may never exceed MRP.
CREATE FUNCTION check_price_le_mrp() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE m bigint;
BEGIN
  SELECT mrp_paise INTO m FROM medicines WHERE id = NEW.medicine_id;
  IF NEW.selling_price_paise > m THEN
    RAISE EXCEPTION 'selling price % exceeds MRP %', NEW.selling_price_paise, m USING ERRCODE = 'check_violation';
  END IF;
  NEW.updated_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER trg_inv_price BEFORE INSERT OR UPDATE ON pharmacy_inventory FOR EACH ROW EXECUTE FUNCTION check_price_le_mrp();

CREATE TABLE prescriptions (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id        uuid NOT NULL REFERENCES patients(id),
  uploaded_by       uuid NOT NULL REFERENCES users(id),
  file_key          text NOT NULL,
  sha256            text NOT NULL,
  mime_type         text NOT NULL CHECK (mime_type IN ('application/pdf','image/jpeg','image/png','image/webp')),
  size_bytes        int  NOT NULL CHECK (size_bytes BETWEEN 1 AND 10485760),
  prescriber_name   text,
  prescriber_reg_no text,
  issued_on         date,
  status            prescription_status NOT NULL DEFAULT 'uploaded',
  created_at        timestamptz NOT NULL DEFAULT now(),
  deleted_at        timestamptz
);
CREATE INDEX idx_rx_patient ON prescriptions (patient_id, created_at DESC);

CREATE TABLE medicine_orders (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_code           text NOT NULL UNIQUE,
  user_id              uuid NOT NULL REFERENCES users(id),
  patient_id           uuid NOT NULL REFERENCES patients(id),
  pharmacy_id          uuid NOT NULL REFERENCES pharmacies(id),
  prescription_id      uuid REFERENCES prescriptions(id),
  requires_prescription boolean NOT NULL DEFAULT false,
  status               order_status NOT NULL DEFAULT 'placed',
  delivery_address     jsonb NOT NULL,             -- snapshot at order time
  subtotal_paise       bigint NOT NULL CHECK (subtotal_paise >= 0),
  delivery_fee_paise   bigint NOT NULL DEFAULT 0 CHECK (delivery_fee_paise >= 0),
  platform_fee_paise   bigint NOT NULL DEFAULT 0 CHECK (platform_fee_paise >= 0),
  total_paise          bigint GENERATED ALWAYS AS (subtotal_paise + delivery_fee_paise + platform_fee_paise) STORED,
  payment_mode         text NOT NULL DEFAULT 'online' CHECK (payment_mode IN ('online','cod')),
  payment_status       payment_status NOT NULL DEFAULT 'created',
  estimated_delivery_at timestamptz,
  rejection_reason     text,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT requires_prescription OR prescription_id IS NOT NULL)
);
CREATE INDEX idx_mo_user     ON medicine_orders (user_id, created_at DESC);
CREATE INDEX idx_mo_pharmacy ON medicine_orders (pharmacy_id, status, created_at);
CREATE TRIGGER trg_mo_updated BEFORE UPDATE ON medicine_orders FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE medicine_order_items (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id           uuid NOT NULL REFERENCES medicine_orders(id) ON DELETE CASCADE,
  medicine_id        uuid NOT NULL REFERENCES medicines(id),
  quantity           int  NOT NULL CHECK (quantity BETWEEN 1 AND 100),
  unit_price_paise   bigint NOT NULL CHECK (unit_price_paise > 0),
  line_total_paise   bigint GENERATED ALWAYS AS (quantity * unit_price_paise) STORED,
  schedule_snapshot  drug_schedule NOT NULL,
  UNIQUE (order_id, medicine_id)
);

-- Block drugs that may not be sold online, and keep the order's Rx flag honest.
CREATE FUNCTION enforce_order_item_rules() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE med medicines%ROWTYPE; ord medicine_orders%ROWTYPE;
BEGIN
  SELECT * INTO med FROM medicines WHERE id = NEW.medicine_id;
  IF NOT med.online_sale_allowed THEN
    RAISE EXCEPTION 'medicine % (schedule %) cannot be sold online', med.brand_name, med.schedule
      USING ERRCODE = 'check_violation';
  END IF;
  IF NOT med.is_active THEN
    RAISE EXCEPTION 'medicine % is inactive', med.brand_name USING ERRCODE = 'check_violation';
  END IF;
  NEW.schedule_snapshot := med.schedule;
  SELECT * INTO ord FROM medicine_orders WHERE id = NEW.order_id;
  IF med.requires_prescription AND NOT ord.requires_prescription THEN
    RAISE EXCEPTION 'order % contains a prescription-only medicine but is not marked as requiring a prescription', ord.order_code
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_order_item_rules BEFORE INSERT OR UPDATE ON medicine_order_items
  FOR EACH ROW EXECUTE FUNCTION enforce_order_item_rules();

CREATE TABLE prescription_reviews (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prescription_id    uuid NOT NULL REFERENCES prescriptions(id),
  order_id           uuid NOT NULL REFERENCES medicine_orders(id),
  pharmacist_user_id uuid NOT NULL REFERENCES users(id),
  pharmacist_reg_no  text NOT NULL,
  decision           review_decision NOT NULL,
  notes              text,
  reviewed_at        timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_rx_reviews_order ON prescription_reviews (order_id, reviewed_at DESC);

CREATE TABLE order_events (
  id           bigserial PRIMARY KEY,
  order_id     uuid NOT NULL REFERENCES medicine_orders(id) ON DELETE CASCADE,
  from_status  order_status,
  to_status    order_status NOT NULL,
  actor_user_id uuid REFERENCES users(id),
  note         text,
  at           timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_order_events ON order_events (order_id, at);

-- ---------------------------------------------------------------------
-- Money: fees, payments, refunds, settlements, subscriptions
-- ---------------------------------------------------------------------
CREATE TABLE fee_rules (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  applies_to    payment_purpose NOT NULL,
  facility_id   uuid REFERENCES facilities(id),
  pharmacy_id   uuid REFERENCES pharmacies(id),
  flat_paise    bigint NOT NULL DEFAULT 0 CHECK (flat_paise >= 0),
  percent_bp    int    NOT NULL DEFAULT 0 CHECK (percent_bp BETWEEN 0 AND 5000), -- basis points
  fee_kind      text NOT NULL CHECK (fee_kind IN ('patient_platform_fee','partner_commission')),
  effective_from timestamptz NOT NULL DEFAULT now(),
  effective_to   timestamptz,
  created_by    uuid NOT NULL REFERENCES users(id)
);

CREATE TABLE payments (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  purpose             payment_purpose NOT NULL,
  appointment_id      uuid REFERENCES appointments(id),
  order_id            uuid REFERENCES medicine_orders(id),
  test_booking_id     uuid REFERENCES test_bookings(id),
  user_id             uuid NOT NULL REFERENCES users(id),
  gateway             text NOT NULL,               -- 'razorpay' | 'cashfree' | 'dev'
  gateway_order_id    text NOT NULL,
  gateway_payment_id  text,
  amount_paise        bigint NOT NULL CHECK (amount_paise > 0),
  currency            char(3) NOT NULL DEFAULT 'INR',
  status              payment_status NOT NULL DEFAULT 'created',
  signature_verified  boolean NOT NULL DEFAULT false,
  verified_at         timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),
  UNIQUE (gateway, gateway_order_id),
  CHECK (num_nonnulls(appointment_id, order_id, test_booking_id) <= 1),
  CHECK (status NOT IN ('captured','refunded','partially_refunded') OR signature_verified)
);
CREATE UNIQUE INDEX uq_payment_gateway_payment ON payments (gateway, gateway_payment_id) WHERE gateway_payment_id IS NOT NULL;
CREATE TRIGGER trg_pay_updated BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Raw gateway webhooks, deduplicated by event id (idempotency).
CREATE TABLE payment_webhook_events (
  gateway      text NOT NULL,
  event_id     text NOT NULL,
  payload      jsonb NOT NULL,
  received_at  timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  PRIMARY KEY (gateway, event_id)
);

CREATE TABLE refunds (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id        uuid NOT NULL REFERENCES payments(id),
  amount_paise      bigint NOT NULL CHECK (amount_paise > 0),
  reason            text NOT NULL,
  status            refund_status NOT NULL DEFAULT 'requested',
  gateway_refund_id text UNIQUE,
  requested_by      uuid REFERENCES users(id),
  created_at        timestamptz NOT NULL DEFAULT now(),
  completed_at      timestamptz
);

CREATE TABLE settlements (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  partner_type     text NOT NULL CHECK (partner_type IN ('facility','pharmacy')),
  partner_id       uuid NOT NULL,
  period_start     date NOT NULL,
  period_end       date NOT NULL,
  gross_paise      bigint NOT NULL,
  commission_paise bigint NOT NULL,
  refunds_paise    bigint NOT NULL DEFAULT 0,
  net_payable_paise bigint GENERATED ALWAYS AS (gross_paise - commission_paise - refunds_paise) STORED,
  status           text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','paid','disputed')),
  utr_reference    text,
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (partner_type, partner_id, period_start, period_end),
  CHECK (period_end >= period_start)
);

CREATE TABLE provider_subscriptions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  facility_id   uuid REFERENCES facilities(id),
  pharmacy_id   uuid REFERENCES pharmacies(id),
  plan_code     text NOT NULL,
  price_paise   bigint NOT NULL CHECK (price_paise >= 0),
  starts_on     date NOT NULL,
  ends_on       date NOT NULL,
  status        text NOT NULL DEFAULT 'active' CHECK (status IN ('trial','active','past_due','cancelled')),
  CHECK (num_nonnulls(facility_id, pharmacy_id) = 1),
  CHECK (ends_on > starts_on)
);

-- ---------------------------------------------------------------------
-- Engagement: notifications, reviews, complaints, promotions
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id             uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel             notif_channel NOT NULL,
  template_key        text NOT NULL,          -- 'appointment_confirmed', 'order_dispatched' ...
  lang                app_language NOT NULL DEFAULT 'bn',
  payload             jsonb NOT NULL DEFAULT '{}',
  status              notif_status NOT NULL DEFAULT 'queued',
  provider_message_id text,
  read_at             timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now(),
  sent_at             timestamptz
);
CREATE INDEX idx_notif_user  ON notifications (user_id, created_at DESC);
CREATE INDEX idx_notif_queue ON notifications (created_at) WHERE status = 'queued';

-- Reviews only from completed, verified visits — one per appointment.
CREATE TABLE reviews (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid NOT NULL UNIQUE REFERENCES appointments(id),
  user_id        uuid NOT NULL REFERENCES users(id),
  doctor_id      uuid NOT NULL REFERENCES doctors(id),
  facility_id    uuid NOT NULL REFERENCES facilities(id),
  rating         smallint NOT NULL CHECK (rating BETWEEN 1 AND 5),
  body           text CHECK (length(body) <= 2000),
  status         moderation_status NOT NULL DEFAULT 'pending',
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_reviews_doctor ON reviews (doctor_id) WHERE status = 'published';

CREATE FUNCTION enforce_review_completed() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM appointments WHERE id = NEW.appointment_id AND status = 'completed'
                 AND booked_by_user_id = NEW.user_id) THEN
    RAISE EXCEPTION 'reviews are only allowed for your own completed appointments' USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_review_completed BEFORE INSERT ON reviews FOR EACH ROW EXECUTE FUNCTION enforce_review_completed();

CREATE TABLE complaints (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_code    text NOT NULL UNIQUE,
  user_id        uuid NOT NULL REFERENCES users(id),
  subject_type   text NOT NULL CHECK (subject_type IN ('appointment','medicine_order','doctor','facility','pharmacy','payment','other')),
  subject_id     uuid,
  category       text NOT NULL,
  description    text NOT NULL,
  status         complaint_status NOT NULL DEFAULT 'open',
  assigned_to    uuid REFERENCES users(id),
  resolution     text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  resolved_at    timestamptz
);
CREATE INDEX idx_complaints_queue ON complaints (status, created_at);

CREATE TABLE promotions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind          text NOT NULL CHECK (kind IN ('banner','featured_listing')),
  title         text NOT NULL,
  image_key     text,
  target_type   text CHECK (target_type IN ('doctor','facility','pharmacy','url')),
  target_ref    text,
  locality_id   uuid REFERENCES localities(id),
  is_sponsored  boolean NOT NULL DEFAULT true,    -- always shown with a "Sponsored" label when true
  starts_at     timestamptz NOT NULL,
  ends_at       timestamptz NOT NULL,
  is_active     boolean NOT NULL DEFAULT true,
  CHECK (ends_at > starts_at)
);

CREATE TABLE platform_settings (
  key        text PRIMARY KEY,
  value      jsonb NOT NULL,
  updated_by uuid REFERENCES users(id),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO platform_settings (key, value) VALUES
  ('schedule_stale_after_days', '14'),
  ('booking_horizon_days',      '14'),
  ('booking_cutoff_minutes',    '30'),
  ('max_active_bookings_per_user', '5');

-- ---------------------------------------------------------------------
-- Audit log — append-only
-- ---------------------------------------------------------------------
CREATE TABLE audit_logs (
  id            bigserial PRIMARY KEY,
  actor_user_id uuid REFERENCES users(id),
  actor_role    role_name,
  action        text NOT NULL,           -- 'schedule.exception.create', 'doctor.verify', 'rx.view' ...
  entity_type   text NOT NULL,
  entity_id     uuid,
  before_data   jsonb,
  after_data    jsonb,
  ip            inet,
  request_id    text,
  at            timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_entity ON audit_logs (entity_type, entity_id, at DESC);
CREATE INDEX idx_audit_actor  ON audit_logs (actor_user_id, at DESC);

CREATE FUNCTION audit_logs_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'audit_logs is append-only' USING ERRCODE = 'insufficient_privilege'; END $$;
CREATE TRIGGER trg_audit_no_update BEFORE UPDATE OR DELETE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION audit_logs_immutable();
CREATE TRIGGER trg_audit_no_truncate BEFORE TRUNCATE ON audit_logs
  FOR EACH STATEMENT EXECUTE FUNCTION audit_logs_immutable();

-- =====================================================================
-- Transaction-safe booking logic
-- =====================================================================

-- Short, unambiguous booking codes (no 0/O/1/I).
CREATE FUNCTION make_code(prefix text, len int DEFAULT 8) RETURNS text LANGUAGE plpgsql AS $$
DECLARE alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; out text := prefix; b bytea; i int;
BEGIN
  b := gen_random_bytes(len);
  FOR i IN 0 .. len-1 LOOP
    out := out || substr(alphabet, (get_byte(b, i) % 32) + 1, 1);
  END LOOP;
  RETURN out;
END $$;

-- Is a session bookable right now? Single source of truth used by search and booking.
CREATE VIEW bookable_sessions AS
SELECT cs.*, dp.doctor_id, dp.facility_id, dp.consultation_fee_paise,
       dp.schedule_confirmed_at,
       (cs.capacity - cs.active_count) AS seats_left
FROM consultation_sessions cs
JOIN doctor_practices dp ON dp.id = cs.practice_id
JOIN doctors d           ON d.id = dp.doctor_id
JOIN facilities f        ON f.id = dp.facility_id
WHERE cs.status IN ('scheduled','running_late')
  AND dp.is_active
  AND dp.schedule_state = 'confirmed'
  AND dp.schedule_confirmed_at > now() - make_interval(days =>
        (SELECT value::int FROM platform_settings WHERE key = 'schedule_stale_after_days'))
  AND d.verification_status = 'verified'
  AND f.verification_status = 'verified' AND f.is_published
  AND coalesce(cs.booking_closes_at, cs.starts_at) > now();

-- Book one seat. Atomic: the conditional UPDATE takes a row lock on the session,
-- so concurrent callers serialise on it; the partial unique indexes are the backstop.
CREATE FUNCTION book_appointment(
  p_session_id uuid, p_patient_id uuid, p_user_id uuid,
  p_slot_starts_at timestamptz DEFAULT NULL, p_platform_fee_paise bigint DEFAULT 0
) RETURNS appointments LANGUAGE plpgsql AS $$
DECLARE s bookable_sessions%ROWTYPE; tok smallint; a appointments%ROWTYPE;
BEGIN
  -- patient must belong to the booking account
  IF NOT EXISTS (SELECT 1 FROM patients WHERE id = p_patient_id AND account_user_id = p_user_id AND deleted_at IS NULL) THEN
    RAISE EXCEPTION 'PATIENT_NOT_OWNED' USING ERRCODE = 'P0001';
  END IF;

  SELECT * INTO s FROM bookable_sessions WHERE id = p_session_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'SESSION_NOT_BOOKABLE' USING ERRCODE = 'P0001';
  END IF;

  IF s.booking_mode = 'time_slot' THEN
    IF p_slot_starts_at IS NULL
       OR p_slot_starts_at < s.starts_at
       OR p_slot_starts_at + make_interval(mins => s.slot_minutes) > s.ends_at
       OR mod(extract(epoch FROM (p_slot_starts_at - s.starts_at))::int, s.slot_minutes * 60) <> 0 THEN
      RAISE EXCEPTION 'INVALID_SLOT' USING ERRCODE = 'P0001';
    END IF;
  ELSIF p_slot_starts_at IS NOT NULL THEN
    RAISE EXCEPTION 'SLOT_NOT_APPLICABLE' USING ERRCODE = 'P0001';
  END IF;

  UPDATE consultation_sessions
     SET active_count = active_count + 1,
         next_token   = next_token + 1
   WHERE id = p_session_id
     AND status IN ('scheduled','running_late')
     AND active_count < capacity
  RETURNING next_token - 1 INTO tok;
  IF tok IS NULL THEN
    RAISE EXCEPTION 'SESSION_FULL' USING ERRCODE = 'P0001';
  END IF;

  BEGIN
    INSERT INTO appointments (booking_code, session_id, patient_id, booked_by_user_id,
                              token_number, slot_starts_at, status,
                              consultation_fee_paise, platform_fee_paise)
    VALUES (make_code('B'), p_session_id, p_patient_id, p_user_id,
            tok, p_slot_starts_at, 'confirmed',
            s.consultation_fee_paise, p_platform_fee_paise)
    RETURNING * INTO a;
  EXCEPTION WHEN unique_violation THEN
    -- slot taken or patient already booked: the whole statement is rolled back by the caller's txn
    RAISE EXCEPTION 'ALREADY_BOOKED' USING ERRCODE = 'P0001';
  END;

  INSERT INTO appointment_events (appointment_id, to_status, actor_user_id, note)
  VALUES (a.id, 'confirmed', p_user_id, 'booked');
  RETURN a;
END $$;

-- Cancel one appointment and free its seat (token number is NOT reused).
CREATE FUNCTION cancel_appointment(
  p_appointment_id uuid, p_actor uuid, p_by_provider boolean, p_reason text
) RETURNS appointments LANGUAGE plpgsql AS $$
DECLARE a appointments%ROWTYPE; new_status appointment_status; prev appointment_status;
BEGIN
  SELECT * INTO a FROM appointments WHERE id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND' USING ERRCODE = 'P0001'; END IF;
  IF a.status NOT IN ('pending_payment','confirmed') THEN
    RAISE EXCEPTION 'NOT_CANCELLABLE' USING ERRCODE = 'P0001';
  END IF;
  prev := a.status;
  new_status := CASE WHEN p_by_provider THEN 'cancelled_by_provider' ELSE 'cancelled_by_patient' END;

  UPDATE appointments SET status = new_status, cancel_reason = p_reason, cancelled_at = now()
   WHERE id = a.id RETURNING * INTO a;
  UPDATE consultation_sessions SET active_count = active_count - 1 WHERE id = a.session_id;
  INSERT INTO appointment_events (appointment_id, from_status, to_status, actor_user_id, note)
  VALUES (a.id, prev, new_status, p_actor, p_reason);
  RETURN a;
END $$;

-- Reschedule = book new + mark old as rescheduled, in one transaction.
CREATE FUNCTION reschedule_appointment(
  p_appointment_id uuid, p_new_session_id uuid, p_user_id uuid, p_slot_starts_at timestamptz DEFAULT NULL
) RETURNS appointments LANGUAGE plpgsql AS $$
DECLARE old appointments%ROWTYPE; nw appointments%ROWTYPE;
BEGIN
  SELECT * INTO old FROM appointments WHERE id = p_appointment_id AND booked_by_user_id = p_user_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND' USING ERRCODE = 'P0001'; END IF;
  IF old.status <> 'confirmed' THEN RAISE EXCEPTION 'NOT_RESCHEDULABLE' USING ERRCODE = 'P0001'; END IF;

  -- free the old seat first so a same-session time change works
  UPDATE appointments SET status = 'rescheduled', cancelled_at = now() WHERE id = old.id;
  UPDATE consultation_sessions SET active_count = active_count - 1 WHERE id = old.session_id;
  INSERT INTO appointment_events (appointment_id, from_status, to_status, actor_user_id, note)
  VALUES (old.id, 'confirmed', 'rescheduled', p_user_id, 'rescheduled');

  nw := book_appointment(p_new_session_id, old.patient_id, p_user_id, p_slot_starts_at, old.platform_fee_paise);
  UPDATE appointments SET rescheduled_from_id = old.id WHERE id = nw.id RETURNING * INTO nw;
  RETURN nw;
END $$;

-- Doctor/facility cancels a whole sitting (emergency, leave). Returns affected
-- appointment ids so the app can notify each patient and process refunds.
CREATE FUNCTION cancel_session(p_session_id uuid, p_actor uuid, p_reason text)
RETURNS SETOF uuid LANGUAGE plpgsql AS $$
DECLARE r record;
BEGIN
  UPDATE consultation_sessions SET status = 'cancelled', public_note = p_reason, updated_by = p_actor
   WHERE id = p_session_id AND status IN ('scheduled','running_late');
  IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_CANCELLABLE' USING ERRCODE = 'P0001'; END IF;

  FOR r IN SELECT id FROM appointments
            WHERE session_id = p_session_id AND status IN ('pending_payment','confirmed')
            FOR UPDATE
  LOOP
    UPDATE appointments SET status = 'cancelled_by_provider', cancel_reason = p_reason, cancelled_at = now()
     WHERE id = r.id;
    INSERT INTO appointment_events (appointment_id, from_status, to_status, actor_user_id, note)
    VALUES (r.id, 'confirmed', 'cancelled_by_provider', p_actor, p_reason);
    RETURN NEXT r.id;
  END LOOP;
  UPDATE consultation_sessions SET active_count = 0 WHERE id = p_session_id;
  UPDATE waitlist_entries SET status = 'cancelled' WHERE session_id = p_session_id AND status = 'waiting';
END $$;

-- =====================================================================
-- Medicine order acceptance — Rx check + stock reservation in one step
-- =====================================================================
CREATE FUNCTION accept_medicine_order(p_order_id uuid, p_pharmacist uuid)
RETURNS medicine_orders LANGUAGE plpgsql AS $$
DECLARE o medicine_orders%ROWTYPE; it record; short int;
BEGIN
  SELECT * INTO o FROM medicine_orders WHERE id = p_order_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND' USING ERRCODE = 'P0001'; END IF;
  IF o.status NOT IN ('placed','awaiting_rx_review') THEN
    RAISE EXCEPTION 'NOT_ACCEPTABLE' USING ERRCODE = 'P0001';
  END IF;

  -- actor must be an active pharmacist of THIS pharmacy
  IF NOT EXISTS (SELECT 1 FROM user_roles WHERE user_id = p_pharmacist AND role = 'pharmacist'
                  AND pharmacy_id = o.pharmacy_id AND revoked_at IS NULL) THEN
    RAISE EXCEPTION 'NOT_PHARMACIST_OF_PHARMACY' USING ERRCODE = 'P0001';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pharmacies WHERE id = o.pharmacy_id AND verification_status = 'verified'
                  AND accepts_online_orders AND licence_valid_until >= current_date) THEN
    RAISE EXCEPTION 'PHARMACY_NOT_ELIGIBLE' USING ERRCODE = 'P0001';
  END IF;

  IF o.requires_prescription AND NOT EXISTS (
       SELECT 1 FROM prescription_reviews pr
        WHERE pr.order_id = o.id AND pr.prescription_id = o.prescription_id
          AND pr.decision = 'approved'
          AND pr.reviewed_at = (SELECT max(reviewed_at) FROM prescription_reviews WHERE order_id = o.id)) THEN
    RAISE EXCEPTION 'RX_NOT_APPROVED' USING ERRCODE = 'P0001';
  END IF;

  FOR it IN SELECT medicine_id, quantity FROM medicine_order_items WHERE order_id = o.id ORDER BY medicine_id LOOP
    UPDATE pharmacy_inventory SET stock_qty = stock_qty - it.quantity
     WHERE pharmacy_id = o.pharmacy_id AND medicine_id = it.medicine_id AND stock_qty >= it.quantity;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'OUT_OF_STOCK:%', it.medicine_id USING ERRCODE = 'P0001';
    END IF;
  END LOOP;

  UPDATE medicine_orders SET status = 'accepted' WHERE id = o.id RETURNING * INTO o;
  INSERT INTO order_events (order_id, from_status, to_status, actor_user_id)
  VALUES (o.id, 'placed', 'accepted', p_pharmacist);
  RETURN o;
END $$;

-- Admin view without clinical data (least privilege): no prescription links, no patient DOB.
CREATE VIEW admin_order_overview AS
SELECT o.id, o.order_code, o.pharmacy_id, o.status, o.requires_prescription,
       o.total_paise, o.payment_status, o.created_at, o.updated_at,
       (SELECT count(*) FROM medicine_order_items i WHERE i.order_id = o.id) AS item_count
FROM medicine_orders o;

-- Stale schedule monitor for the admin dashboard.
CREATE VIEW stale_schedules AS
SELECT dp.id AS practice_id, d.full_name AS doctor, f.name AS facility,
       dp.schedule_state, dp.schedule_confirmed_at
FROM doctor_practices dp
JOIN doctors d ON d.id = dp.doctor_id
JOIN facilities f ON f.id = dp.facility_id
WHERE dp.is_active
  AND (dp.schedule_state <> 'confirmed'
       OR dp.schedule_confirmed_at <= now() - make_interval(days =>
            (SELECT value::int FROM platform_settings WHERE key = 'schedule_stale_after_days')));

COMMIT;
