-- Phase 4: sitting generation, schedule exceptions applied to existing
-- sittings, booking limits, cancellation window, waiting-list offers.
BEGIN;

-- Extra sittings need their own size.
ALTER TABLE schedule_exceptions
  ADD COLUMN capacity smallint CHECK (capacity BETWEEN 1 AND 500),
  ADD COLUMN slot_minutes smallint CHECK (slot_minutes BETWEEN 5 AND 120),
  ADD CONSTRAINT extra_session_needs_practice_and_capacity
    CHECK (kind <> 'extra_session' OR (practice_id IS NOT NULL AND capacity IS NOT NULL));

CREATE FUNCTION setting_int(p_key text) RETURNS int LANGUAGE sql STABLE AS $$
  SELECT value::int FROM platform_settings WHERE key = p_key
$$;

-- India time helpers: a local date + local time -> absolute instant.
CREATE FUNCTION ist(p_date date, p_time time) RETURNS timestamptz LANGUAGE sql IMMUTABLE AS $$
  SELECT (p_date + p_time) AT TIME ZONE 'Asia/Kolkata'
$$;

-- ---------------------------------------------------------------------
-- Generate sittings for [p_from, p_from + p_days) from weekly templates.
-- Leave / holiday / cancelled exceptions suppress a sitting; time_change
-- moves it; extra_session adds one. Idempotent: existing sittings are kept.
-- Pass p_practice_id to regenerate a single practice after its schedule changes.
-- Returns how many new sittings were created.
-- ---------------------------------------------------------------------
CREATE FUNCTION generate_sessions(p_from date, p_days int, p_practice_id uuid DEFAULT NULL) RETURNS int LANGUAGE plpgsql AS $$
DECLARE created int := 0; n int;
BEGIN
  IF p_days < 1 OR p_days > 60 THEN RAISE EXCEPTION 'p_days must be 1..60'; END IF;

  WITH days AS (
    SELECT d::date AS d FROM generate_series(p_from, p_from + p_days - 1, interval '1 day') d
  ), base AS (
    SELECT t.id AS template_id, t.practice_id, dp.doctor_id, dp.booking_mode, days.d,
           t.start_time, t.end_time, t.slot_minutes, t.capacity
      FROM schedule_templates t
      JOIN doctor_practices dp ON dp.id = t.practice_id AND dp.is_active
      JOIN days ON extract(dow FROM days.d) = t.weekday
     WHERE (p_practice_id IS NULL OR t.practice_id = p_practice_id)
       AND days.d >= t.effective_from
       AND (t.effective_to IS NULL OR days.d <= t.effective_to)
       AND (t.week_of_month IS NULL OR ((extract(day FROM days.d)::int - 1) / 7 + 1) = ANY (t.week_of_month))
  ), shaped AS (
    SELECT b.*,
           coalesce(tc.new_start_time, b.start_time) AS s_time,
           coalesce(tc.new_end_time, b.end_time) AS e_time
      FROM base b
      LEFT JOIN LATERAL (
        SELECT se.new_start_time, se.new_end_time FROM schedule_exceptions se
         WHERE se.kind = 'time_change' AND se.doctor_id = b.doctor_id
           AND (se.practice_id IS NULL OR se.practice_id = b.practice_id)
           AND b.d BETWEEN se.starts_on AND se.ends_on
         ORDER BY se.created_at DESC LIMIT 1
      ) tc ON true
     WHERE NOT EXISTS (
       SELECT 1 FROM schedule_exceptions se
        WHERE se.kind IN ('leave', 'holiday', 'cancelled') AND se.doctor_id = b.doctor_id
          AND (se.practice_id IS NULL OR se.practice_id = b.practice_id)
          AND b.d BETWEEN se.starts_on AND se.ends_on)
  ), ins AS (
    INSERT INTO consultation_sessions (practice_id, template_id, session_date, starts_at, ends_at, booking_mode,
                                       slot_minutes, capacity, booking_closes_at)
    SELECT practice_id, template_id, d, ist(d, s_time), ist(d, e_time), booking_mode,
           CASE WHEN booking_mode = 'time_slot' THEN slot_minutes END,
           -- a time-slot sitting can never hold more patients than it has slots
           CASE WHEN booking_mode = 'time_slot' AND slot_minutes IS NOT NULL
                THEN least(capacity, (extract(epoch FROM (e_time - s_time)) / 60 / slot_minutes)::int)
                ELSE capacity END,
           ist(d, s_time) - make_interval(mins => setting_int('booking_cutoff_minutes'))
      FROM shaped
     WHERE e_time > s_time AND ist(d, s_time) > now()
       AND (booking_mode <> 'time_slot' OR slot_minutes IS NOT NULL)
    ON CONFLICT (practice_id, starts_at) DO NOTHING
    RETURNING 1
  )
  SELECT count(*) INTO n FROM ins;
  created := created + n;

  -- Extra one-off sittings
  WITH days AS (
    SELECT d::date AS d FROM generate_series(p_from, p_from + p_days - 1, interval '1 day') d
  ), ins AS (
    INSERT INTO consultation_sessions (practice_id, session_date, starts_at, ends_at, booking_mode, slot_minutes,
                                       capacity, booking_closes_at)
    SELECT se.practice_id, days.d, ist(days.d, se.new_start_time), ist(days.d, se.new_end_time), dp.booking_mode,
           CASE WHEN dp.booking_mode = 'time_slot' THEN coalesce(se.slot_minutes, 15) END, se.capacity,
           ist(days.d, se.new_start_time) - make_interval(mins => setting_int('booking_cutoff_minutes'))
      FROM schedule_exceptions se
      JOIN doctor_practices dp ON dp.id = se.practice_id AND dp.is_active
      JOIN days ON days.d BETWEEN se.starts_on AND se.ends_on
     WHERE se.kind = 'extra_session' AND ist(days.d, se.new_start_time) > now()
       AND (p_practice_id IS NULL OR se.practice_id = p_practice_id)
    ON CONFLICT (practice_id, starts_at) DO NOTHING
    RETURNING 1
  )
  SELECT count(*) INTO n FROM ins;
  RETURN created + n;
END $$;

-- ---------------------------------------------------------------------
-- Apply a new exception to sittings that already exist.
-- leave / holiday / cancelled: cancel each affected sitting (and its bookings).
-- time_change: move the sitting; time-slot bookings move by the same offset,
--   and any that no longer fit are cancelled.
-- Returns every affected appointment id (for SMS and refunds).
-- ---------------------------------------------------------------------
CREATE FUNCTION apply_schedule_exception(p_exception_id uuid, p_actor uuid)
RETURNS SETOF uuid LANGUAGE plpgsql AS $$
DECLARE ex schedule_exceptions%ROWTYPE; s record; appt uuid; shift interval; new_start timestamptz; new_end timestamptz;
BEGIN
  SELECT * INTO ex FROM schedule_exceptions WHERE id = p_exception_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND' USING ERRCODE = 'P0001'; END IF;

  FOR s IN
    SELECT cs.* FROM consultation_sessions cs JOIN doctor_practices dp ON dp.id = cs.practice_id
     WHERE dp.doctor_id = ex.doctor_id
       AND (ex.practice_id IS NULL OR cs.practice_id = ex.practice_id)
       AND cs.session_date BETWEEN ex.starts_on AND ex.ends_on
       AND cs.status IN ('scheduled', 'running_late')
       AND cs.ends_at > now()
     ORDER BY cs.starts_at
     FOR UPDATE OF cs
  LOOP
    IF ex.kind IN ('leave', 'holiday', 'cancelled') THEN
      FOR appt IN SELECT * FROM cancel_session(s.id, p_actor, coalesce(ex.reason_public, ex.kind::text)) LOOP
        RETURN NEXT appt;
      END LOOP;
    ELSIF ex.kind = 'time_change' THEN
      -- Everyone booked on this sitting is affected (moved or, if they no longer fit, cancelled).
      FOR appt IN SELECT id FROM appointments WHERE session_id = s.id AND status IN ('pending_payment', 'confirmed') LOOP
        RETURN NEXT appt;
      END LOOP;
      new_start := ist(s.session_date, ex.new_start_time);
      new_end := ist(s.session_date, ex.new_end_time);
      shift := new_start - s.starts_at;
      UPDATE consultation_sessions
         SET starts_at = new_start, ends_at = new_end, updated_by = p_actor,
             booking_closes_at = new_start - make_interval(mins => setting_int('booking_cutoff_minutes')),
             public_note = coalesce(ex.reason_public, public_note)
       WHERE id = s.id;
      IF s.booking_mode = 'time_slot' THEN
        -- Two-step move so the unique (session, slot) index never sees a clash mid-update.
        UPDATE appointments SET slot_starts_at = slot_starts_at + interval '100 years'
         WHERE session_id = s.id AND status IN ('pending_payment', 'confirmed');
        UPDATE appointments SET slot_starts_at = slot_starts_at - interval '100 years' + shift
         WHERE session_id = s.id AND status IN ('pending_payment', 'confirmed');
        FOR appt IN
          SELECT id FROM appointments
           WHERE session_id = s.id AND status IN ('pending_payment', 'confirmed')
             AND slot_starts_at + make_interval(mins => s.slot_minutes) > new_end
        LOOP
          PERFORM cancel_appointment(appt, p_actor, true, coalesce(ex.reason_public, 'time_change'));
        END LOOP;
      END IF;
    END IF;
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- Booking v2: adds a per-account cap on upcoming bookings (stops one
-- account from holding a whole sitting) and marks a waiting-list entry booked.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION book_appointment(
  p_session_id uuid, p_patient_id uuid, p_user_id uuid,
  p_slot_starts_at timestamptz DEFAULT NULL, p_platform_fee_paise bigint DEFAULT 0
) RETURNS appointments LANGUAGE plpgsql AS $$
DECLARE s bookable_sessions%ROWTYPE; tok smallint; a appointments%ROWTYPE; active int;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM patients WHERE id = p_patient_id AND account_user_id = p_user_id AND deleted_at IS NULL) THEN
    RAISE EXCEPTION 'PATIENT_NOT_OWNED' USING ERRCODE = 'P0001';
  END IF;

  -- Serialise this account's bookings so the cap cannot be beaten by parallel requests.
  PERFORM 1 FROM users WHERE id = p_user_id FOR UPDATE;
  SELECT count(*) INTO active FROM appointments a2 JOIN consultation_sessions cs ON cs.id = a2.session_id
   WHERE a2.booked_by_user_id = p_user_id AND a2.status IN ('pending_payment', 'confirmed') AND cs.ends_at > now();
  IF active >= setting_int('max_active_bookings_per_user') THEN
    RAISE EXCEPTION 'TOO_MANY_ACTIVE' USING ERRCODE = 'P0001';
  END IF;

  SELECT * INTO s FROM bookable_sessions WHERE id = p_session_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_BOOKABLE' USING ERRCODE = 'P0001'; END IF;

  IF s.booking_mode = 'time_slot' THEN
    IF p_slot_starts_at IS NULL
       OR p_slot_starts_at < s.starts_at
       OR p_slot_starts_at + make_interval(mins => s.slot_minutes) > s.ends_at
       OR mod(extract(epoch FROM (p_slot_starts_at - s.starts_at))::int, s.slot_minutes * 60) <> 0 THEN
      RAISE EXCEPTION 'INVALID_SLOT' USING ERRCODE = 'P0001';
    END IF;
  ELSIF p_slot_starts_at IS NOT NULL THEN
    RAISE EXCEPTION 'SLOT_NOT_APPLICABLE' USING ERRCODE = 'P0001';
  END IF;

  UPDATE consultation_sessions
     SET active_count = active_count + 1, next_token = next_token + 1
   WHERE id = p_session_id AND status IN ('scheduled', 'running_late') AND active_count < capacity
  RETURNING next_token - 1 INTO tok;
  IF tok IS NULL THEN RAISE EXCEPTION 'SESSION_FULL' USING ERRCODE = 'P0001'; END IF;

  BEGIN
    INSERT INTO appointments (booking_code, session_id, patient_id, booked_by_user_id, token_number, slot_starts_at,
                              status, consultation_fee_paise, platform_fee_paise)
    VALUES (make_code('B'), p_session_id, p_patient_id, p_user_id, tok, p_slot_starts_at, 'confirmed',
            s.consultation_fee_paise, p_platform_fee_paise)
    RETURNING * INTO a;
  EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'ALREADY_BOOKED' USING ERRCODE = 'P0001';
  END;

  INSERT INTO appointment_events (appointment_id, to_status, actor_user_id, note) VALUES (a.id, 'confirmed', p_user_id, 'booked');
  UPDATE waitlist_entries SET status = 'booked' WHERE session_id = p_session_id AND patient_id = p_patient_id AND status IN ('waiting', 'offered');
  RETURN a;
END $$;

-- ---------------------------------------------------------------------
-- Cancel v2: patients can cancel only their own booking and only until
-- booking closes (default 30 minutes before the sitting). Providers can always cancel.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION cancel_appointment(
  p_appointment_id uuid, p_actor uuid, p_by_provider boolean, p_reason text
) RETURNS appointments LANGUAGE plpgsql AS $$
DECLARE a appointments%ROWTYPE; new_status appointment_status; prev appointment_status; closes timestamptz;
BEGIN
  SELECT * INTO a FROM appointments WHERE id = p_appointment_id FOR UPDATE;
  IF NOT FOUND OR (NOT p_by_provider AND a.booked_by_user_id IS DISTINCT FROM p_actor) THEN
    RAISE EXCEPTION 'NOT_FOUND' USING ERRCODE = 'P0001';
  END IF;
  IF a.status NOT IN ('pending_payment', 'confirmed') THEN RAISE EXCEPTION 'NOT_CANCELLABLE' USING ERRCODE = 'P0001'; END IF;
  IF NOT p_by_provider THEN
    SELECT coalesce(booking_closes_at, starts_at) INTO closes FROM consultation_sessions WHERE id = a.session_id;
    IF closes <= now() THEN RAISE EXCEPTION 'CANCEL_WINDOW_CLOSED' USING ERRCODE = 'P0001'; END IF;
  END IF;
  prev := a.status;
  new_status := CASE WHEN p_by_provider THEN 'cancelled_by_provider' ELSE 'cancelled_by_patient' END;
  UPDATE appointments SET status = new_status, cancel_reason = p_reason, cancelled_at = now() WHERE id = a.id RETURNING * INTO a;
  UPDATE consultation_sessions SET active_count = active_count - 1 WHERE id = a.session_id;
  INSERT INTO appointment_events (appointment_id, from_status, to_status, actor_user_id, note) VALUES (a.id, prev, new_status, p_actor, p_reason);
  RETURN a;
END $$;

CREATE OR REPLACE FUNCTION reschedule_appointment(
  p_appointment_id uuid, p_new_session_id uuid, p_user_id uuid, p_slot_starts_at timestamptz DEFAULT NULL
) RETURNS appointments LANGUAGE plpgsql AS $$
DECLARE old appointments%ROWTYPE; nw appointments%ROWTYPE; closes timestamptz;
BEGIN
  SELECT * INTO old FROM appointments WHERE id = p_appointment_id AND booked_by_user_id = p_user_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND' USING ERRCODE = 'P0001'; END IF;
  IF old.status <> 'confirmed' THEN RAISE EXCEPTION 'NOT_RESCHEDULABLE' USING ERRCODE = 'P0001'; END IF;
  SELECT coalesce(booking_closes_at, starts_at) INTO closes FROM consultation_sessions WHERE id = old.session_id;
  IF closes <= now() THEN RAISE EXCEPTION 'CANCEL_WINDOW_CLOSED' USING ERRCODE = 'P0001'; END IF;

  UPDATE appointments SET status = 'rescheduled', cancelled_at = now() WHERE id = old.id;
  UPDATE consultation_sessions SET active_count = active_count - 1 WHERE id = old.session_id;
  INSERT INTO appointment_events (appointment_id, from_status, to_status, actor_user_id, note)
  VALUES (old.id, 'confirmed', 'rescheduled', p_user_id, 'rescheduled');

  nw := book_appointment(p_new_session_id, old.patient_id, p_user_id, p_slot_starts_at, old.platform_fee_paise);
  UPDATE appointments SET rescheduled_from_id = old.id WHERE id = nw.id RETURNING * INTO nw;
  RETURN nw;
END $$;

-- ---------------------------------------------------------------------
-- Waiting list: when a seat frees up, offer it to the earliest waiting
-- patient (they get an SMS). The seat is not held: first to book gets it,
-- which keeps the paper queue at the chamber and the app in step.
-- ---------------------------------------------------------------------
CREATE FUNCTION offer_next_waitlist(p_session_id uuid) RETURNS waitlist_entries LANGUAGE plpgsql AS $$
DECLARE w waitlist_entries%ROWTYPE; closes timestamptz;
BEGIN
  SELECT coalesce(booking_closes_at, starts_at) INTO closes FROM consultation_sessions
   WHERE id = p_session_id AND status IN ('scheduled', 'running_late') AND active_count < capacity;
  IF closes IS NULL OR closes <= now() THEN RETURN NULL; END IF;
  UPDATE waitlist_entries SET status = 'offered', offered_until = closes
   WHERE id = (SELECT id FROM waitlist_entries WHERE session_id = p_session_id AND status = 'waiting'
                ORDER BY created_at LIMIT 1 FOR UPDATE SKIP LOCKED)
  RETURNING * INTO w;
  RETURN w;
END $$;

CREATE INDEX idx_appt_session_status ON appointments (session_id, status);
CREATE INDEX idx_notif_dedupe ON notifications (user_id, template_key, (payload->>'appointment_id'));

COMMIT;
