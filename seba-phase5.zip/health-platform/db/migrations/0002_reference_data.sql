-- Reference data needed in every environment: launch towns and specialities.
-- Also: town slugs, an index for name search, and an OTP rate-limit index.
BEGIN;

ALTER TABLE localities ADD COLUMN slug text;
CREATE UNIQUE INDEX uq_localities_slug ON localities (slug) WHERE slug IS NOT NULL;

INSERT INTO localities (slug, name_en, name_bn, district, state, is_launched) VALUES
  ('dhuliyan', 'Dhuliyan', 'ধুলিয়ান', 'Murshidabad', 'West Bengal', true),
  ('farakka',  'Farakka',  'ফারাক্কা', 'Murshidabad', 'West Bengal', true),
  ('jangipur', 'Jangipur', 'জঙ্গিপুর', 'Murshidabad', 'West Bengal', true),
  ('malda',    'Malda',    'মালদা',    'Malda',       'West Bengal', true)
ON CONFLICT (name_en, district, state) DO UPDATE SET slug = EXCLUDED.slug, name_bn = EXCLUDED.name_bn, is_launched = true;

-- Common OPD specialities. Bengali names are the everyday terms patients use.
INSERT INTO specialities (slug, name_en, name_bn, name_hi) VALUES
  ('general-physician',  'General physician',            'সাধারণ চিকিৎসক',          'सामान्य चिकित्सक'),
  ('paediatrics',        'Child specialist',             'শিশু বিশেষজ্ঞ',            'बाल रोग विशेषज्ञ'),
  ('gynaecology',        'Gynaecologist',                'স্ত্রীরোগ বিশেষজ্ঞ',        'स्त्री रोग विशेषज्ञ'),
  ('medicine',           'Medicine specialist',          'মেডিসিন বিশেষজ্ঞ',         'मेडिसिन विशेषज्ञ'),
  ('orthopaedics',       'Bone and joint specialist',    'হাড় ও জয়েন্ট বিশেষজ্ঞ',     'हड्डी रोग विशेषज्ञ'),
  ('ent',                'ENT specialist',               'নাক কান গলা বিশেষজ্ঞ',      'नाक कान गला विशेषज्ञ'),
  ('dermatology',        'Skin specialist',              'চর্মরোগ বিশেষজ্ঞ',          'त्वचा रोग विशेषज्ञ'),
  ('ophthalmology',      'Eye specialist',               'চক্ষু বিশেষজ্ঞ',            'नेत्र रोग विशेषज्ञ'),
  ('cardiology',         'Heart specialist',             'হৃদরোগ বিশেষজ্ঞ',           'हृदय रोग विशेषज्ञ'),
  ('neurology',          'Nerve and brain specialist',   'স্নায়ুরোগ বিশেষজ্ঞ',         'तंत्रिका रोग विशेषज्ञ'),
  ('psychiatry',         'Psychiatrist',                 'মনোরোগ বিশেষজ্ঞ',          'मनोचिकित्सक'),
  ('surgery',            'General surgeon',              'জেনারেল সার্জন',            'सामान्य सर्जन'),
  ('urology',            'Urologist',                    'মূত্ররোগ বিশেষজ্ঞ',          'मूत्र रोग विशेषज्ञ'),
  ('chest',              'Chest specialist',             'বক্ষরোগ বিশেষজ্ঞ',          'छाती रोग विशेषज्ञ'),
  ('dentistry',          'Dentist',                      'দাঁতের ডাক্তার',             'दंत चिकित्सक'),
  ('diabetes',           'Diabetes specialist',          'ডায়াবেটিস বিশেষজ্ঞ',        'मधुमेह विशेषज्ञ')
ON CONFLICT (slug) DO NOTHING;

CREATE INDEX idx_specialities_bn_trgm ON specialities USING gin (name_bn gin_trgm_ops);
CREATE INDEX idx_specialities_en_trgm ON specialities USING gin (name_en gin_trgm_ops);
CREATE INDEX idx_doctors_name_bn_trgm ON doctors USING gin (full_name_bn gin_trgm_ops);
CREATE INDEX idx_facilities_name_bn_trgm ON facilities USING gin (name_bn gin_trgm_ops);
CREATE INDEX idx_otp_ip_recent ON otp_challenges (request_ip, created_at DESC);

-- Demo rows are flagged so they can never be mistaken for real providers and
-- can be removed in one statement.
ALTER TABLE doctors    ADD COLUMN is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE facilities ADD COLUMN is_demo boolean NOT NULL DEFAULT false;

COMMIT;
