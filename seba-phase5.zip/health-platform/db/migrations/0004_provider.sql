-- Phase 5: provider-side operations — staff bookings for phone and walk-in
-- patients, the visit queue (check-in / done / no-show), one-tap schedule
-- confirmation, running late, and rebuilding sittings after a schedule edit.
BEGIN;

CREATE INDEX idx_user_roles_active ON user_roles (user_id) WHERE revoked_at IS NULL;
CREATE INDEX idx_doctors_user ON doctors (user_id) WHERE user_id IS NOT NULL;

-- ---------------------------------------------------------------------
-- Staff booking: the chamber's phone and walk-in queue goes into the same
-- sitting as online bookings, so every seat shown online is real.
-- Differences from patient booking: no per-account cap (one phone can book
-- for a family), and staff can add patients until the sitting ends.
-- ---------------------------------------------------------------------
CREATE FUNCTION book_by_staff(p_session_id uuid, p_patient_id uuid, p_account_user_id uuid, p_staff_id uuid)
RETURNS appointments LANGUAGE plpgsql AS $$
DECLARE s consultation_sessions%ROWTYPE; fee bigint; tok smallint; a appointments%ROWTYPE;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM patients WHERE id = p_patient_id AND account_user_id = p_account_user_id AND deleted_at IS NULL) THEN
    RAISE EXCEPTION 'PATIENT_NOT_OWNED' USING ERRCODE = 'P0001';
  END IF;
  SELECT cs.* INTO s FROM consultation_sessions cs JOIN doctor_practices dp ON dp.id = cs.practice_id AND dp.is_active
   WHERE cs.id = p_session_id AND cs.status IN ('scheduled', 'running_late') AND cs.ends_at > now();
  IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_BOOKABLE' USING ERRCODE = 'P0001'; END IF;
  IF s.booking_mode = 'time_slot' THEN RAISE EXCEPTION 'SLOT_NOT_APPLICABLE' USING ERRCODE = 'P0001'; END IF;
  SELECT consultation_fee_paise INTO fee FROM doctor_practices WHERE id = s.practice_id;

  UPDATE consultation_sessions SET active_count = active_count + 1, next_token = next_token + 1
   WHERE id = p_session_id AND active_count < capacity
  RETURNING next_token - 1 INTO tok;
  IF tok IS NULL THEN RAISE EXCEPTION 'SESSION_FULL' USING ERRCODE = 'P0001'; END IF;

  BEGIN
    INSERT INTO appointments (booking_code, session_id, patient_id, booked_by_user_id, token_number, status, consultation_fee_paise)
    VALUES (make_code('B'), p_session_id, p_patient_id, p_account_user_id, tok, 'confirmed', fee)
    RETURNING * INTO a;
  EXCEPTION WHEN unique_violation THEN
    RAISE EXCEPTION 'ALREADY_BOOKED' USING ERRCODE = 'P0001';
  END;
  INSERT INTO appointment_events (appointment_id, to_status, actor_user_id, note) VALUES (a.id, 'confirmed', p_staff_id, 'booked by clinic');
  RETURN a;
END $$;

-- ---------------------------------------------------------------------
-- Visit queue. Allowed moves only; only on or after the sitting's day.
-- ---------------------------------------------------------------------
CREATE FUNCTION set_visit_status(p_appointment_id uuid, p_to appointment_status, p_actor uuid)
RETURNS appointments LANGUAGE plpgsql AS $$
DECLARE a appointments%ROWTYPE; s consultation_sessions%ROWTYPE; prev appointment_status;
BEGIN
  SELECT * INTO a FROM appointments WHERE id = p_appointment_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND' USING ERRCODE = 'P0001'; END IF;
  SELECT * INTO s FROM consultation_sessions WHERE id = a.session_id;
  IF s.session_date > (now() AT TIME ZONE 'Asia/Kolkata')::date THEN
    RAISE EXCEPTION 'TOO_EARLY' USING ERRCODE = 'P0001';
  END IF;
  IF NOT ((a.status = 'confirmed' AND p_to IN ('checked_in', 'completed', 'no_show'))
       OR (a.status = 'checked_in' AND p_to IN ('completed', 'no_show'))
       OR (a.status = 'no_show' AND p_to = 'checked_in')) THEN   -- arrived late after all
    RAISE EXCEPTION 'INVALID_TRANSITION' USING ERRCODE = 'P0001';
  END IF;
  prev := a.status;
  UPDATE appointments SET status = p_to WHERE id = a.id RETURNING * INTO a;
  INSERT INTO appointment_events (appointment_id, from_status, to_status, actor_user_id) VALUES (a.id, prev, p_to, p_actor);
  RETURN a;
END $$;

-- One tap: "this schedule is still correct".
CREATE FUNCTION confirm_schedule(p_practice_id uuid, p_actor uuid) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  UPDATE doctor_practices SET schedule_state = 'confirmed', schedule_confirmed_at = now(), schedule_confirmed_by = p_actor
   WHERE id = p_practice_id AND is_active;
  IF NOT FOUND THEN RAISE EXCEPTION 'NOT_FOUND' USING ERRCODE = 'P0001'; END IF;
END $$;

CREATE FUNCTION set_running_late(p_session_id uuid, p_late boolean, p_note text, p_actor uuid) RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  UPDATE consultation_sessions
     SET status = CASE WHEN p_late THEN 'running_late' ELSE 'scheduled' END::session_status,
         public_note = CASE WHEN p_late THEN p_note END, updated_by = p_actor
   WHERE id = p_session_id AND status IN ('scheduled', 'running_late') AND ends_at > now();
  IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_CANCELLABLE' USING ERRCODE = 'P0001'; END IF;
END $$;

-- ---------------------------------------------------------------------
-- After the weekly schedule changes: remove future sittings that nobody has
-- ever booked or waited for, then regenerate. Sittings with bookings are kept
-- as they are (the clinic handles those patients by moving or cancelling).
-- ---------------------------------------------------------------------
CREATE FUNCTION rebuild_future_sessions(p_practice_id uuid)
RETURNS TABLE (removed int, created int, kept_with_bookings int) LANGUAGE plpgsql AS $$
DECLARE r int; c int; k int;
BEGIN
  WITH del AS (
    DELETE FROM consultation_sessions cs
     WHERE cs.practice_id = p_practice_id AND cs.starts_at > now() AND cs.status = 'scheduled'
       AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.session_id = cs.id)
       AND NOT EXISTS (SELECT 1 FROM waitlist_entries w WHERE w.session_id = cs.id)
       AND cs.active_count = 0
    RETURNING 1)
  SELECT count(*) INTO r FROM del;
  c := generate_sessions((now() AT TIME ZONE 'Asia/Kolkata')::date, setting_int('booking_horizon_days'), p_practice_id);
  -- Booked sittings that no longer match the weekly schedule: the clinic must move or cancel them.
  SELECT count(*) INTO k FROM consultation_sessions cs
   WHERE cs.practice_id = p_practice_id AND cs.starts_at > now() AND cs.status IN ('scheduled', 'running_late')
     AND EXISTS (SELECT 1 FROM appointments a WHERE a.session_id = cs.id AND a.status IN ('confirmed', 'pending_payment'))
     AND NOT EXISTS (SELECT 1 FROM schedule_templates t
                      WHERE t.practice_id = p_practice_id AND t.weekday = extract(dow FROM cs.session_date)
                        AND ist(cs.session_date, t.start_time) = cs.starts_at)
     AND NOT EXISTS (SELECT 1 FROM schedule_exceptions se
                      WHERE se.practice_id = p_practice_id AND se.kind IN ('extra_session', 'time_change')
                        AND cs.session_date BETWEEN se.starts_on AND se.ends_on);
  RETURN QUERY SELECT r, c, k;
END $$;

-- Templates can now be deleted while past sittings keep a history.
ALTER TABLE consultation_sessions DROP CONSTRAINT consultation_sessions_template_id_fkey,
  ADD CONSTRAINT consultation_sessions_template_id_fkey FOREIGN KEY (template_id) REFERENCES schedule_templates(id) ON DELETE SET NULL;

-- Phone numbers recorded by clinic staff for patients without the app.
ALTER TABLE users ADD COLUMN created_by_staff uuid REFERENCES users(id);

COMMIT;
