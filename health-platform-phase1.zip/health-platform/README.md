# Healthcare Booking & Pharmacy Platform — Phase 1

Phase 1 delivers the database foundation: the full PostgreSQL schema, the transaction-safe
booking and pharmacy rules, and tests that prove them. The Next.js app is built on top of
this in Phase 2 onward.

```
db/
  migrations/0001_init.sql     48 tables, enums, constraints, indexes, booking + order functions
  tests/rules_test.sql         18 rule tests (runs inside a transaction, leaves no data behind)
  tests/concurrency_test.sh    race test: many separate connections booking the same seats
```

## Run it

Requires PostgreSQL 15 or newer.

```bash
createdb health
export DATABASE_URL=postgresql://localhost/health

psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/migrations/0001_init.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f db/tests/rules_test.sql     # ends with: ALL TESTS PASSED
bash db/tests/concurrency_test.sh 40 10                                 # ends with: CONCURRENCY TEST PASSED
```

The concurrency test wipes the test tables first — run it only on a throwaway database.

## Key database functions

| Function | What it does |
| --- | --- |
| `book_appointment(session, patient, user, slot?, fee?)` | Takes one seat atomically; raises `SESSION_FULL`, `ALREADY_BOOKED`, `SESSION_NOT_BOOKABLE`, `INVALID_SLOT`, `PATIENT_NOT_OWNED` |
| `cancel_appointment(appt, actor, by_provider, reason)` | Frees the seat; serial numbers are never reused |
| `reschedule_appointment(appt, new_session, user, slot?)` | Moves a booking in one transaction |
| `cancel_session(session, actor, reason)` | Cancels a sitting and returns every affected booking for SMS / refunds |
| `accept_medicine_order(order, pharmacist)` | Checks pharmacist, licence, approved Rx review; reserves stock |

Views: `bookable_sessions` (the single definition of "available"), `stale_schedules`
(admin monitor), `admin_order_overview` (orders without clinical data).

## Conventions

- Money in paise (`bigint`), never floating point.
- Times as `timestamptz`; local display in Asia/Kolkata.
- Prescriptions and licences live in private object storage; the database stores only the key and SHA-256.
- `audit_logs` is append-only (updates, deletes and truncates are rejected).
- No secrets in code. Outside services run in a labelled dev mode until keys are configured.

Not legal advice: compliance needs review by a lawyer before launch.
